=============================================
=                                           =
=    This is a ViperSoft Creation           =    
=                                           =
=   Presenting TO U Newcomers PBVE          =
=                                           = 
=      Poly Batch Virus engine              =
=                                           =
=         Author: Viper                     =
=                                           =
=============================================

Version       0.1

Feel free to make changes if you would like
But please give me credit.

Coming soon:: vbs.Purple_Haze 