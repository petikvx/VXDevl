
  Simple Win32ASM Overwriter Generator
  by Second Part To Hell
  www.spth.de.vu
  spth@aonmail.at
  Austria


  1.) What the hell is this?

  Nice question: This is a simple tool to generate simple win32asm overwriter viruses. ;)
  The special thing is, that the whole code is totally random, and because of that, it
  will be hell for AVs to detect every virus.




  2.) Techniques

  As I told you, the tool generates totally random virus-codes, I didn't tell you
  anything about the techniques. OK, here we are:


    I) Adding Trash
	Adding trash is a really good technique in ASM I think, and because of that
	I included it. The idea came to my mind while i was reading the "Hunting for
	Metamorphic" by Sz�r & Ferrie (you'll find it in 29a#6). The princip of the 
	thing is really easy: you have you code, and between the lines you add some
	junk, which don't do anything.

	Examples for Adding Trash:
	--> inc	 ebp
	--> and  esi, 12h
	--> mov  ecx, 10d
	--> xor  ebx, ebx
	--> xchg edi, ebx
	--> ...

	Note: Don't forget, that you must not use registers for trash code, which
	      needs the virus to run. And you also don't have to use 'esp'.

   II) Changing instructions
	That's maybe the most successfully technique in my program ;). It's possible
	to make the same things with three different codes. The idea came to my mind
	while  I  was  look  at  some  output  of  SnakeByte's "New Generation Virus 
	Construction Kit". 

	Examples for Changing instructions:
	-----------------------
	push	offset any
	= = = = = = = = = = = =
	mov	eax, offset any
	push	eax
	-----------------------
		OR
	-----------------------
	add	eax, 3
	= = = = = = = = = = = =	
	inc	eax
	inc	eax
	inc	eax
	= = = = = = = = = = = =
	sub	eax, -3
	-----------------------
		OR
	-----------------------
	jmp	hello
	= = = = = = = = = = = =
	xor	ecx, ecx
	jecxz	hello
	= = = = = = = = = = = =
	cmp	eax, eax
	jge	hello
	-----------------------

	And so on... I think, you got the point.

  III) Using different registers
	Much metamorphic virus use this technique (like Mental Driller's MetaPHOR or
	Vecna's Regswap). I found that information while reading something about Vecna's
	Regswap, and I thought, that's good. 

	Examples for using different registers
	-----------------------
	add	eax, 12h
	mov	ebx, eax
	push	ebx
	= = = = = = = = = = = =
	add	ebp, 12h
	mov	esi, ebp
	push	esi
	-----------------------


   IV) Body moving
	Win32.Ghost use this techique (it has 10 functions=10*9*...*2*1 different generations).
	My program is able to generate 26*25*24*...*3*2*1 different generations. Moreover it
	will be a success when you remix your code.

	Example for Body Moving
	-----------------------
	push	0
	push	eax
	push	eax
	push	0
	call	MessageBoxA
	= = = = = = = = = = = =
	jmp a
	b:
	push	eax
	push	eax
	jmp c
	a:
	push	0
	jmp b
	c:
	push	0
	call 	MessageBoxA
	-----------------------

  3.) Thanks and Greets

	Thanks goes to:
		Vorgon				<-- for the tons of info you gave me in ASM
		Z0MBiE, Vecna, Mental Driller	<-- for the technique you discovered | giving me the ideas ;)
		Nekr0, SnakeByte, Daemonlord	<-- for the tuts and viruses you wrote ;)
		Lord Yup			<-- for giving me the tipp with the 'pewrsec'. thx!

	Greets:
		everybody in rRlf, Doctor Rave, jackie, VorteX, Worf, SAD1c, Gigabyte, Nekronomikon, Virusbuster, ...