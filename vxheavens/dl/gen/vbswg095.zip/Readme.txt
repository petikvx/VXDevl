______________________________________________________________________
Vbs Worms Generator 0.95 By [K]Alamar
Buenos Aires - Argentina - 11/Jul/2000
Http://www.virii.com.ar
Virii Argentina - The biggest virii resource in the net.
Bugs, questions or comments: kalamar@virii.com.ar
����������������������������������������������������������������������
**********************************************************************
YOU NEED THE WINDOWS SCRIPT HOST 5.0 OR LATER IF YOU WANT THE PROGRAM
TO WORK, IF THE WSH 5 IS NOT INSTALLED THE PROGRAM WILL TELL YOU.
YOU ALSO NEED THE VISUAL BASIC 5.0 RUNTIMES, YOU CAN GET THEM IN
MICROSOFT.COM OR YOU CAN ASK ME FOR THEM AND I'LL SEND THE FILES TO
YOU.
CONTACT ME IF YOU HAVE ANY OF THE PROBLEMS, I'LL HELP YOU.
**********************************************************************
YOU NEED THE MICROSOFT VISUAL BASIC 5.0 RUNTIMES TO RUN THIS PROGRAM.
**********************************************************************
Remeber, this program if for educational purpose only, I take no 
responsabiliy for any damage caused for any file created whit this 
program to anything.
**********************************************************************
PLEASE LEAVE THIS FILE IN THE SAME FOLDER AS THE EXE IF YOU WANT THE 
PROGRAM TO RUN FINE.
**********************************************************************
����������������������������������������������������������������������
Sorry for the bad english.
����������������������������������������������������������������������
Hi!:
Thanx for downloading the Vbs Worms Generator 0.95.
I can see the 1.0 Comming!
If you have any idea or code that i can add to the script please
contact me and i will add it.
Sorry for the bugs, after all, I'm just 17 years old!.
______________________________________________________________________
What's New:
*NEW ICON!, not very good, but better than the other one.
*Fixed more bugs!
*Script modification so Avp can detect your worms!
*Save as default option!!
*Added a Agreement the first time you run the program.
*Visual modification (startup ahs it's own window).
*Deleted Select your own script at mirc.
*Save as Vbe.
*Fixed mroe bugs.
*Added System Crash Payload.
*Can't remember anithing else.
______________________________________________________________________

It's not the 1.0 cause i think that there are still more bugs to be
fixed, and i am a little tired right now, i 3 or 4 days i will made
the final one, but no t the last!.
______________________________________________________________________
What can be new?:
i'm working in html infecting, adding the code to the html, but no
deleting it,  modifying all shortcuts to redirect to your script,
made all favorites go to any site, and a lot of stuf that i'm thinking.

If you have any idea, please let me know.
______________________________________________________________________
*Stuff:
The worms crated whit the program are completly randomized, so you 
will never have 2 equal worms.

What does that mean?

That all the variables are randomized words of 10 characters, so, the
posibilities of having two equal words in a worm are dificult, and 
the posibilities of having 2 equal worms are completily imposible.

You must be very carefoul when you edit the worm, because if you
change a variable, you must change it every time it's shown.
______________________________________________________________________
Thanx to:
Pepe Lepu for helping me.
Mano/SunSoft_Team for the Pirch script.
All the people who contact me for the congratulations for this great
program!, i can name all her, but they know who they are.

I think that I haven't forget somebody, if i do, sorry.
______________________________________________________________________
*Features:

Start whit windows:
This make the worm be executed every time windows is started, so your
worm can try to infect or spread every day.

Worm backup:
It's just for having a copy of the worm in a safe place, so you can
be shure that it will no be lost.

Outlook Replication:
it uses the same function that all the vbs's, js's or any other kind of
worm, it sends a message, that you can define, whit te worm attached
to every preson in the user's address list.

Mirc replication:
Search for mirc.ini(what means that the mirc is there) in the most
commons floders(programfiles\mirc, c:\mirc, c:\mirc32) and if it 
is found, the worm create "script.ini" in that folder, that script make
the mirc sends the worm to every person that join to a channel.
(see "If found Mirc, infect.")

Pirch replication:
Same as mirc, but for pirch (i haven't tested the script cause i 
haven't got pirch, please someone test it and tell me if this work).

Infect Files:
The worm will search for all the hard drives (and the network drives 
too, i think) for files whit the extencion that you want(in this
version only .vbs and vbe are searched) and copy overwrite him whit itself.
*If found Mirc, infect:
This will make the worm to search also for mirc.ini, so if it find him,
it will infect the folder where mirc is. This method works 100% of the
times.

'To do a search for all the computer could take over 5 minutes, 
depending of the hard drive size.

Payloads:
These are stuff that you can add to the worm to be done.
  Message: shows a message box whit the text and the picture that
  you want.

  Open web address: open the web address that you want.

  Crash System: Creates 1Mb variables until the system goes down of
  memory

  When?: whit this you can tell the worm when do you wan to execute
  the payloads.

*Any idea?, contact me and i will add it!.

Save as fefault:
If you click this button in any window, the optionsselected are going
to be the same everitime you run the program, i thnk that it's nice.
______________________________________________________________________

Ok, this is all that the program can make, maybe i forgot something,
i don't know.
I hope that you can learn something about Visual Scripting, it's
really easy an powerfull.
Visit www.virii.com.ar often if you wnna get the newest versions.

Have fun.

[K]Alamar
kalamar@virii.com.ar
http://www.virii.com.ar
______________________________________________________________________
Visual Basic is too easy!.
����������������������������������������������������������������������