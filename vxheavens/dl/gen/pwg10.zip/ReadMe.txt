
 Worm Generator 1.0a
 -------------------

 Author  : p0ke
 Release : 21 Feb 2004
 Size    : 431�616 byte

 -------------------

 The most WormGens ive seen generates detected binaries.
 Well this doesnt. You choose a name for it and check
 what way it should spread. Then press build and it will
 generate delphi source code for you.

 This source code can easily be changed in any way you want
 and you can also learn and see how it is made.

 This program is not made for any illegal use or abusement
 of other peoples systems.

 And what i always wonder when i see a WormGen is :
 "That shit has to be backdoored, all wormgens is".
 Check this how much you want, you wont find any backdoor
 there is none. I love worms to much for killing em 
 with lame backdoors.

 -------------------

 Made by p0ke

 WARNING!
 This should have been downloaded from 
 www.imafraid.com (or any link p0ke gives) else
 its not garanteed to be clean!