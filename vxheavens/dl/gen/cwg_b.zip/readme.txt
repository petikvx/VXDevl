C++ Worm Generator beta
by Retro

9th May 2004

When you make the virus, it will appear in the c:\ folder.
This is only a taster of the final version

http://retro.host.sk
www.indovirus.net
www.rrlf.de
