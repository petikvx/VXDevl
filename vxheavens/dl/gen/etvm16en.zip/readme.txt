This is the ReadMe for El-Trucha's Virus Maker.

Descriptions of the files:
===========================
virusmkr.bat - The program.

autoexec.bat - The Autoexec.bat that will be replaced with the one that has the format command.

bat2exe.com - The compiler, BAT2EXEC. Much thanx 2 the author!!! ;)

CHOICE.COM - the DOS Choice command, I included this because it doesn't come with Win2k/XP, the only OS's that will run this program.

readme.txt - This file.

changelog.txt - The program's ChangeLog.


Usage:
===========================
Here's the files for each OS:

DOS:
autoexec.bat
command.com

Windows 3.x/9x/Me:
autoexec.bat
command.com
win.ini
win.com

Windows NT/2k/XP (maybe 2k3 and Longhorn, but I'm not sure...)
boot.ini
NTLDR

And the usage of the program...pretty simple...just click on Enter for Next, 1 for Yes, and 2 for No.