-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

           -Class Macro Kit v1.0 beta-

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Hejos folks,

Welcome  to my newest creator. This is only  the beta
but I hope you like  it.  Please  mail me if you find 
any bugs. Ok  about the  kit:  It  contains a special
kind of polymorphic  engine  called  PiE which can be
added to every class macro. You can also choose  from
several options of the engine to modify it's  actions
Hmm...the payloads where taken from my tutorial about
VBA payloads in LineZer0's zine issue #1.  Ok think I
have  talked  enough about the kit so start  and have 
phun!

-jackie twoflower/LineZer0/Metaphase-

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Thanks and greets:

-Slagehammer		- Thanks Slage, without you I
			  would be nothing!
-VicodinES		- Wherever you are, you are 
			  the greatest coder ever!
-HeXcrasher		- How is life?
-f0re			- Hope our new crew will work
-Darkman		- Kiss! When will we start?
-Serialkiller		- Mail me about the viewer!
-Lord_Arz		- What about the planters?
-Knowdeth		- Metaphase#2 ???
-Fletcher		- Thanks for everything bro!
-Gigabyte		- Thanks & greets for you!
-The Might		- Code that macro!
-Tally			- Thanks for everything
-Blackjack		- Tatata
-Zer0			- What up my man?
-Ruzz			- 'Ruzz rules the world!'
-Spo0ky			- Greets!

-All ppl on UNDERNET

-LineZer0 Network
-Metaphase VX Team
-Dutch Virii Community
-Codebreakers
-Cybernetic Crew
-Ultimate Chaos
-Kefrens
-VTC
-3c
-NoMercy Virus Team
-NuKE
-29A

-Also all ppl I forgot...sorry...you know who you are!

-And of course to you for using CMK!


Have phun,

-jackie twoflower/Lz0NT/MVT-

jack.twoflower@disinfo.net

DO NOT SPREAD VIRII! THIS KIT IS FOR EDUCATIONAL PURPOSE ONLY!
