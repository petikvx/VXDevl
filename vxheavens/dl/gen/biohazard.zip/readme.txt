+-<Bio Hazard Worm Generator v1.00>-+
|      coded by MadDogg187          |
|     � 2001 Murder-System          |
+-----------------------------------+

Underground Dogg Soliderz
WebPage: http://www.murder-system.com
Email  : assassinno187@hotmail.com
ICQ UIN: 95389922
