~~~~~~~~~~~~~~~~~~~~~~~~~
    p0kes WormGen 2.0    
 why re-invent the wheel
~~~~~~~~~~~~~~~~~~~~~~~~~

What the fuck is this ?
-----------------------

 This wormgenerator generates open source code
 worms. Its not that much to explain.
 The generator has following options:
  o Mass-mail
   o Gather Mails from txt, vbs, htm, html
   o Gather Mails from Choosen files
   o Use found textfiles as subject/body
   o Choose subject/body
 
  o Network (local) spread
  o Share-Dir drop
  o IrcBot
  o Irc-Script drop
 
  o Undetectable-Try mode

Then What the fuck does it mean ?
---------------------------------

 1. Mass-mail i think everyone knows,
    so i aint gonna explain that.

 2. Network Spread:
    The worm will search computers in lan
    and try to copy itself to their C$

 3. Share-Dir drop:
    You will have to choose what dirnames
    the worm shall search after.
    Example is :
     If find dir "Share" then drop "Setup.exe"

 4. IrcBot :
    Just a simple ircbot with download ability

 5. Irc Script Drop :
    If it finds Script.ini it will overwrite
    with a own modified irc-script

 6. Undetectable-Try mode :
    This will take alot of more time to generate
    source. This makes all variables randomized
    which in some cases can bring undetectables.
    Its not a recommended choice if u need fast
    generated worms. But worth a try when u got time.

So, Why do i need this ?
------------------------

 Well, i didnt say you need it. It was you who
 downloaded it.
 This is good for studing worms, educational purpose only.
 

Who made this shit ?
--------------------

 p0ke, or as some people know me, Sic.
 Took me .. a week maybe to make it.

Wanna whine, complain and be a bitch?
-------------------------------------

 Mail me at soultrapped@hotmail.com
