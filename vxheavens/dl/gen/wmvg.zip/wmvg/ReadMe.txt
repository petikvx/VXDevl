The WalruS Macro Virus Generator (WMVG)

The WalruS Macro Virus Generator Is A Easy To Use Virus Creation Kit For Word 97/2K. WMVG Is AutoRun When The Document WMVG.doc Is Opened In Word. 

Currently WMVG Has The Following Virus options.

Infection Hook : Open Or Close
Infection Routine : String Copy Or Import/Export To File
Stealth : On Or Off
Add Random Noise : On Or Off
mIRC Worm Spreading : On Or Off 
VBS Backup : On Or Off
Payloads: None, Message Box, CD Tray, Kill Document, Hiccups, Colours, Assistant Message, Plugin Your Own,
Payload Trigger : On Infection Hook, By Date, Random, 
Create Source Code : On Or Off
WMVG Creates Viruses With Random Variable Names Upon Each Run. Random Noise Can Also Be Added.

In Addition There Are Text Boxes For Virus Author, Virus Name And Virus Comments (Not critical).

Every Option Has An Associated Help Button Providing A Help Message Box

Viruses And Source Are Created In C:\My Documents

In Addition To Making Viruses WMVG Also Has An Extras Screen. Here There Are The Following Options.

Contact The WalruS : Mail, Web Page, IRC
Greets : My Pals 
Drop A WalruS Virus : Fools Gold, Puny, LSD, Furio

Scattered Throughout The WMVG Are Secret And Hidden Bits Of Information (Just For Fun)


In Future WMVG Will Be Updated To Include More And Different User Options.

WMVG Was Designed, Written And Tested On Word 2K. If You Spot A Bug Of Any Kind Please Inform Below. Please

WMVG Fonts Are Comic Sans MS Which  Is Part Of Office Installation. Should The WMVG Text Look Incorrect Then Ensure That The Font Is Present In The C:\Windows\Fonts Folder. If It Is Not Then The Font Is Provided With WMVG In The Folder Labelled Font

For Any Comments, Questions Or Bugs Contact WalruS Direct Below.

WalruS@Z.com
http://www.WalruS.8k.com