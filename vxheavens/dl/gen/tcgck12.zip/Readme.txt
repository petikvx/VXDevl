
 // ###################################################################### \\
 // #    The Czybik Gen Virus Construction Kit v1.0                      # \\
 // #                                                                    # \\
 // #     �2006 by sk0r alias Czybik                                     # \\
 // #                                                                    # \\
 // # Visit www.sk0r-scripts.tk & www.sk0r-virii.tk & www.czybik-kit.tk  # \\
 // #                                                                    # \\
 // ###################################################################### \\
 
 
This is a Virus Creation Kit (Vck) to create own Worms. It creates
Visual Basic Script Worms. It hast much features as following:

Version 1.0 :
==============

First Settings Block:
---------------------

- Input Author name
- Input Worm Name
- Input Filename
- Input Fake and real Extension

Second Settings Block:
-----------------------

- E-Mail Spreading
- P2P-Spreading
- Steam Client Spreading
- mIRC Spreading
- Gamers.Irc Spreading
- Network Share Spreading

Third Settings Block:
----------------------

- Backups of the worm
- Startup Methods
- Specific Reg Changes
- Other Values

Fourdth Settings Block:
-----------------------

- Activation of Payload
- Infect file method
- Show message method
- Format drives method
- Delete systemfiles method


Usage: Simply run the tcgck.exe and select options you want the worm have to.
       Then press the generate button and the worm will be created in the
	   directory where the tcgck.exe exists. Then your worm is useable.


DISCLAIMER: BY USING THE TOOL AND GENERATING A WORM YOU AGREE AUTOMAITCALL THAT THE AUTHOR OF THE
            TOOL ("sk0r alias Czybik") IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED BY THE TOOL OR BY
			A GENERATED WORM. ALSO YOU AGREE THAT YOU WILL NOT SPREAD THE WORM IN THE WILD.
			YOU ARE RESPONSIBLE FOR WHAT YOU ARE DOING WITH THE GENERATED WORMS. YOU ARE NOT
			ALLOWED THO DECOMPILE, DISASSEMBLE OR ANYTHING, LIKE THE TOOL. YOU MAY DISTRIBUTE
			THE TOOL ON YOU WEBSPACE BUT ONLY IF YOU DONT MODIFY THE TOOL, THE README AND
			ANYTHING ELSE. YOU MAY TEST THE WORMS ON A CLOSED SYSTEM.
			
			
			
Changelog:
===========

Version 1.2:
-------------------
- Fixex the Bookmark, Link and Pc Info Send Bug
- Fixex some quote Bugs
- added polymorphic Engine

Version 1.1:
------------
- Changed the 'About' Dialog
- Fixed some quote Bugs
- added spreading copying worm in folders with special chars
- added choosing icon and title of messagebox 
- added choosing title and color of batch mesage
- added more regvalues to the 'specific reg changes' feature

Version 1.0:
-------------
The whole Tool in its version
with the functions.



More functions will appear! But that takes time.
To give me some ideas you can E-mail me @ sk0r1337@gmx.de
If you have good ideas, I will add them and give you
some credits in the About Dialog.



 ================================================================================
 =The Czybik Gen Creation Kit �2006 by sk0r alias Czybik | All rights reserved ^=
 ================================================================================