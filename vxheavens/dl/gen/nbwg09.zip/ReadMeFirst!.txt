                -----README-----

+++/////////////////////\\\\\\\\\\\\\\\\\\\+++
+++//		  NEWBORN		 \\+++
/////					 \\\\\
/////	W      	W 0000 RRRR M	M	 \\\\\
/////	 W  W  W  0  0 RRRR MM MM	 \\\\\
/////	  WW WW	  0  0 R R  M M M	 \\\\\
/////	  W   W   0000 R  R M	M	 \\\\\
/////					 \\\\\
/////		 GENERATOR		 \\\\\	
/////					 \\\\\
+++//By Beebs AKA -NicX-		 \\+++
+++/////////////////////\\\\\\\\\\\\\\\\\\\+++


	*FOR EDUCATIONAL PURPOSES ONLY*


The Newborn Worm generator v0.8 can create
versions of the Newborn P2P Worm.

Contents of this .ZIP archive:
==============================
-Readme.txt
-Newborn Worm Generator.exe
-Compiler.vbs

This archive should be approximatley 30700 bytes, 
if not it may be corrupt or modified

N.B. With some Anti-Virus products, (Norton 2000)
the Compiler may be detected as a malicious script.
It is absolutely harmless. It is detected because it
uses the GetFile command line of FileSystemObject in
Visual Basic Script (the language it is written in)
to be able to find the Source file. This "GetFile" 
may be detected as malicious. I will say it again, 
it is ABSOLUTELY HARMLESS.


Functions Are:
==============
-Infecting Kazaa Shared Folder
-Infecting ]\WINDOWS\System\] Directory
-Attempting to delete Norton AV 2000 files
-Creating a new directory on drive [C] named
 'WORMED!'

Variables defined by user:
==========================
-Virus name
-Creator name
-Kazaa name (Name of the file when it is dropped
 to Kazaa Shared Folder, in FILENAME.mp3.vbs format

To create a Worm:
=================
--Run "NewbornWormGenerator.exe"
--Choose "Create Worm". This will create your customised
  source code at location (C:\myworm.txt)
--Open Source code text file using word editor i.e. Notepad
--IMPORTANT---->Replace all ' with " <----IMPORTANT
--Save text file, do NOT rename it or change directory
--Run "Compile.vbs". This will create MyWorm.vbs from the
  source code
--MyWorm.vbs is the finished Worm. At this point, rename it
  to whatever you want.

Disclaimer:
===========
By using this program, your agree that -NicX- cannot
be held responsible for any damage that may arise
from using this program. All programs from -NicX- are
provided as-is, with no support available. You may freely
distribute this archive, but only if it is in its original
form. Do not modify any of the files it contains.

Contact:
========
I appreciate feedback! Please send to nicx@hotmail.com
Do NOT send files
Do NOT ask me how to write virii
Do NOT ask me how to hack

That seems about it.
Thanx, and have Phun!


