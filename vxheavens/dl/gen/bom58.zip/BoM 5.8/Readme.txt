
 BATCH-O-MATIC - By SAD1c

 For any kind of question, comments or suggests, e-mail: sad1c@interfree.it
 For new versions or other programs, surf: http://sad1cpage.supereva.it
_______________________________________________________________________

 Informations:
 - Author: SAD1c
 - Version: 5.8
 - Release Date: 07/03/2003
 - Description: BATCH-O-MATIC is a C++ written batch virus generator.
   It generate worms that (also using WSH) infect files, spread through
   internet and use lots of interesting payloads and techniques...
_______________________________________________________________________

 Important Notes: This Software is for educational purposes only.
                  You cannot use this Software for making any kind of
                  Damage at people or things.
_______________________________________________________________________

 Addictional Notes: If YOU are a LAMER or a SCRIPT KIDDIE, GET OUT
                    OF THIS PROGRAM, and remember that MAKE DAMAGE
                    to the others ONLY FOR FUN is a BIG BULLSHIT!!