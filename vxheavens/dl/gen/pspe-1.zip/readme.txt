This is Just an simple Script Poly Engine that has been added in MVBSWE-8
Will changes file body with 3 type Polymorphsm,I'm lazy to teach you kids
understand it By ur self you know that I'm the most fuckin lazy person in
da world :P