Razorblade's Batch Virus Generator v1.1
(c) 2005 by Razorblade
http://www.razorcenter.de.vu
=======================================

This is my first VCK I have coded! I know that Batch-Virii are very lame, but I have coded this VCK to learn Visual Basic and improve myself! 
This VCK is written in VB, so, you see .....


Anyway .... have fun! ;)


Change log v1.1:
====================
- Fixed infection routine
- Fixed tooltips
- Added disclaimer
- Added lame set-encryption ^^
- Packed with UPX

Comments to:
razor.hacks@gmx.net


