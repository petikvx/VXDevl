The VicodinES Class.Poppy Construction Kit
---version 1.0a

Some quick notes:

If for some reason you have code you need stored in Item(1)
then please save it or back it up because this kit will also
act as a Class Anti-Virus for your normal.dot. If you have
an infection or get an infection in your normal.dot CPCK will
clean it by default.

Hidden things?

There is only one hidden thing - it is easy to find.

More versions?

As with VMPCK there may be other versions. If you have feedback,
bug reports or comments you can send them to vic@sourceofkaos.com.

----------------------

Dedication:

This kit is dedicated to my #1 fan Chris Stubbs. He loves me so much
that he nicked some of my Class.Poppy code for his AV product. How do
I know? It's the only VBA code in his whole horrible up-converted
Word basic mess.

I also dedicate this kit to those at NAI who also nicked my code for
their Class.Poppy stand alone cleaner. 

In both cases they used the SAME variable names that I did for code.
When do I get paid for this????

oh and ummm.... hey NAI,

==start==

Network News -- Network Associates falls foul of a virus

In a spectactular marketing blunder, anti-virus vendor Network Associates
has sent out an email infected with a Word macro virus.

The WM97/Class.B virus which appeared in a press release for CyberCop
Scanner 2.5, is relatively new, according to rival vendor Sophos. One of 
it's effects is to display the message "I think [name] is a stupid jerk" 
on certain days.

"There are 500 new viruses a month. It's always a challenge, these things 
can happen," says Caroline Kuipers, a spokesperson for Network 
Associates. The virus was not detected because the sender didn't have the 
latest a/v updates.

IT lawyer Dai Davis, a consultant at Nabarro Nathanson, said. "The law 
says you can't send a virus and then give advice on disinfection".

Davis also added that NAI's actions were an offence under the 1990 
Computer Misuse Act, carrying up to 5 years' imprisonment.

==end==