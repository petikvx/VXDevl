TVBSG Visual Basic Script worm generator
========================================

Copyright (C)2000-2001, Tomoiaga Cristian

For any problems, questions etc, please email
tomas@email.ro

Non-Exclusive License Agreement
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	TVBSG is freeware. This means:

	- All copyrights to TVBSG are exclusively owned by the author - 
	  Tomoiaga Cristian
	- Anyone may use this software, free of charge, in any environment. 
	- TVBSG may be freely distributed, provided the distribution
          package is not modified. No person or company may charge a fee
	  for the distribution of TVBSG without written permission from
	  the copyright holder. 
	- TVBSG is distributed "as is". No warranty of any kind is expressed
	  or implied. You use this software at your own risk. The author will not
	  be liable for data loss, damages, loss of profits, or any other kind of
	  loss while using or misusing this software.
	- You may not use, copy, emulate, clone, rent, lease, sell, modify,
	  decompile, disassemble, or reverse engineer TVBSG.
	- All rights not expressly granted here are reserved by Tomoiaga Cristian
	- Using TVBSG signifies acceptance of the terms and conditions
	  of this license. If you do not agree with the terms of this license
	  you must remove TVBSG files from your storage devices and cease
	  to use the product.
        - YOU MUST AGREE THAT TOMOIAGA CRISTIAN IS NOT RESPONSIBLE IN
          ANT WAY FOR ANY DAMAGE CAUSED BY FILES CREATED WITH THIS
          PROGRAM TO ANYTHING !! 

        Tomoiaga Cristian
        eMail : tomas@email.ro


TVBSG History
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[ TVBSG v1.0beta: ]
- the first version of TVBSG.
waiting/searching for bugs 



 Visual Basic� and VBScript� is are products and a trade marks of Microsoft� Corp.