~~~~~~~~~~~~~~~~~~~~~~~~~
    p0kes WormGen 2.1   
 True way to make a worm
~~~~~~~~~~~~~~~~~~~~~~~~~

********************************************************************************
********************************************************************************
WARNING!
NOTE TO ALL NEWBIES, AND ALL PEOPLE THAT DOESNT KNOW WHAT OPEN SOURCE MEANS.
THIS GENERATOR WILL GENERATE A *.DPR FILE (DELPHI PROJECT) AND YOU WILL HAVE
TO COMPILE IT USING ANY DELPHI VERSION. RECOMMENDED DELPHI 6 ENTERPRISE.

DONT MAIL ME ABOUT "WHAT IS DELPHI" "HOW TO COMPILE" ETC. IM SICK OF THAT.
THANKS.
********************************************************************************
********************************************************************************

What the fuck is this ?
-----------------------

 This wormgenerator generates open source code
 worms. Its not that much to explain.
 The generator has following options:
  o Mass-mail
   o Gather Mails from txt, vbs, htm, html
   o Gather Mails from Choosen files
   o Use found textfiles as subject/body
   o Choose subject/body
 
  o Network (local) spread
  o Share-Dir drop
  o IrcBot
  o Irc-Script drop

  o Visit site, for counters.
  o Time execution, for delay execution of worm.
  o DDoS Homepages, for taking down fbi.gov
  o Mass WebDownloader, download how many files you want
  o Autostart, works on all windows versions
 
  o Undetectable-Try mode

Then What the fuck does it mean ?
---------------------------------

 1. Mass-mail i think everyone knows,
    so i aint gonna explain that.

 2. Network Spread:
    The worm will search computers in lan
    and try to copy itself to their C$

 3. Share-Dir drop:
    You will have to choose what dirnames
    the worm shall search after.
    Example is :
     If find dir "Share" then drop "Setup.exe"

 4. IrcBot :
    Just a simple ircbot with download ability

 5. Irc Script Drop :
    If it finds Script.ini it will overwrite
    with a own modified irc-script

 6. Undetectable-Try mode :
    This will take alot of more time to generate
    source. This makes all variables randomized
    which in some cases can bring undetectables.
    Its not a recommended choice if u need fast
    generated worms. But worth a try when u got time.

 7. Visit Site :
    This is for making the worm, every time it get
    runned, to visit a site. Good for keeping tracks
    on your worm.

 8. Time Execution :
    Good for delayed execution, example when binded
    to a software. Makes it all lesser suspicious.

 9. DDoS Homepage :
    This will send a /GET Request 1000 times sec.
    This will not be noticed if you only do it with
    a worm, you need more then 10.

 10.Mass WebDownload :
    Download alot of files, instead of send em all
    at the same time. Good for lazy people.

 11.Autostart :
    This is only singel api-call that works on all
    windows versions.
    On 9x it will write "Shell=Explorer.exe Filename.exe"
    to System.ini.
    On NT it will write "Shell" "Explorer.exe Filename.exe"
    under HKLM\Software\microsoft Nt\logon

So, Why do i need this ?
------------------------

 Well, i didnt say you need it. It was you who
 downloaded it.
 This is good for studing worms, educational purpose only.
 

Who made this shit ?
--------------------

 p0ke, or as some people know me, Sic.

Wanna whine, complain and be a bitch?
-------------------------------------

 Mail me at soultrapped@hotmail.com
 Visit www.fjun.com/badboll for updates.
