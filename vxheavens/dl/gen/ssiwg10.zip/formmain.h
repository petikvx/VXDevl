//---------------------------------------------------------------------------
#ifndef formmainH
#define formmainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFormWorm : public TForm
{
__published:	// IDE-managed Components
        TPanel *PanelTitulo1;
        TPanel *PanelTitulo2;
        TPanel *Panel3;
        TPanel *Panel4;
        TRadioGroup *RadioGroupIdioma;
        TButton *BotaoSair;
        TPanel *PanelTitulo3;
        TGroupBox *GroupBox1;
        TLabel *LabelWormName;
        TEdit *EditWormName;
        TLabel *LabelSubject;
        TEdit *EditSubject;
        TEdit *EditMessage;
        TLabel *LabelMessage;
        TCheckBox *CheckCrypt;
        TCheckBox *CheckNetwork;
        TButton *BotaoCriar;
        void __fastcall Panel3Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall RadioGroupIdiomaClick(TObject *Sender);
        void __fastcall BotaoSairClick(TObject *Sender);
        void __fastcall BotaoCriarClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormWorm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormWorm *FormWorm;
//---------------------------------------------------------------------------
#endif
