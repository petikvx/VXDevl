//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("ssiwg.res");
USEFORM("formmain.cpp", FormWorm);
USEUNIT("geraworm.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TFormWorm), &FormWorm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
