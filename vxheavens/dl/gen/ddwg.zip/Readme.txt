dav's delphi w0rm gen

Note:
The author is not responsible for anything you do or the tool does!
Virus spreading is illegal in most of the countries but learning isnt!

Bla:
dav's delphi w0rm gen generates open source delphi w0rms! :)
The w0rm srcs should run @ D7+...

Features:
+ hardcore var changing
+ add w0rm to win regestry
+ copy2kazaa sharing folder
+ copy2known p2p folders
+ copy2IIS webserver wwwroot
+ add icon c0de string
+ add w0rm c0de documentation




