EASY ANSI BOMB CREATOR v1.0
---------------------------


Running EASY ANSI BOMB CREATOR in Windows
-----------------------------------------

Just double click on EABC10.EXE and it will start.


Running EASY ANSI BOMB CREATOR in MS-DOS
----------------------------------------

Just type EABC10.EXE at the command prompt and hit enter.
But make sure EABC10.EXE is in the current directory.


Using EASY ANSI BOMB CREATOR
----------------------------

After running the program answer the questions and before
you know it you have a ANSI Bomb. Easy enough !


Information on EASY ANSI BOMB CREATOR
-------------------------------------

This file and its update can be downloaded at http://thebestvck.cjb.net/
or you can email me at SAH174@Hotmail.com for errors or questions or comments.