Hye.. this is FetiopVer3.0.A Upgrade..
a number of bugs have been fixed...
ok have fun of encryption.....
                              -Lasiaf-
try to invert colour ;p

for any comments or bugs report please 
e-mail :Cracker0012002@yahoo.com
       :aidaayuni@hotmail.com



