                  "INVICTUS" VX Library - by Weendigo[MATRiX]
                  ~~~~~~~~~~~~~~~~~~~~~
   I really don�t know why am I doing this library, maybe bcz
my girl leave some months ago, or bcz my ganja ends, world sux,
ppl die by hungry, Abraham Lincon was a fag, McVeigh is dead,
Bush wants to suck my dick everyday...

   Fuck reasons...let�s code!

   First release - 05/08/2001
   Current Functions:

   _open_read
   _open_create
   _open_write
   _close_file
   _infect_file (not fully working)

   Second release - 12/08/2001
   Current Functions:

   _open_read
   _open_create
   _open_write
   _close_file
   _infect_file
   TempPath

   Release 1.00 - 19/08/01

   Added functions:

   Pack
   Depack
   procB64encode
   procB64decode

   You can make this library better sending comments about new
functions that should be implemented in the future, and
reporting bugs.
   All coded in ASM

   PS: To use this shit by your own hands.

   URL:

   http://www.coderz.net/mtxvx
   http://www.nbk.hpg.com.br

   Email:

   nbk_vx@starmail.com