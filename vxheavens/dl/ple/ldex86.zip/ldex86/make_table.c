#include<stdio.h>
#include<windows.h>


int main(int argc, char **argv){
       FILE *fout;
       int i;
       BYTE num = 0;
       if (argc !=2){
              printf("Pass some arguments\n");
              return 0;
       }
       fout = fopen(argv[1], "w");
       
       for (i=0; i <= 0xFF; i++){
              fprintf(fout, "/* %.2X */, 0\r\n", num);
              num++;
       }
       fclose(fout);
       return 0;
}       
        
