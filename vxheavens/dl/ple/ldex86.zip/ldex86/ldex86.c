/*
  LdeX86 (Length disassembler engin for X86)
     deroko <deroko<at>gmail<dot>com>
     http://deroko.headcoders.net
  
  Currently it can handle 1/2 byte long opcodes and FPU. 
  Table and algo for them are available. It is not complete, I have spent only 1 day
  working on it and making instruction table. There are many working lde's for x86
  such as z0mbie's LDE32, uNdErX's mlde32, and roy 'g' biv's RGBLDE.
  This code is simple to understand and that's the only reason why I have posted it.
  I'm currently working to implement all instructions in it, and to transfer it eventually
  to asm (bcc32 -S rulz)

Update:
  Instruction tables reduced to BYTE instead of DWORD...
  
Update:
  All FPUopcodes start with 11011 and are folowed by modrm so process 'em like any
  other modrm opcode :)

Update:
  It handles operand - prefix and address prefix (0x66 and 0x67 prefixes), I hope that
  they are handled in right way, if not, le'me know how to handle them in correct way. 
  It handles some extended opcodes (2-byte-long) that I have included in my table_2,
  actually I have spent 2 hours reading IA32 manula Volume2 and storing them in da table.
  
  I have used z0mbie's lde32 as reference (just for cool table organazing), everythig
  else is made by me (feeling tables, making algo to decode opcodes)...
  FPU instructions ain't included yet, but they will be some day, when I find time to 
  finish this engine.
  
Further development:
  change engin from C/C++ to asm
  
                                                 deroko <deroko<at>gmail<dot>com>
                                                 http://deroko.headcoders.net
*/

#include<windows.h>
#include<stdio.h>

#include "decoder.h"

DWORD  disassembler(BYTE *);

int main(){ 
       DWORD i, j,  size;
       BYTE *memptr, *tempptr, *address, *p;

       printf("\nLdeX86 - Length Disassembler engin X86\n\n");
       printf("             deroko <deroko<at>gmail<dot>com>\n");
       printf("             http://deroko.headcoders.net\n");
       printf("\npress enter to start \n");
       getchar();
       
       address = (unsigned char *)GetProcAddress(LoadLibrary("kernel32"), "VirtualAllocEx");
       
       for (i = 0; i < 50; i++){ //changi this to decode more instructions
              size = disassembler(address);
              p=address;
              for (j=0; j<size; j++)
                    printf("%.2X ", p[j]);
              printf("\n");            
              address = address + size;
          }
       printf("press enter to exit\n");
       getchar();
       ExitProcess(0);
       return 0;
}


DWORD disassembler(BYTE *startaddress){
       BYTE opcode, *p, tempopcode,instruction;
       int size;
       int opsizeprefix = 0, addressprefix = 0;
       size = 0;
       p=startaddress;
       opcode=*p;
       //Proces PREFIXES!!! if any...
       prefix_loop:    
              if (table_1[opcode] == C_PREFIX){
                     if (opcode == C_66)
                            opsizeprefix = 1;
                     if (opcode == C_67)
                            addressprefix = 1;
                     size++;
                     p++;
                     opcode=*p;
                     goto prefix_loop;
              }
            //check for test, stupid and fucking test
       instruction = table_1[opcode];
       if ((opcode == 0xF6) || (opcode == 0xF7)){
              opcode=p[1];
         if ((opcode & 0x38) != 0)         //test or neg/not...
                     instruction = C_MODRM;
              
       }
       if (opsizeprefix)
              //where was 8 still is 8 //where was 32 now is 16
              if (instruction & C_DATA32){
                     instruction &= ~(C_DATA32);
                     instruction |= C_DATA16;
              }
       if (addressprefix){
                     instruction &= ~(C_DATA32);
                     instruction &= ~(C_DATA8);
                     instruction |= C_DATA16;
              }
       //fill instruction with flags from table_2 and decode it in right way
       if (instruction == C_2BYTE){
                  size += 1;
                  p++;
                  instruction = table_2[*p];
                  //if (instruction == C_DATA32)
                  //   size += 5;
                  //goto check_modrm;   
       }       
       if (instruction & C_SIZE1)
                  size +=  1;       
       if (instruction == (C_DATA8 + C_DATA16)) //such as enter,16,0 for example
                  size +=  4;
       if (instruction == (C_DATA16 + C_DATA32)) //far jmp, far call
                  size +=  7;
       if (instruction == C_DATA32)
                  size +=  5;
       if (instruction == C_DATA8)
                  size +=  2;
       if (instruction == C_DATA16)
                  size +=  3;
check_modrm:
       if (instruction & C_MODRM){
                  unsigned char modrm;
                  size += 2;
                  p++;
                  modrm = *p;
                  if ((modrm >> 6) == 0 && (modrm & 0x07) == 0x05) //modrm is folowed by 32disp
                            size+=4;
                                                    
                  if ((modrm >> 6) != 3 && (modrm & 0x07) == 0x04){   //sib
                     size++;
                     if ( (modrm >> 6) == 1 && (modrm & 0x07) == 0x04) //8bit disp after SIB(added to index)
                            size++;
                     if ( (modrm >> 6) == 2 && (modrm & 0x07) == 0x04) //32bit displacement after sib(added to index)             
                            size += 4;
                    } //SIB processing
                  ////////////////TEST CODE//////////////////
                  if (modrm >= 0x40 && modrm <= 0x7f && (modrm & 0x07) != 0x04)
                            size +=1;
                  if (modrm >= 0x80 && modrm <= 0xbf && (modrm & 0x07) != 0x04)
                            size +=4;                            
                  ///////////////TEST CODE///////////////////   
                  if (instruction & C_DATA32)  //is this opcode opcode modrm immdata ???
                          size +=4 ;
                  if (instruction & C_DATA8)
                          size++;
                  if (instruction & C_DATA16)
                          size+=2;        
                     
       }
       
       if (instruction == C_UNKNOWN)
                  size += 1;
                  
       return size;
}

 