// Str.cpp : Defines the entry point for the console application.
//
//This file contains string function realization
#include <stdarg.h>
int strlen(const char* Str1)
{
	int i=0;
	while (Str1[i]!=0)
	{
		i++;
	}
	return i;
}


int strcpy(char* Str1,const char* Str2)
{
	int b = strlen(Str2);
	for (int i=0;i<=b;i++)
	{
		Str1[i]=Str2[i];
	}
	return (int)Str1;
}

int strcmp(const char* Str1,const char* Str2)
{
	if (strlen(Str1)==strlen(Str2))
	{
		for (int i=0;i<=strlen(Str1);i++)
		{
			if (Str1[i]!=Str2[i]) return 1;
		}
		return 0;
	}
	return 1;
}

int strcat(char *Str1,const char* Str2)
{
	Str1 = (char*)((int)Str1 + (int)strlen(Str1));
	for (int i=0;i<=strlen(Str2);i++)
	{
		Str1[i] = Str2[i];
	}
	return (int)Str1;
}

int memset(void* Data,int Filled,int Size)
{
	for (int i=0;i<Size;i++)
	{
		((char*)Data)[i] = Filled;
	}
	return (int)Data;
}

char* ToHex(char* Buffer,int Number)
{
	int j=7;
	for (int i=0;i<4;i++)
	{
		char x = ((char*)&Number)[i];
		char x1 = x & 0x0f;//������� �����
		if (x1>=0x0 && x1<=0x9)
		{
			x1 = x1 + 0x30;
		}
		else
		{
			x1 = x1 + 0x37;
		}
		Buffer[j] = x1;
		j--;
		unsigned char x2 = ((char*)&Number)[i];
		x2 = x >> 4;//������� �����
		x2 = x2 & 0x0f;
		if (x2>=0x0 && x2<=0x9)
		{
			x2 = x2 + 0x30;
		}
		else
		{
			x2 = x2 + 0x37;
		}
		Buffer[j]=x2;
		j--;
	}
	Buffer[8]=0;
	return Buffer;
}

int sprintf(char *Buffer,char* Format,...)
{
	va_list vl;
	va_start(vl,Format);
	int j=0;
	for (int i=0;i<=strlen(Format);i++)
	{
		if (Format[i]!='%')
		{
			Buffer[j]=Format[i];
			j++;
		}
		else
		{
			i++;
			if (Format[i]=='s')
			{
				char* Str = va_arg(vl,char*);
				strcpy(&Buffer[j],Str);
				j = j+strlen(Str);
			}
			else
			if (Format[i]=='X')
			{
				int x = va_arg(vl,int);
				char Buffer2[3];
				ToHex(Buffer2,x);
				strcpy(&Buffer[j],Buffer2);
				j = j + strlen(Buffer2);
			}
		}
	}

	return 0;
}