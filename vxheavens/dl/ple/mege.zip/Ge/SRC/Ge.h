//D�finitions des types DWORD, WORD et BYTE
typedef unsigned long  DWORD;
typedef unsigned short WORD;
typedef unsigned char  BYTE;

#define DEBUG

//Prototypage des fonctions
DWORD Ge_Main(DWORD Options,
              BYTE *pGene1,
              BYTE *pGene2,
              DWORD iSizeOfGene1,
              DWORD iMutationRate,
              DWORD iCrossOverRate,
              DWORD iMutPacketSize,
              DWORD iCrossPacketSize,
              DWORD iRndNumber,
              DWORD iSeed,
              DWORD iPrimeNumber1,
              DWORD iPrimeNumber2
             );

void CrossOver_Gene(BYTE *pGene1,
                    BYTE *pGene2,
                    DWORD iSizeOfGene1,
                    DWORD iCrossOverRate,
                    DWORD iPacketSize,
                    DWORD *iSeed,
                    DWORD iPrimeNumber1,
                    DWORD iPrimeNumber2
                   );

void Mutate_Gene(BYTE *pGene,
                 DWORD iSizeOfGene,
                 DWORD iMutationRate,
                 DWORD iPacketSize,
                 DWORD *iSeed,
                 DWORD iPrimeNumber1,
                 DWORD iPrimeNumber2
                );

void Create_Gene(BYTE *pBuffer,
                 DWORD iSizeOfBuffer,
                 DWORD *iSeed,
                 DWORD iPrimeNumber1,
                 DWORD iPrimeNumber2
                );

BYTE Hash(DWORD Data,
          DWORD iRndNumber
         );

DWORD RndNumberGenerator(DWORD *iSeed,
                         DWORD iPrimeNumber1,
                         DWORD iPrimeNumber2
                        );

DWORD RndSeed(DWORD iRndNumber,
              DWORD iPrimeNumber1,
              DWORD iPrimeNumber2
             );

