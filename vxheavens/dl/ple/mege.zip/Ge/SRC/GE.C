
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
// GE - Genetic Engine
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////

#include "Ge.h"

#ifdef DEBUG
  int main()
  {
    return 0;
  }
#endif

//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
//
// (DWORD)Ge_main(DWORD Options,
//                BYTE *pGene1,
//                BYTE *pGene2,
//                DWORD iSizeOfGene1,
//                DWORD iMutationRate,
//                DWORD iCrossOverRate,
//                DWORD iMutPacketSize,
//                DWORD iCrossPacketSize,
//                DWORD iRndNumber,
//                DWORD iSeed,
//                DWORD iPrimeNumber1,
//                DWORD iPrimeNumber2
//               )
//
//
// Param�tres:
// -----------
//
// DWORD Options          --> options
// BYTE *pGene1           --> pointeur sur le d�but d'un buffer contenant un g�ne
// BYTE *pGene2           --> pointeur sur le d�but d'un deuxi�me g�ne (facultatif)
// DWORD iSizeOfGene1     --> taille du g�ne point� par pGene1
// DWORD iMutationRate    --> nombre d'octets � muter par groupe (facultatif)
// DWORD iCrossOverRate   --> nombre d'octets � permuter pa groupes (facultatif)
// DWORD iMutPacketSize   --> taille des groupes (facultatif)
// DWORD iCrossPacketSize --> taille des groupes (facultatif)
// DWORD iRndNumber       --> nombre quelconque choisit par l'appelant
// DWORD iSeed            --> graine (facultatif)
// DWORD iPrimeNumber1    --> grand nombre premier (facultatif)
// DWORD iPrimeNumber2    --> grand nombre premier (< iPrimeNumber1) (facultatif)
//
// Retourne 0 si pas d'erreurs, 1 sinon.
//
// Remarques:
// ----------
//
// Options disponibles:
//
//       a. 0 cr�er un nouveau g�ne
//
//       b. 1 utiliser un g�ne existant (point� par pGene1) et appliquer des mutations
//
//       c. 2 utiliser un g�ne existant (point� par pGene1) et appliquer un crossing-over
//            avec un g�ne n�2 (point� par pGene2)
//
//       d. 3 utiliser un g�ne existant (point� par pGene1) et appliquer un crossing-over
//            avec un g�ne n�2 � cr�er (buffer point� par pGene2)
//
//       e. 4 utiliser un g�ne existant (point� par pGene1) et appliquer des mutations
//            puis appliquer un crossing-over avec un g�ne n�2 (point� par pGene2)
//
//       f. 5 utiliser utiliser un g�ne existant (point� par pGene1) et appliquer
//            un crossing-over avec un g�ne n�2 (point� par pGene2) puis appliquer
//            appliquer des mutations au g�ne point� par pGene1
//
//       e. 6 utiliser un g�ne existant (point� par pGene1) et appliquer des mutations
//            puis appliquer un crossing-over avec un g�ne n�2 � cr�er (point� par pGene2)
//
//       f. 7 utiliser utiliser un g�ne existant (point� par pGene1) et
//            un crossing-over avec un g�ne n�2 � cr�er (point� par pGene2) puis
//            appliquer des mutations au g�ne point� par pGene1
//
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////

DWORD Ge_Main(DWORD Options,
              BYTE *pGene1,
              BYTE *pGene2,
              DWORD iSizeOfGene1,
              DWORD iMutationRate,
              DWORD iCrossOverRate,
              DWORD iMutPacketSize,
              DWORD iCrossPacketSize,
              DWORD iRndNumber,
              DWORD iSeed,
              DWORD iPrimeNumber1,
              DWORD iPrimeNumber2
             )
{
  DWORD bFlag = 0;
  if(Options>7){
    bFlag = 1;
    return bFlag;
  }
  if(iSeed==0){
    iSeed = RndSeed(iRndNumber, iPrimeNumber1, iPrimeNumber2);
  }
  if(Options==0){
    Create_Gene(pGene1, iSizeOfGene1, &iSeed, iPrimeNumber1, iPrimeNumber2);
	return bFlag;
  }
  if(Options==1){
    Mutate_Gene(pGene1, iSizeOfGene1, iMutationRate, iMutPacketSize, &iSeed, iPrimeNumber1, iPrimeNumber2);
    return bFlag;
  }
  if(Options==2){
    CrossOver_Gene(pGene1, pGene2, iSizeOfGene1, iCrossOverRate, iCrossPacketSize, &iSeed, iPrimeNumber1, iPrimeNumber2);
    return bFlag;
  }
  if(Options==3){
    Create_Gene(pGene2, iSizeOfGene1, &iSeed, iPrimeNumber1, iPrimeNumber2);
    CrossOver_Gene(pGene1, pGene2, iSizeOfGene1, iCrossOverRate, iCrossPacketSize, &iSeed, iPrimeNumber1, iPrimeNumber2);
    return bFlag;
  }
  if(Options==4){
    goto MutCross;
  }
  if(Options==5){
    goto CrossMut;
  }
  if(Options==6){
    Create_Gene(pGene2, iSizeOfGene1, &iSeed, iPrimeNumber1, iPrimeNumber2);
    goto MutCross;
  }
  if(Options==7){
    Create_Gene(pGene2, iSizeOfGene1, &iSeed, iPrimeNumber1, iPrimeNumber2);
    goto CrossMut;
  }
  CrossMut:
    CrossOver_Gene(pGene1, pGene2, iSizeOfGene1, iCrossOverRate, iCrossPacketSize, &iSeed, iPrimeNumber1, iPrimeNumber2);
    Mutate_Gene(pGene1, iSizeOfGene1, iMutationRate, iMutPacketSize, &iSeed, iPrimeNumber1, iPrimeNumber2);
    return bFlag;
  MutCross:
    Mutate_Gene(pGene1, iSizeOfGene1, iMutationRate, iMutPacketSize, &iSeed, iPrimeNumber1, iPrimeNumber2);
    CrossOver_Gene(pGene1, pGene2, iSizeOfGene1, iCrossOverRate, iCrossPacketSize, &iSeed, iPrimeNumber1, iPrimeNumber2);
    return bFlag;
}

//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
//
// (void)CrossOver_Gene(BYTE *pGene1,
//                      BYTE *pGene2,
//                      DWORD iSizeOfGene1,
//                      DWORD iCrossOverRate,
//                      DWORD iPacketSize,
//                      DWORD *iSeed,
//                      DWORD iPrimeNumber1,
//                      DWORD iPrimeNumber2
//                     )
//
// Param�tres:
// -----------
//
// BYTE *pGene1         --> g�ne n�1
// BYTE *pGene2         --> g�ne n�2
// DWORD iSizeOfGene1   --> taille du g�ne n�1 en octets
// DWORD iCrossOverRate --> nombre d'octets � �changer par groupe (facultatif)
// DWORD iPacketSize    --> taille des groupes (facultatif)
// DWORD *iSeed         --> pointeur sur la graine
// DWORD iPrimeNumber1  --> grand nombre premier (facultatif)
// DWORD iPrimeNumber2  --> grand nombre premier (< iPrimeNumber1) (facultatif)
//
// Remarques:
// ----------
//
// La taille du g�ne n�1 et du g�ne n�2 doit �tre la m�me.
//
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////

void CrossOver_Gene(BYTE *pGene1,
                    BYTE *pGene2,
                    DWORD iSizeOfGene1,
                    DWORD iCrossOverRate,
                    DWORD iPacketSize,
                    DWORD *iSeed,
                    DWORD iPrimeNumber1,
                    DWORD iPrimeNumber2
                   )
{
  DWORD j;
  DWORD k;
  BYTE Tmp;
  if(iCrossOverRate==0){
    iCrossOverRate = 3; //taux d'�change: 3 octets par groupe de 8 octets
  }
  if(iPacketSize==0){
    iPacketSize = 8;
  }
  for(DWORD i=0; i<iSizeOfGene1; i++){
    j = 0;
    k = 0;
    *iSeed = RndNumberGenerator(iSeed, iPrimeNumber1, iPrimeNumber2);
    while((i<iSizeOfGene1)&&(j<(*iSeed&iPacketSize))){
      *iSeed = RndNumberGenerator(iSeed, iPrimeNumber1, iPrimeNumber2);
      pGene1++;
      pGene2++;
      i++;
      j++;
    }
    while((i<iSizeOfGene1)&&(j<iPacketSize)&&(k<iCrossOverRate)){
      Tmp = *pGene1;
      *pGene1 = *pGene2;
      *pGene2 = Tmp;
      pGene1++;
      pGene2++;
      i++;
      j++;
      k++;
    }
  }
}

//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
//
// (void)Mutate_Gene(BYTE *pGene,
//                   DWORD iSizeOfGene,
//                   DWORD iMutationRate,
//                   DWORD iPacketSize,
//                   DWORD *iSeed,
//                   DWORD iPrimeNumber1,
//                   DWORD iPrimeNumber2
//                  )
//
// Param�tres:
// -----------
//
// BYTE *pGene         --> pointeur sur le d�but d'un g�ne
// DWORD iSizeOfGene   --> taille du g�ne en octets
// DWORD iMutationRate --> nombre d'octets � muter par groupes (facultatif)
// DWORD iPacketSize   --> taille des groupes (facultatif)
// DWORD *iSeed        --> pointeur sur la graine
// DWORD iPrimeNumber1 --> grand nombre premier (facultatif)
// DWORD iPrimeNumber2 --> grand nombre premier (< iPrimeNumber1) (facultatif)
//
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////

void Mutate_Gene(BYTE *pGene,
                 DWORD iSizeOfGene,
                 DWORD iMutationRate,
                 DWORD iPacketSize,
                 DWORD *iSeed,
                 DWORD iPrimeNumber1,
                 DWORD iPrimeNumber2
                )
{
  BYTE BitMask;
  DWORD j;
  DWORD k;
  if(iMutationRate==0){
    iMutationRate = 1;
  }
  if(iPacketSize==0){
    iPacketSize = 8;
  }
  for(DWORD i=0; i<iSizeOfGene; i++){
    j = 0;
    k = 0;
    *iSeed = RndNumberGenerator(iSeed, iPrimeNumber1, iPrimeNumber2);
    while((i<iSizeOfGene)&&(j<(*iSeed&iPacketSize))){
      *iSeed = RndNumberGenerator(iSeed, iPrimeNumber1, iPrimeNumber2);
      pGene++;
      i++;
      j++;
    }
    while((i<iSizeOfGene)&&(j<iPacketSize)&&(k<iMutationRate)){
      BitMask = 1;
      *iSeed = RndNumberGenerator(iSeed, iPrimeNumber1, iPrimeNumber2);
      *pGene ^= BitMask << *iSeed;
      pGene++;
      i++;
      j++;
      k++;
    }
  }
}

//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
//
// (void)Create_Gene(BYTE *pBuffer,
//                   DWORD iSizeOfBuffer
//                   DWORD *iSeed,
//                   DWORD iPrimeNumber1,
//                   DWORD iPrimeNumber2
//                  )
//
// Param�tres:
// -----------
//
// BYTE *pBuffer       --> pointeur sur le d�but du buffer dans lequel placer le g�ne
// DWORD iSizeOfBuffer --> taille du buffer en octets
// DWORD *iSeed        --> pointeur sur la graine
// DWORD iPrimeNumber1 --> grand nombre premier (facultatif)
// DWORD iPrimeNumber2 --> grand nombre premier (< iPrimeNumber1) (facultatif)
//
// Remarques:
// ----------
//
// Un g�ne de 100 octets offre 2^800 possibilit�s de boucles de d�chiffrements
// possibles. Sachant que 2^800 = 10^241 et qu'il existe approximativement
// 10^80 atomes dans l'univers, je ne pense pas que g�n�rer des g�nes de plus de
// 100 octets apporte quelque chose de plus...
//
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////

void Create_Gene(BYTE *pBuffer,
                 DWORD iSizeOfBuffer,
                 DWORD *iSeed,
                 DWORD iPrimeNumber1,
                 DWORD iPrimeNumber2
                )
{
  DWORD iTmp;
  for(DWORD i=0; i<iSizeOfBuffer; i++){
    iTmp = RndNumberGenerator(iSeed, iPrimeNumber1, iPrimeNumber2);
    *iSeed = RndNumberGenerator(&iTmp, iPrimeNumber1, iPrimeNumber2);
    *pBuffer = *iSeed; //Hash(iTmp, *iSeed);
    pBuffer++;
  }
}

//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
//
// (BYTE)Hash(DWORD Data,
//            DWORD iRndNumber
//           )
//
// Param�tres:
// -----------
//
// DWORD Data       --> octets � hasher
// DWORD iRndNumber --> nombre al�atoire
//
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
/*
BYTE Hash(DWORD Data, DWORD iRndNumber)
{
  for(DWORD i=0; i<iRndNumber; i++){
    if(i%2==0){
      Data = Data << 8;
    }
    else{
      if(i%3==0){
        Data %= i;
      }
      else{
        if(i%5==0){
          Data ^= iRndNumber;
        }
        else{
          Data++;
        }
      }
    }
  }
  return Data;
}
*/
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
//
// (DWORD)RndNumberGenerator(DWORD *iSeed,
//                           DWORD iPrimeNumber1,
//                           DWORD iPrimeNumber2
//                          )
//
// Param�tres:
// -----------
//
// DWORD *iSeed        --> pointeur sur la graine
// DWORD iPrimeNumber1 --> grand nombre premier (facultatif)
// DWORD iPrimeNumber2 --> grand nombre premier (< iPrimeNumber1) (facultatif)
//
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////

DWORD RndNumberGenerator(DWORD *iSeed, DWORD iPrimeNumber1, DWORD iPrimeNumber2)
{
  if(iPrimeNumber1==0){
    iPrimeNumber1 = 43691;
  }
  if(iPrimeNumber2==0){
    iPrimeNumber2 = 14449;
  }
  *iSeed *= (iPrimeNumber1 + 1);
  *iSeed += iPrimeNumber2;
  *iSeed %= iPrimeNumber1;
  return *iSeed;
}

//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////
//
// (DWORD)RndSeed(DWORD iRndNumber,
//                DWORD iPrimeNumber1,
//                DWORD iPrimeNumber2
//               )
//
// Param�tres:
// -----------
//
// DWORD iRndNumber    --> nombre quelconque choisit par l'appelant
// DWORD iPrimeNumber1 --> grand nombre premier (facultatif)
// DWORD iPrimeNumber2 --> grand nombre premier (< iPrimeNumber1) (facultatif)
//
//////////x//////////x//////////x//////////x//////////x//////////x//////////x//////////

DWORD RndSeed(DWORD iRndNumber, DWORD iPrimeNumber1, DWORD iPrimeNumber2)
{
  DWORD iSeed = 0;
  for(DWORD i=0; i<iRndNumber; i++){
    iSeed = RndNumberGenerator(&iSeed, iPrimeNumber1, iPrimeNumber2);
  }
  return iSeed;
}
