
//Valeurs de retour
#define GE_SUCCESS 0
#define GE_ERROR   1

//Options
#define CMD_CREATE            0
#define CMD_MUTATE            1
#define CMD_CROSSOVER         2
#define CMD_CCROSSOVER        3
#define CMD_MUTATE_CROSSOVER  4
#define CMD_CROSSOVER_MUTATE  5
#define CMD_MUTATE_CCROSSOVER 6
#define CMD_CCROSSOVER_MUTATE 7
