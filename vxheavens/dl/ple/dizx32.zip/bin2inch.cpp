#include <stdio.h>
#include <io.h>

typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef unsigned long       DWORD;

#define __T__SIGN1  'TBGN'
#define __T__SIGN2  'TEND'

#define __SIGN1	  'DBEG'
#define __SIGN2	  'DEND'

   int to1=0,to2=0,o1=0,o2=0,repeat_s;

int main(void)
{
	FILE *f,*h;
	if ((f=fopen("image.exe","rb"))==NULL){printf("File opening error!\n"); return 1;}
	int l=filelength(fileno(f));
	BYTE* buf= new BYTE[l];

   fread(buf,1,l,f);
   fclose(f);

	printf("\nGetting binary data...\n");
   for (int i=0;i<l;i++)
   {
   	if ( *(DWORD*)&buf[i] == __T__SIGN1 ) to1=i+4;
   	if ( *(DWORD*)&buf[i] == __T__SIGN2 ) to2=i;
   	if ( *(DWORD*)&buf[i] == __SIGN1 ) o1=i+4;
   	if ( *(DWORD*)&buf[i] == __SIGN2 ) o2=i;
   }

   f=fopen("dizx32.inc","wb");				//asm include
   h=fopen("dizx32.h","wb");				//C include

	fprintf(h,"//===================================================================\r\n");
	fprintf(h,"//  DIZX main function\r\n");
	fprintf(h,"//  size is %i bytes\r\n",o2-o1-1);
	fprintf(h,"//===================================================================\r\n");
	fprintf(h,"#define	dizx32_size	%i\r\n\r\n",o2-o1-1);
	fprintf(h," BYTE _dizx32[] = { \r\n");
	

	fprintf(f,";===================================================================\r\n");
	fprintf(f,";  DIZX main function\r\n");
	fprintf(f,";  size is %i bytes\r\n;",o2-o1-1);
	fprintf(f,";===================================================================\r\n");
	fprintf(f,"dizx32_size         equ        %i\r\n\r\n",o2-o1-1);
	fprintf(f,"\r\n\r\n dizx32:\r\n");

   for(int i=0;i<(o2-o1);i++)
  	{
		if (i%10 == 0) {
				fprintf(f,"\r\n db ");
				if (i) fprintf(h,",\r\n");
				}

	        fprintf(f,"0%02Xh",buf[o1+i]);
		fprintf(h,"0x%02X",buf[o1+i]);
		if ((i%10 != 9)&&(i!=(o2-o1-1))) {fprintf(f,",");fprintf(h,",");}
        }

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	fprintf(f,"\r\n\r\n;===================================================================\r\n");
	fprintf(f,";  DIZX tables unpacker\r\n");
	fprintf(f,";  size is %i bytes\r\n",to2-to1-1);
	fprintf(f,";===================================================================\r\n");
	fprintf(f,"dizx32_init_size         equ        %i\r\n\r\n",to2-to1-1);
	fprintf(f,"\r\n\r\n dizx32_init:\r\n");

	fprintf(h,"\r\n }; \r\n\r\n//===================================================================\r\n");
	fprintf(h,"//  DIZX tables unpacker\r\n");
	fprintf(h,"//  size is %i bytes\r\n",to2-to1-1);
	fprintf(h,"//===================================================================\r\n");
	fprintf(h,"#define	dizx32_init_size	%i\r\n",to2-to1-1);
	fprintf(h,"\r\n\r\n BYTE _dizx32_init[] = { \r\n");


   for(int i=0;i<(to2-to1);i++)
  	{
		if (i%10 == 0) {fprintf(f,"\r\n db "); 
				if (i)fprintf(h,",\r\n");}

	        fprintf(f,"0%02Xh",buf[to1+i]);
		fprintf(h,"0x%02X",buf[to1+i]);
		if ((i%10 != 9)&&(i!=(to2-to1-1))) {fprintf(f,",");fprintf(h,",");}
   }

	
	fprintf(h,"\r\n }; \r\n");
      delete buf;
      fclose(f);
      fclose(h);
      printf("\nBinary image was written on dizx32.inc & dizx32.h\n");
	return 0;
}
