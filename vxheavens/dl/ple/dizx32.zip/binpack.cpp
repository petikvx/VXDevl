#include <stdio.h>
#include <io.h>

typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef unsigned long       DWORD;

#define __T__SIGN1  'TBGN'
#define __T__SIGN2  'TEND'

   int to1=0,to2=0,repeat_s;

int main(void)
{
	FILE* f;
	if ((f=fopen("hash.exe","rb"))==NULL){printf("File opening error!\n"); return 1;}
	int l=filelength(fileno(f));
	BYTE* buf= new BYTE[l];

   fread(buf,1,l,f);
   fclose(f);

	printf("\nGetting binary data...\n");
   for (int i=0;i<l;i++)
   {
   	if ( *(DWORD*)&buf[i] == __T__SIGN1 ) to1=i+4;
   	if ( *(DWORD*)&buf[i] == __T__SIGN2 ) to2=i;
   }

   f=fopen("hash.inc","wb");

	fprintf(f,";");
	for (int i=0;i<=77;i++) fprintf(f,"=");
	fprintf(f,"\r\n;  DIZX32 tables unpacker\r\n;");

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	for (int i=0;i<=77;i++) fprintf(f,"=");
	fprintf(f,"\r\n\r\n\r\n dizx_init :\r\n");
	fprintf(f,"pusha\r\n");
	fprintf(f,"mov edi,[esp+8*4+4]\r\n\xor ecx,ecx\r\n\r\n");

   int s=to1,tsize=1+2+4+2;//ret+xor+pusha/popa+mov
   while (s<to2-1)
   {

		if (*(DWORD*)&buf[s]==0xffffffff)
      {
      	fprintf(f,"xor eax,eax                 ;eax=0ffffffffh\r\n");
      	fprintf(f,"dec eax                     ;\r\n");
	      tsize+=3;
      }
		else
		{
      	fprintf(f,"mov eax,0%08Xh\r\n",*(DWORD*)&buf[s]);
	      tsize+=5;
		}

 		repeat_s=1;
		for (int i=0;;i++)
       {
	   	if (*((DWORD*)&buf[s+i*4])==*((DWORD*)&buf[s+(i+1)*4]))repeat_s++;
	      else break;
       }

	   s+=repeat_s*4;

	 	if (repeat_s >=5)
 		{
	  	 fprintf(f,"mov cl,%i \r\n",repeat_s);
	  	 fprintf(f,"rep stosd \r\n");
		 tsize+=2+2;
   	}
	  else
		{
      tsize+=repeat_s;
   	for (;repeat_s!=0;repeat_s--)fprintf(f,"stosd\r\n");
		}
   }

 		fprintf(f,"\r\npopad\r\nret\r\n\r\n");
     	fprintf(f,";size is %i bytes\r\n;",tsize);
		for (int i=0;i<=77;i++) fprintf(f,"=");


      delete buf;
		fclose(f);
		printf("\nData was written on dizx.inc\n");
     return 0;
}
