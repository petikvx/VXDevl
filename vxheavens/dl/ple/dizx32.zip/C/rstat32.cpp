#include <stdio.h>
#include <stdlib.h>
#include <dir.h>
#include <dos.h>
#include <string.h>
#include <io.h>
#include <ctype.h>


typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef unsigned long       DWORD;
#include <x:\dizx32\dizx32def.h>

struct output xout;
DWORD result;
DWORD PEheader;

int resb,resc,res5,resf;

void findfiles(char* dir);
int process_file(char* filename);

void *Pdizx32;
void *Pdizx32_init;
void* tablePtr;
#include <x:\dizx32\dizx32.h>

int main(int argc,char* argv[])
{

Pdizx32=_dizx32;
Pdizx32_init=_dizx32_init;

tablePtr=malloc(2048);		//for tables
(*(dizx32_init*)Pdizx32_init)((DWORD)tablePtr);

printf (" =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
printf ("  rstat32 v 1.0 [DIZX32 based] (c) necr0mancer 2002\n");
printf ("  Reengeneering tool for disassembly statistic of files.\n");

if (argc!=2) {
printf ("\n Use:        rstat32.exe  <directory_name>\n");
printf (" =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n");
exit(1);}

printf (" =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n");
printf ("*** Getting statistic *** \n\n");

resb=resc=res5=resf=0;
findfiles(argv[1]);

printf (" =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
printf ("  Total  files processed                           %i\n",resf);
if (resf==0) resf=1;
printf ("  Middle bytes disassembled (Kb)                   %i.%i\n",resb/(1024*resf),((resb%(1024*resf))/1000)*1000);
printf ("  Middle commands disassembled                     %i\n",resc/resf);
printf ("  Middle 5 length bytes commands disassembled      %i\n",res5/resf);
printf (" =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");

free(tablePtr);
return 0;
}

void findfiles(char* dir)
{

struct ffblk searchRec;

char dirmask[1024];
char pdir[1024];

strcpy(dirmask,dir);
strcpy(pdir,dir);		//looked directory
if (dirmask[strlen(dirmask)-1]!='\\') strcat(dirmask,"\\");
strcat(dirmask,"*.*");
findfirst(dirmask,&searchRec,FA_RDONLY|FA_HIDDEN|FA_SYSTEM|FA_DIREC|FA_ARCH);

char npath[1024];

while (1)
  {
		strcpy(npath,pdir);		//npath=cdir
		if (npath[strlen(npath)-1]!='\\') strcat(npath,"\\");
	   strcat(npath,searchRec.ff_name);

		if ((searchRec.ff_attrib & FA_DIREC)&&(searchRec.ff_name[0]!='.'))
			{
	   		strcat(npath,"\\");
				findfiles(npath);
			}
      else if(!(searchRec.ff_attrib & FA_DIREC)) process_file(npath);


	  if(findnext(&searchRec)) break;
  }

};


//==============================================================================

int process_file(char* filename)
{

#define l strlen(filename)

	printf(" * file : %s \n",filename);

 for (int i=0; i<l; i++)
   {
      filename[i] = toupper(filename[i]);
   }
	printf(" * file converted : %s \n",filename);

if (

	((filename[l-3]=='E')&&
	(filename[l-2]=='X')&&
	(filename[l-1]=='E'))||

	((filename[l-3]=='D')&&
	(filename[l-2]=='L')&&
	(filename[l-1]=='L')))

{

	FILE* f;
	f=fopen(filename,"rb");
	if (f==0) { printf(" * ! %s  - File opening error.\n",filename); return 0 ;}

	BYTE* buf= new BYTE[filelength(fileno(f))];
   fread(buf,1,filelength(fileno(f)),f);
	fclose(f);

   if (*(WORD*)buf!=(WORD)0x5A4D) {printf(" * %s-no EXE\n\n",filename);return 0;} //MZ check
   if ((*(WORD*)&buf[0x18])<(WORD)0x40) {printf(" * %s - no PE format.\n\n",filename);return 0;}

   PEheader=(*(DWORD*)&buf[0x3c]);
   if (*(WORD*)(buf+PEheader)!=(WORD)'PE'){printf(" * %s - no PE format.\n",filename);return 0;}

	DWORD text=*(WORD*)(buf+PEheader+0x14);	//get object table => code section object offset
	text+=PEheader+0x18;
   DWORD RVA=*(DWORD*)(buf+PEheader+0x28);//get RVA
   RVA=RVA-*(DWORD*)(buf+text+0x0c)+*(DWORD*)(buf+text+0x14);

	BYTE* memPtr=buf+(DWORD)RVA;

   int cc,cs,c5;
   cc=cs=c5=0;

	while (cs<=4096)//disasm 4 kb(write while (1) if you want to disasm all file;))
	{
		result=(*(dizx32*)Pdizx32)((DWORD)memPtr,(DWORD)&xout,(DWORD)tablePtr);
		if (result!=-1)
		{
			 cs+=result;
			 resb+=result;

          cc++;
          resc++;

      	if( result>=5 )	{	c5++;	res5++;}

			(DWORD)memPtr+=result;
		}else break;
	}

  	resf++;																	//+ 1 file processed

// resb,resc,res5,resf;

	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	printf("   Total disasmed (bytes)           :  %u  bytes.\n",cs);
	printf("   Total disasmed (commands)        :  %u .\n",cc);
	printf("   Total 5_bytes_commands disasmed  :  %u .\n",c5);
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

   free(buf);
}
	return 0;
}

