#include <stdio.h>
#include <stdlib.h>
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef unsigned long       DWORD;
#include <x:\dizx32\dizx32def.h>

void* a;
DWORD b;
struct output xout;
DWORD result;

int main()
{
#include <x:\dizx32\dizx32.h>
typedef DWORD __cdecl dizx32(DWORD bufer,DWORD out,DWORD table);
typedef void __cdecl dizx32_init(DWORD bufer);

void *Pdizx32=_dizx32;
void *Pdizx32_init=_dizx32_init;


void* tablePtr=malloc(2048);		//for tables
(*(dizx32_init*)Pdizx32_init)((DWORD)tablePtr);
b=*(DWORD*)tablePtr;


BYTE* memPtr=_dizx32_init;


printf ("Demonstration of DIZX32 using: self engine disasming\n");
printf("\n *   Self disasming of function dizx32_init:\n\n");
while ((DWORD)(memPtr-_dizx32_init)<=dizx32_init_size)
{
result=(*(dizx32*)Pdizx32)((DWORD)memPtr,(DWORD)&xout,(DWORD)tablePtr);
	if (result!=-1)
		{
			printf("command size is :  %u  bytes.\n",result);
			(DWORD)memPtr+=result;
		}else break;
}

memPtr=_dizx32;
printf("\n\n *   Self disasming of function dizx32:\n\n");
while ((DWORD)(memPtr-_dizx32)<=dizx32_size)
{
result=(*(dizx32*)Pdizx32)((DWORD)memPtr,(DWORD)&xout,(DWORD)tablePtr);
	if (result!=-1)
		{
			printf("command size is :  %u  bytes.\n",result);
			(DWORD)memPtr+=result;
		}else break;
}


free(tablePtr);
return 0;
}
