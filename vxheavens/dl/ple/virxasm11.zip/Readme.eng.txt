
 ======================================================================
 ====================[ LENGTH-DISASSEMBLER ENGINE ]====================
 ====================[ VIRXASM32 ]=========[ v1.1 ]====================
 ====================[ WRITTEN BY MALUM  28.07.06 ]====================
 ======================================================================

 HISTORY:
 v1.0 - first beta release
 v1.1 - bugfix in all extended table, added 9A,EA opcodes

 -----------
 Description
 -----------
  VirXasm32 is length-disassembler of 32 bit executable code of Intel processors.
  I decided to exclude error flag from dizasm tables that's why VirXasm disassemble
all opcodes (possible and impossible). Also disasm know nothing about CODE/REG field
(imho all len-dizasms not process field CODE/REG. exclude TEST). VirXasm not process
67h prefix and that's why it not understand jokes like "mov eax,[si]" (are you use
16 bit addressing in 32 bit mode ;) ) Although it well process all other prefixes
(include 0F1h "pseudo-prefix" :) because error flag is not present).
  Size of VirXasm is only 309 bytes (bigger then first version). VirXasm well
disassemble itself. Of cause external calls, absolute offsets in code are not
present. But version "A" have delta offset (call delta/pop ebp) that's why
I wrote version "B" without delta offsets were all data push in stack.

 -------------
 How to use it
 -------------
  Before use VirXasm include file VirXasm32_v1.1.asm to your virus, set ESI
on disassembling code, call VirXasm32 and it will return in EAX length of
instruction. Also you must have 180 bytes in stack. For example:

	; ...
	mov	esi, offset instrs
nxt:	call	VirXasm32
	add	esi, eax
	cmp	eax, 5
	jne	nxt
	; ...

include	VirXasm32_v1.1b.asm

 ----------
 About code
 ----------
  For description of opcodes I used two tables on group (normal and extended
groups). In first table each instruction have one bit of present mod r/m byte
(I used BT instruction). In second table each instruction have two bits. First
bit is presence of immediate value and second bit is size of immediate value.
(0 - byte, 1 - double word or word if 66h prefix present) Some opcodes can not
be descripted by this method (ENTER,RET N,IRET N and fucking TEST). VirXasm
process it apart. Also my dizasm use special order of opcodes in opcode table
(for example: 0xh,1xh,2xh,3xh are equal, in extended group, 1xh,2xh,4xh,5xh,
6xh,9xh,Dxh,Exh Fxh are equal too and in normal group in 4xh,5xh,7xh,9xh,Bxh,
Dxh,Exh,Fxh opcodes have places by pairs (oh, my bad english)).

 --------
 Contacts
 --------
  All offers, notices and information about bugs send to me
  (C) Malum 28.07.06 - malum@mail.ru

; =======[
; ==========================[
; ===============================================[
