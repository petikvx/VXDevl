Example virus win9x.dee.demo
It shows how to create viruses with vxsc kit & dee engine.
killatom.exe - util to kill any atom in your system (it usually takes on debug)

							(c) necr0mancer