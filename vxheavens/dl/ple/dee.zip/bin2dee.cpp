#include <stdio.h>
#include <io.h>

typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef unsigned long       DWORD;

#define __SIGN1	  'DBEG'
#define __SIGN2	  'DEND'

   int to1=0,to2=0,o1=0,o2=0,repeat_s;

int main(void)
{
	FILE *f,*h;
	if ((f=fopen("image.exe","rb"))==NULL){printf("File opening error!\n"); return 1;}
	int l=filelength(fileno(f));
	BYTE* buf= new BYTE[l];

   fread(buf,1,l,f);
   fclose(f);

	printf("\nGetting binary data...\n");
   for (int i=0;i<l;i++)
   {
   	if ( *(DWORD*)&buf[i] == __SIGN1 ) o1=i+4;
   	if ( *(DWORD*)&buf[i] == __SIGN2 ) o2=i;
   }

   f=fopen("dee.inc","wb");				//asm include
   h=fopen("dee.h","wb");				//C include

	fprintf(h,"//===================================================================\r\n");
	fprintf(h,"//  DEE main function\r\n");
	fprintf(h,"//  DWORD   dee ( DWORD code_param, \r\n");
	fprintf(h,"//                 DWORD bufer_param,\r\n");
	fprintf(h,"//                 DWORD num_param,\r\n");
	fprintf(h,"//                 DWORD replace_param,\r\n");
	fprintf(h,"//                 DWORD random_proc, );\r\n");
	fprintf(h,"//  size is %i bytes\r\n",o2-o1-1);
	fprintf(h,"//===================================================================\r\n");
	fprintf(h,"#define	dee_size	%i\r\n\r\n",o2-o1-1);
	fprintf(h," BYTE _dee[] = { \r\n");
	

	fprintf(f,";===================================================================\r\n");
	fprintf(f,";  DEE main function\r\n");
	fprintf(f,";  DIZX main function\r\n");
	fprintf(f,";  DWORD   dee ( DWORD code_param, \r\n");
	fprintf(f,";                 DWORD bufer_param,\r\n");
	fprintf(f,";                 DWORD num_param,\r\n");
	fprintf(f,";                 DWORD replace_param,\r\n");
	fprintf(f,";                 DWORD random_proc, );\r\n");
	fprintf(f,";  size is %i bytes\r\n;",o2-o1-1);
	fprintf(f,";===================================================================\r\n");
	fprintf(f,"dee_size         equ        %i\r\n\r\n",o2-o1-1);
	fprintf(f,"\r\n\r\n dee:\r\n");

   for(int i=0;i<(o2-o1);i++)
  	{
		if (i%10 == 0) {
				fprintf(f,"\r\n db ");
				if (i) fprintf(h,",\r\n");
				}

	        fprintf(f,"0%02Xh",buf[o1+i]);
		fprintf(h,"0x%02X",buf[o1+i]);
		if ((i%10 != 9)&&(i!=(o2-o1-1))) {fprintf(f,",");fprintf(h,",");}
        }

      fprintf(h,"\r\n };\r\n");

      delete buf;
      fclose(f);
      fclose(h);
      printf("\nBinary image was written on deep.inc & deep.h\n");
	return 0;
}
