Symantec Computer Virus and Worm Simulation System
Copyright (C) 1999, Symantec Corporation

There should be three files in this archive:

        README.TXT      This README file
        VBSIM.EXE       The simulation program
        VBSIM.PDF       Simulation documentation

These files make up the Symantec Computer Virus and Worm Simulation System.
This program was first demonstrated at the Virus Bulletin 1999 conference
in Vancouver, Canada.  The program VBSIM.EXE shows how computer viruses and
worms spread through corporations.

In order to run this program, click on the VBSim icon, or run VBSim.EXE
from the DOS command prompt.

If you have any comments or questions, please send e-mail to:

        Carey Nachenberg
        cnachenberg@symantec.com

