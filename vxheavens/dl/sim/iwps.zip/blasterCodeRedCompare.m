%%=====================================================================
% This program compares Blaster and Code Red simulation.
% We run both Blaster, a sequential scan worm with random starting point, and Code Red 100 simulation runs by C simulation codes. 
% The simulation results are written in three files.
% This program use these three files to draw propagation curves.
% Updated Date: 02/21/2004:  
%               Add inline explanation for sharing with other researchers.
% Author: Cliff Changchun Zou.

clear all;

%------------------------------ Code Red.
fid = fopen( 'codered-100run.txt', 'r');
simulationNum = 700;
sampleRun = 100;
monitorBit = 20; 
N=360000;
scanRate = 358;
q= 1 - power( 1 - 1/power(2,32-14), scanRate);

Datatemp = fscanf( fid, '%ld', [4,inf]);
fclose(fid);

I_all = zeros(simulationNum, sampleRun); C_all = I_all; Z_all = I_all; 

for i=1:sampleRun,
    I_all(:,i) = Datatemp(2, 1+ (i-1)*simulationNum:i*simulationNum)';
    C_all(:,i) = Datatemp(4, 1+ (i-1)*simulationNum:i*simulationNum)';
    Z_all(:,i) = Datatemp(3, 1+ (i-1)*simulationNum:i*simulationNum)';
end

[Sort_I_all, indexI] = sort(I_all'); [Sort_C_all, indexC] = sort(C_all'); [Sort_Z_all, indexZ] = sort(Z_all');

CodeRedMeanI = mean(Sort_I_all)';
CodeRed95 = Sort_I_all(95,:)'; CodeRed05 = Sort_I_all(5,:)';
CodeRedMeanI = [CodeRedMeanI; N*ones(300,1)]; CodeRed95 = [CodeRed95; N*ones(300,1)]; CodeRed05 = [CodeRed05; N*ones(300,1)];

%--------------------- a sequential scan worm with randomly selected starting point.
fid = fopen( 'sequential-100run-monitor5-bgp-2.txt', 'r');
monitorNum = 5;  % 16, 128, 512, 1024, 4096.
simulationNum = 1000;
sampleRun = 100;

Datatemp = fscanf( fid, '%ld', [2+3*monitorNum,inf]);
fclose(fid);

I_all = zeros(simulationNum, sampleRun); 
Z_all = zeros(monitorNum, simulationNum, sampleRun); C_all = Z_all;

for i=1:sampleRun,
    I_all(:,i) = Datatemp(2, 1+ (i-1)*simulationNum:i*simulationNum)';
    for j=1:monitorNum,
        Z_all(j, :,i) = Datatemp(3+(j-1)*3, 1+ (i-1)*simulationNum:i*simulationNum)';
        C_all(j, :,i) = Datatemp(4+(j-1)*3, 1+ (i-1)*simulationNum:i*simulationNum)';
    end
end

[Sort_I_uniform_all, indexI] = sort(I_all'); 
BlasterUniformMeanI = mean(Sort_I_uniform_all)';
BlasterUniform95 = Sort_I_uniform_all(95,:)'; BlasterUniform05 = Sort_I_uniform_all(5,:)';

%-------------- Blaster worm (with 40% probability to select a local IP address as its starting point)
fid = fopen( 'blaster-100run-monitor5-2.txt', 'r');
monitorNum = 5;  % 16, 128, 512, 1024, 4096.
simulationNum = 1000;
sampleRun = 100;

Datatemp = fscanf( fid, '%ld', [2+3*monitorNum,inf]);
fclose(fid);

I_all = zeros(simulationNum, sampleRun); 
Z_all = zeros(monitorNum, simulationNum, sampleRun); C_all = Z_all;

for i=1:sampleRun,
    I_all(:,i) = Datatemp(2, 1+ (i-1)*simulationNum:i*simulationNum)';
    for j=1:monitorNum,
        Z_all(j, :,i) = Datatemp(3+(j-1)*3, 1+ (i-1)*simulationNum:i*simulationNum)';
        C_all(j, :,i) = Datatemp(4+(j-1)*3, 1+ (i-1)*simulationNum:i*simulationNum)';
    end
end

[Sort_I_all, indexI] = sort(I_all'); 
BlasterMeanI = mean(Sort_I_all)';
Blaster95 = Sort_I_all(95,:)'; Blaster05 = Sort_I_all(5,:)';


figure; hold on; axis([0 700 0 360000]); xlabel('Time t (minute)'); ylabel('# of infected hosts');
t=1:12:1000;  % This "t" is used for adding markers on curves later (from the matlab figure windows). 
              % Adding marker on curves makes it clear to show on black/white printout paper.
              % We change figure's font size, curve's thickness through Matlab figure windows.
plot(t, CodeRedMeanI(t),'r--'); plot(t, BlasterUniformMeanI(t),'b');  plot(t, BlasterMeanI(t),'k--'); 
legend('Code Red','Uniform sequential', 'Blaster');
%return;

figure; hold on; axis([0 700 0 360000]); xlabel('Time t (minute)'); ylabel('# of infected hosts');
t=1:12:1000;
plot(t, CodeRed95(t),'b'); plot(t, CodeRed05(t),'b--'); 
plot(t, BlasterUniform95(t),'r'); plot(t, BlasterUniform05(t),'r--'); 
legend('95% Code Red', '5% Code Red', '95% sequential', '5% sequential');
return;
