//====================== blaster-multiMonitor-100run.cpp ===================================
//              RPC Blaster worm simulation.

//    1. Consider local preference (40%) of the Blaster worm.
//    2. Consider uniform distribution of vulnerable hosts in 
//                      (a). entire IPv4 space (b). BGP routable space.
//    3. Use multiple monitoring systems with different number of IP blocks. All of them monitor the same number of IP addresses.
//       The monitoring blocks in one monitoring system are evenly distributed in IPv4 space.
//    4. Each monitoring system monitors two data sets: C_t and Z_t (see our paper in CCS'03)
//    5. Run 100 times simulation.
//    6. Scan rate of one infected host is fixed. Scan rate of all infected hosts follows normal distribution, or a fixed scan rate.
//    7. Use Code Red parameters for comparision. N= 360000, I_0=10, \eta=N(358, 100^2) 
//    8. Input a BGP non-overlapping routing prefixes data file: "prefix-len.20030922"
//       Output results to a file to be used by Matlab program. The output file name is given at command line after this program.


// Date: 10/31/2003. We assume vulnerable hosts are uniformly distributed in BGP routable space. BGP prefixes are 
//                   from BGP tables on Sept. 22, 2003 (route view project).

// Date: 12/17/2003:
//        (1).  Use the same parameters as Code Red, assume noise and normal distribute for scan rate.
//        (2).  In one simulation, get results for multiple monitoring systems with different number of IP blocks. 
//              All monitoring systems have the same number of IP addresses.
//        (3).  Use binary search in finding whether a scan hits monitors or vulnerable host, which greately increases 
//              simulation speed and makes it possible to simulate 4096-block monitoring system for 100 simulation runs.
//
// Date: 1/22/2004:   Add detailed inline explanations for coordination with other researchers.
//         Notations see our "Monitoring and Early Warning" paper in CCS'03.
//         For 100 simulation runs, this program will run about 13 hours on P4 2.7Ghz Linux computer.
// 
// Author: Cliff Changchun Zou.         
//========================================================================

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define NUM						360000  // System population: N
#define ENDSIMUL				1000  // end of simulation (unit time) for Blaster the unit time is a minute. 
#define INIT_INFECTED_NUM		10    // initially infected hosts: I(0)
#define MONITOR_SYSTEM_NUM      5     // 5 different monitoring systems with different blocks of IP addresses.
#define SAMPLE_RUN				100   // Run simulation 100 times.

const double SCAN_PER_MINUTE	= 358;   // Average scan per minute: \eta
const short  MONITOR_SPACE_BIT  = 20;  // how many IP space is used for monitor (2^{20})
const short  DIVIDE_MINUTE      = 1;  // divide a unit time (a minute) into many steps to simulate more accurately.
                                      // you can increase this value to increase simulation accuracy.
const double SIGMA1				= 100;  // standard diviation for the normal distribution of scan rate.

const double LOCAL_START		= 0.4;  // 0% to start from local address (random starting point).  
                                        // 40% is the original blaster worm.

const int MONITOR_BLOCK[]			= {16, 128, 512, 1024, 4096}; // We simulate five monitoring systems. Each
                                    // one has n equal size blocks of IP space. n= 16, 128, 512, 1024, 4096.
                                    // the total IP space covered by each monitoring system is 2^{20}. 
const int MAX_BLOCK					= 4096;
typedef enum  {
	healthy = 0,
	danger = 1,
	infected = 2,
	immunized = 3
}NodeStatus_type;

typedef struct {           // normal distribution structure.
    double average;
    double variance;
}Normal_type;

typedef struct {
	NodeStatus_type nodeStatus;
	int countSource[MONITOR_SYSTEM_NUM];  // flag: whether this node has been count in the i-th monitoring system 
	                                      // (for unique source) i=1,2,3,4,5
	double currentIP;                     // Current IP address the worm is scanning; It is the beginning IP for 
	                                      // scanning for the current unit time.
	double scanRate;                      // this node's scan rate.
}NodeData_type;

typedef struct {
	long scan;     // number of scans observed in a unit time: Z_t
	long source;   // number of unique sources that the monitoring system has observed until now: C_t
}MonitorCounter_type;

typedef struct {     // the beginning and ending IP addresses of one monitoring block.
	double beginIP;  
	double endIP;
}MonitorBlockIP_type;	

//=========================================================================
//   Global variables.

NodeData_type NodeData[NUM];
double NodeIP[NUM]; // the IP address of each vulnerable computer.
MonitorBlockIP_type MonitorBlock[MONITOR_SYSTEM_NUM][MAX_BLOCK];

MonitorCounter_type monitorCounter[MONITOR_SYSTEM_NUM];       // monitoring data.
long monitorHitSource[MONITOR_SYSTEM_NUM];     // The number of observed sources in a unit time. (C_t is a cumulative data).
Normal_type ScanRate;
Normal_type noiseZ, noiseC;    // added noise in data Z_t and C_t

//=========================================================================
void initNode(  NodeData_type[]);   // initialized status of all vulnerable hosts.
short expGenerator( short );        // exponential distribution generator.
double normalGenerator( Normal_type);  // non-negative normal distribution generator.
long monitorHit(int kk, double beginIP, double endIP); // check whether scans from an infected host in a discrete time hit any monitoring space.
double rand01(void);                // 0-1 uniform distribution.
void infection ( NodeData_type [], long);  
void initVulnerable( FILE *);       // Determine the IP addresses of vulnerable hosts according to BGP routable space.
long findTarget(double, double);    // check whether scans from an infected host in a discrete time hit any host in the system.

//=========================================================================
int main ( int argc, char * argv[] ) {

	if( argc !=2) {
		printf("Usage: simulator outputfilename.\n"); exit(1);
	};
	long oldInfectedNum, infectedNum = INIT_INFECTED_NUM ; // total infected node number.
	long timeTick = 0;  // simulation time tick unit.
	long i,j, finish_timeTick, firstCount=1;
	double  infectedPercentage, oldInfectedPercentage;
	FILE *out, *in;
	if ((out = fopen(argv[1], "wt")) == NULL) {
		printf("open output file error.\n"); exit(1);
	};

	// add normal distribution noise to data Z_t according to the hourly data by Goldsmith:
	//    http://lists.jammed.com/incidents/2001/07/0149.html
	int monitorBit = MONITOR_SPACE_BIT, timeUnit = 1;
	double BaseBit = 16, BaseUnit = 60,BaseNZmean = 110.5, BaseNZstd = 30;
	double ratio = timeUnit/BaseUnit*pow(2, monitorBit-BaseBit);
	double noiseZmean = BaseNZmean * ratio;
	double noiseZstd = BaseNZstd * ratio;
	double threshold = noiseZmean * 2;
	int alarmTime = 3;   
	noiseZ.average = noiseZmean; noiseZ.variance = noiseZstd * noiseZstd;
    // in Blaster simulation, C_t is very small. In order to see its dynamic, I didn't add noise to C_t. 
	// (In our Kalman filter estimation, we used Z_t for Blaster worm).

	time_t beginTime, endTime;
	long simulTime;
	double scanNumber = 0;
	long monitorHitNum = 0;
	timeTick = 0;
	
	srand( (unsigned)time( NULL ) );
	(void)time( &beginTime );	
	initVulnerable( in);

  for(long m=0; m<SAMPLE_RUN;m++){	// run SAMPLE_RUN times simulation.
	double scanNumber = 0;
	long timeTick = 0, IPindex; 
	infectedNum = INIT_INFECTED_NUM ;
	initNode(  NodeData );   // initialize status of vulnerable hosts at each simulation run.
	
	// simulation begin.

	double prob1,scanRate;
	double beginIP, endIP;
	oldInfectedPercentage = 0;
	while ( timeTick < ENDSIMUL) {
	  for (int k=0; k<MONITOR_SYSTEM_NUM;k++){
		// reset the monitor counter ( non-cumulative monitor counter).
			monitorCounter[k].scan  = 0; // monitorCounter.source    = 0;
			monitorHitSource[k] = 0;
	  };
	  oldInfectedNum= infectedNum;
	  timeTick ++;
	  for(int x=0;x<DIVIDE_MINUTE;x++){  // simulate DIVIDE_MINUTE times in one unit time.
	    for ( i=0;i<NUM; i++)
		    if ( NodeData[i].nodeStatus == infected ) {
				// determine whether this infected node hits a target or monitor during this minute.
				beginIP = NodeData[i].currentIP; 
				endIP   = beginIP + NodeData[i].scanRate /DIVIDE_MINUTE;   // the IP range the host is scanning during this discrete time.
				for (int kk=0; kk<MONITOR_SYSTEM_NUM;kk++){  // determine whether it hits a monitor.
					monitorHitNum = 0;
					monitorHitNum  = monitorHit(kk, beginIP, endIP);
					if (monitorHitNum >= 1 ) {  // the scan is in the monitor.
						//printf("%ld\t", monitorHitNum);  //test
						monitorHitSource[kk] ++;   // add one source IP in.
						monitorCounter[kk].scan += monitorHitNum;
						if (monitorHitNum > 10000) {printf("Wrong in monitorHitNum: too big\n"); exit(1);};
						if ( NodeData[i].countSource[kk] == 0 ){
							NodeData[i].countSource[kk] = 1;
							monitorCounter[kk].source ++;
						};
					};
				};
				if ( (IPindex = findTarget(beginIP, endIP)) >= 0 ) {  // the worm finds target.
					infection( NodeData, IPindex);
				};
				if ( endIP >= pow(2,32) ) endIP -= pow(2,32);  // restart currentIP if over the boundary.
				NodeData[i].currentIP = endIP+1;
			};

	    for ( i=0 ;i<NUM; i++){
	      if ( NodeData[i].nodeStatus == danger ) {  //update current status. A newly infected host becomes infectious in the next round.
			NodeData[i].nodeStatus  = infected;
			infectedNum ++;
			if (rand01() < LOCAL_START)   // start from local IP.
				NodeData[i].currentIP = NodeIP[i];
			else                          // from random IP.
				NodeData[i].currentIP = rand01()*pow(2,32);
	      };
		}; 
	  }; // end for(int x=0;x<DIVIDE_MINUTE;x++)

	  // add noise into Z_t.
	  for (int kk=0; kk<MONITOR_SYSTEM_NUM;kk++){
		  monitorCounter[kk].scan += long(floor(0.5 + normalGenerator(noiseZ)));
	  };
	  // printout this step result into file.
	  fprintf(out, "%ld\t%ld\t", timeTick,infectedNum);
      for (int kk=0; kk<MONITOR_SYSTEM_NUM;kk++){
		  fprintf(out, "%ld\t%ld\t%ld\t", monitorCounter[kk].scan, monitorCounter[kk].source, monitorHitSource[kk]);
	  };
	  fprintf(out,"\n");

	}; // end while simulation.
  }; // end 100 sample runs.
	fclose(out);
	(void)time(&endTime);
	simulTime = (long) ( endTime -beginTime );
	printf("\n Simulation finished by using  %lf hours.\n", simulTime/3600.0);
	return 0;
} // end main.


//==============================================================================
//-----------------------------------------------------------------

double rand01(void) {
	return (double(rand()) + 0.5) / ((double)RAND_MAX + 1.0);  
	// I add 0.5 and 1.0 to achieve a balanced distribution in (0,1).
}

short expGenerator( short average ) { // exponential distribution generator.

	short temp = short( - log( 1.0 - rand01() ) * double(average) ) ;
	if ( temp < 1) temp = 1; // minimum infection delay time.
	return temp;
}
//-----------------------------------------------------------------------------------
void initVulnerable( FILE * in) {

	// uniformly distributed in entire IPv4 space.
	/*
	double interval2 = pow(2,32)/NUM;
    for (long i=0; i<NUM; i++){
		NodeIP[i] = i*interval2;
	};
	return;
	*/

    // uniformly distributed in the BGP routable space.

	double allocateSpace = 0, density, baseIP, interval;
	char Prefix[100], *str;
	long i,j, currentIndex = 0, prefixNum=0;
	int a, b, c, d,prefixLen;
	if ((in = fopen("prefix-len.20030922", "rt")) == NULL) {
		printf("open input file error.\n"); exit(1);
	};
	while (fgets(Prefix, 100, in) != NULL){
		str = strstr(Prefix, "/"); 
		sscanf(str, "/%d", &prefixLen); 
		allocateSpace += pow(2, 32-prefixLen);
	};
	density = NUM / allocateSpace;   // density of vulnerable hosts in the routable space.
	interval = 1/density;            // assuming vulnerable hosts are evenly distributed in routable space.
	rewind(in);
	int Flag = 1;
	while (Flag == 1 && fgets(Prefix, 100, in) != NULL){
		prefixNum ++;
		sscanf(Prefix, "%d.%d.%d.%d/%d", &a, &b, &c, &d, &prefixLen);
		long n = long(pow(2, 32-prefixLen) * density + 0.7);  // this 0.7 can be adjusted to make sure almost all prefixes have  
		                                                      // been filled by vulnerable hosts. 
		                                                      // (we will miss one or several prefixes but the error is small). 
		// determine base IP address.
		baseIP = a*16777216.0 + b*65536.0 + c*256.0 + d;
		for (i=0; i<n; i++) {
			NodeIP[currentIndex] = baseIP + i * interval;
			currentIndex ++;
			if ( currentIndex >= NUM ){
				printf("prefixNum = %ld\n", prefixNum); Flag = 0;
				break;
			};
		};
	};
}

//-----------------------------------------------------------------------------------
void initNode( NodeData_type NodeData[]) {	
	long i;  // iteration variable.
	long x;
	double scanRate;

	ScanRate.average = SCAN_PER_MINUTE;
	ScanRate.variance = SIGMA1 * SIGMA1;

	for (i=0;i< NUM; i++){
			
			NodeData[i].nodeStatus = healthy;
			for (int k=0; k<MONITOR_SYSTEM_NUM;k++) 
				NodeData[i].countSource[k] = 0;      // not counted yet by monitor.
			//scanRate = normalGenerator(ScanRate);    // normal distribution of scan rate for each host.
			scanRate = SCAN_PER_MINUTE;            // the same scan rate for all hosts.
			if (scanRate < 1 ) scanRate = 1;         // minimal scan rate is 1 per unit time.
			NodeData[i].scanRate = scanRate;
	};
	 
	// determine which node is infected in the initial state.  randomly pick initially infected hosts.
	for( i= 1;i<=INIT_INFECTED_NUM; i++) {
		x = long( NUM * rand01() ); 
		NodeData[x].nodeStatus = infected;
		if (rand01() < LOCAL_START) {  // start from local IP.
			NodeData[x].currentIP = NodeIP[x]+1;
		}
		else {                          // from random IP.
			NodeData[x].currentIP = rand01()*pow(2,32);
		};		
	};
	// initialize counters.
	for (int k=0; k<MONITOR_SYSTEM_NUM;k++){
		monitorCounter[k].scan = 0; monitorCounter[k].source = 0;
		monitorHitSource[k] = 0;
	};

	// initialized MonitorBlock.
	for (int k=0; k<MONITOR_SYSTEM_NUM;k++){
		double blockInterval = pow(2,32)/MONITOR_BLOCK[k];

		for (i=0; i<MONITOR_BLOCK[k]; i++) {
			MonitorBlock[k][i].beginIP = blockInterval * i;
			MonitorBlock[k][i].endIP = MonitorBlock[k][i].beginIP + pow(2,MONITOR_SPACE_BIT)/MONITOR_BLOCK[k] - 1;
		};
	};
}
//---------------------------------------------------------------------------------
long findTarget(double beginIP, double endIP){
	long i;
	double beginNode, endNode, middleIP;

	// use binary search tree to find the closest node IP.
	long beginIndex=0, endIndex=NUM-1;

	middleIP = (beginIP + endIP ) / 2;
	while (beginIndex != endIndex - 1 ){
		long middleIndex = (beginIndex + endIndex ) / 2;
		if ( NodeIP[middleIndex] < middleIP )
			beginIndex = middleIndex;
		else if (NodeIP[middleIndex] > middleIP)
				endIndex = middleIndex;
		else {
			beginIndex = middleIndex;
			break;  // equal to one node IP address.
		};
	};
	if ( NodeIP[beginIndex] >= beginIP && NodeIP[beginIndex] <=endIP ){
		return beginIndex; 
	};
	if ( NodeIP[endIndex] >= beginIP && NodeIP[endIndex] <=endIP ) {
		return endIndex;
	};
	// the two "if" above are correct when the density of vulnerable hosts is small such that one worm scans 
	// in a unit time (an IP block with about \eta addresses) cannot hit two vulnerable hosts.

	return -1;  // no target is in the scan interval.
}


//---------------------------------------------------------------------------------

void infection ( NodeData_type NodeData[], long IPindex ) {
		// update node status.
		if ( NodeData[IPindex].nodeStatus == healthy)
			NodeData[IPindex].nodeStatus = danger;
}
//--------------------------------------------------------------------------

long monitorHit(int k, double beginIP, double endIP){
	int hitFlag = 0, index;
	long hitNum = 0;

	// use binary search tree to find the closest monitoring block beginIP.
	double middleIP = (beginIP + endIP ) / 2;
	long beginIndex=0, endIndex=MONITOR_BLOCK[k]-1;

	while (beginIndex < endIndex - 1 ){
		long middleIndex = (beginIndex + endIndex ) / 2;
		if ( MonitorBlock[k][middleIndex].beginIP <= middleIP )
			beginIndex = middleIndex;
		else if (MonitorBlock[k][middleIndex].beginIP > middleIP)
				endIndex = middleIndex;
	};
	hitFlag = 0;
	if ( endIndex - beginIndex !=1){
		printf("Wrong in binary search of monitor\n"); 
		printf("beginIndex=%ld, endIndex=%ld, beginIP=%lf, endIP=%lf, k=%d\n", beginIndex, endIndex, beginIP, endIP, k);
		exit(1);
	};

	// Determine whether the worm's scans overlap with the nearest monitoring block.
	// Again we assume the worm's scans in a unit time cannot overlap with two monitoring block because monitoring blocks
	// are distributed sparsely in the entire IPv4 space.

	for(long i=beginIndex; i<=beginIndex+1; i++){
		if (endIP <= MonitorBlock[k][i].endIP && endIP >=MonitorBlock[k][i].beginIP){
			hitFlag = 1; index = i; break;
		};
		if (beginIP <= MonitorBlock[k][i].endIP && beginIP >=MonitorBlock[k][i].beginIP){
			hitFlag = 2; index = i; break;
		};
		if (beginIP <= MonitorBlock[k][i].beginIP && endIP >= MonitorBlock[k][i].endIP){
			hitFlag = 3; index = i; break;
		};
	};
	if (hitFlag == 0) 
		return 0;  // not hit.
	if(hitFlag == 1) {
		double max = beginIP;
		if (max < MonitorBlock[k][index].beginIP) max = MonitorBlock[k][index].beginIP;
		hitNum = long(endIP - max+1);
		if (hitNum <0) {printf("Wrong in hitNum in monitorHit\n"); exit(1);};
		return hitNum;
	};
	if(hitFlag == 2) {
		hitNum = long(MonitorBlock[k][index].endIP - beginIP+1);
		if (hitNum <0) {printf("Wrong in hitNum in monitorHit\n"); exit(1);};
		return hitNum;
	};
	if (hitFlag ==3){
		hitNum = long(MonitorBlock[k][index].endIP - MonitorBlock[k][index].beginIP + 1);
		if (hitNum <0) {printf("Wrong in hitNum in monitorHit\n"); exit(1);};
		return hitNum;
	};
};
		


//---------------------------------------------------------------------------
		  
double normalGenerator( Normal_type normal){ // normal distribution generator.
    double temp, x ;
    static double Table[151]= 
					{0.5000,	0.5030,	0.5160,	0.5239,	0.5319, 
					0.5398,		0.5478,	0.5557,	0.5636,	0.5714,
					0.5793,		0.5871,	0.5948,	0.6026,	0.6103,
					0.6179,		0.6255,	0.6331,	0.6406,	0.6480,
					0.6554,		0.6628,	0.6700,	0.6772,	0.6844,
					0.6915,		0.6985,	0.7054,	0.7123,	0.7190,
                    0.7257,		0.7324,	0.7389,	0.7454,	0.7517,
					0.7580,		0.7642,	0.7703,	0.7764,	0.7823,
					0.7881,		0.7939,	0.7995,	0.8051,	0.8106,
					0.8159,		0.8212,	0.8264,	0.8315,	0.8365,
					0.8413,		0.8461,	0.8508,	0.8554,	0.8599,
					0.8643,		0.8686,	0.8729,	0.8770,	0.8810,
                    0.8849,		0.8888,	0.8925,	0.8962,	0.8997,
					0.90320,	0.90658,	0.90988,	0.91809,	0.91621,	
					0.91924,	0.92220,	0.92507,	0.92785,	0.93056, 
					0.93319,	0.93574,	0.93822,	0.94062,	0.94295,		
					0.94520,	0.94738,	0.94950,	0.95154,	0.95352, 
					0.95543,	0.95728,	0.95907,	0.96080,	0.96246,		
                    0.96407,	0.96562,	0.96712,	0.96856,	0.96995,		
					0.97128,	0.97257,	0.97381,	0.97500,	0.97615,		
					0.97725,	0.97831,	0.97932,	0.98030,	0.98124,		
					0.98214,	0.98300,	0.98382,	0.98461,	0.98537,
					0.98610,	0.98679,	0.98745,	0.98809,	0.98870,		
					0.98928,	0.98988,	0.99036,	0.99086,	0.99134,	
                    0.99180,	0.99224,	0.99266,	0.99305,	0.99343,
					0.99379,	0.99413,	0.99446,	0.99477,	0.99506,		
					0.99534,	0.99560,	0.99586,	0.99609,	0.99632, 
					0.99653,	0.99674,	0.99693,	0.99711,	0.99728,		
					0.99745,	0.99760,	0.99774,	0.99788,	0.99801, 
					0.99813,	0.99825,	0.99836,	0.99846,	0.99856,
					1.0   }; 
    temp =rand01();
    int sign = 1, i;
    if ( temp <0.5) {
        sign = -1;
        temp = 1 - temp;
    };
	x=0;
    for (i=0;i< 150; i++) 
        if ( temp <= Table[i] ) { 
            x = double( i ) / 50.0; 
            break;
        }
    if ( sign == -1 ) 
      x = 0 - x;
    temp = normal.average + x * sqrt(normal.variance); 
    // experiment require that normal distribution number to be non-negative.
    if ( temp <=0.000000000001) temp = 0.0000001;

    return temp;
    
}					

