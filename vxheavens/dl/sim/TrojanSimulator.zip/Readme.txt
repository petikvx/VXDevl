For years you have been able to test your virus scanner with the harmless "Eicar" test file. Using the just released "Trojan Simulator" you can now test your trojan scanner in the same manner, using a harmless demonstration trojan. This is a risk-free way to see how your security software behaves in a real-world situation.

Program details
---------------

Web page: http://www.misec.net/trojansimulator
Download: http://www.misec.net/products/TrojanSimulator.zip

Installation is simple: Simply unzip all files contained in TrojanSimulator.zip to any directory. To start, simply double-click TrojanSimulator.exe.

How it works
------------
When you run Trojan Simulator, you will be presented with a screen showing some informational text about Trojan Simulator. Clicking the Install button will install the demo trojan on your system. The demo trojan simulates a real trojan server by hiding its main window and writing an autostart entry to the registry. Clicking the Uninstall button removes the autostart entry from the registry and then unloads the demo trojan server from memory. While the demo trojan is running, you get a chance to observe the behavior of any installed security software.

The technical details are as follows: 

When run with the /install parameter, TSServ.exe loads into memory and adds an autostart entry to the registry. An informational dialog will pop up notifying that the demo server was successfully installed along with the path to the server and its process ID. Most trojans don't really present a dialog saying they've successfully installed themselves in your system, though! (Although many will present a fake error message to make it look like the executable file was corrupted or that some other problem occured that prevented the file from being run. In reality the trojan server is already running in memory when this dialog is shown.) 

When run with the /uninstall parameter, TSServ.exe removes its autostart entry and then unloads all copies of itself from memory. If you run TSServ.exe without any parameters, nothing will happen - the program simply starts and immediately exits.


Ways Trojan Simulator can be detected
-------------------------------------
When the Trojan Simulator server is installed, it will exist as an active process in memory. It will also have an autostart entry in the system registry. Most virus scanners are not that good at dealing with trojans, so it's likely that your virus scanner, if it detects the Trojan Simulator server, will neither be able to remove the process from memory nor be able to remove the registry entry. Any decent trojan scanner should take care of this if the server is detected.

The demo trojan server can be detected on the system in the following ways:

- By its file fingerprint. 

The demo trojan server file, named TSServ.exe, has a unique fingerprint that can be used by security software to detect its presence on a system. The file is packed with the executable packer UPX to reduce its size and to further simulate the behavior of a real trojan. Trojan servers are often packed to avoid detection by security software - see the note below for more information about this.

- By its in-memory fingerprint. 

Once TSServ.exe gets loaded into memory, it has a unique fingerprint in its code section. This can be used by security software to detect its presence in memory. Even though the server file is packed with the UPX executable packer, it always exists in memory in unpacked form. This means the fingerprint won't be the same as for the file on disk, but it also means that this is the perfect opportunity to detect the server, should a file scan have missed it.

- By the registry entry it creates

TSServ.exe creates an autostart entry in the Windows registry, under the key HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Run. The name of the entry is "TrojanSimulator" (without the quotes), and its value is the path to TSServ.exe, enclosed in quotes ("), and followed by the /install parameter. The type of the entry is REG_SZ (standard registry string value).

