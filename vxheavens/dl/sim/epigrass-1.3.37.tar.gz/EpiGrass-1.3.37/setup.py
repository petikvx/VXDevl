# -*- coding: utf-8 -*-
from distutils.core import setup 
import MySQLdb, os 
# Edit the lines below if you already have a MySQL server installed 
# with root user and password defined.
sqluser = 'root'
sqlpass = ''
host = 'localhost'
# Is this installation an upgrade?  1 if yes, 0 if no.
upgrade = 1
#===========================================================================
if not upgrade:
    con = None
    try:
        os.system('mysqladmin -u %s create epigrass -p%s'%(sqluser,sqlpass))
        con = MySQLdb.connect(host=host, port=3306, user=sqluser,passwd=sqlpass, db='epigrass')
        Cursor = con.cursor()
        Cursor.execute("GRANT ALL ON epigrass.* TO 'epigrass'@'localhost'IDENTIFIED BY 'epigrass';")
        print Cursor.fetchall()
    finally:
        if con:
            con.close()

setup(name='EpiGrass',
        version='1.3.37',
        description = 'Network epidemiology simulator',
        author = 'Flávio Codeço Coelho, Cláudia Torres Codeço',
        author_email = 'fccoelho@fiocruz.br',
        license = 'GPL',
        packages = ['Epigrass'],
        scripts = ['epigrass.py'],
        data_files = [('share/epigrass/demos',['demos/script.epg', 'demos/mesh.epg', 'demos/star.epg','demos/sitios2.csv','demos/edgesout.csv', 'demos/nodes.csv','demos/mesh.csv','demos/star.csv','demos/limites.map']),
                    ('share/epigrass/docs',['docs/userguide.pdf'])
                    ]
        )
