Welcome to LineZer0's first ezine ever!

Phew, finally we released our zine and
we hope you like it! Thanks for reading!

jack twoflower /linezero/metaphase

http://beam.to/lzo
