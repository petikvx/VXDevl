--------------------------------------------------------------------------------
                            Polymorph Matlab virus 
                                  by Positron
--------------------------------------------------------------------------------

Virus name: MatLab.Matrix.a
----------------------------

This  is the first polymorph Matlab  virus.  You  can find  lots  of  samples in 
"InfectedFiles" directory. KAV detect now all samples, but easy make a much more
harder poly engine in Matlab. 
Matlab is very interest ,  and still  include  lots  of  possibilities for virus
writers.
      
Positron
