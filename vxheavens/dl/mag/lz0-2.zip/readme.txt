hi there, I just wanna say a big thank you to the following people
that beta tested the zine release:

VirusBuster
Evul
Roadkil
Spyda
kr1zt
heXc
Zer0

Catch y'all around,
jackie

Carinthia/Austria/Europe 3rd july 2000 / 2:01pm
