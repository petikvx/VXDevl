This viewer uses state-of-the-art technology that not every computer out there in the world has.
Because of this fact I have organized the directories in a nice order, and everything is in text
format. Two of the documents in the articles directory are in MS Word format.

Controls for the viewer when viewing a document:

Left Mouse Button - scroll down
Right Mouse Button - scroll up
Up Arrow - scroll up
Down Arrow - scroll down
Left Arrow - scroll left
Right Arrow - scroll right
Space Bar - scroll down faster

There is a SECRET AREA that can be accessed by pressing a special key combination.
This key combination is usable any time the viewer is running.

I know this zine viewer may have a few bugs that make it not perfect, and the high end demands
of DirectX aren't good for compatiblity. For the next zine created a new design will be used to
achieve more compatibility for the various readers out there in the world. Some work has already
begun on the 2nd zine.

Enjoy!
VxF

RECOMMENDED MACHINE SPECS
1ghz+ processor
64mb ram
Win98+ (best test results achieved with win2k and xp)
DirectX 8.x+ (DirectX 9 recommended)