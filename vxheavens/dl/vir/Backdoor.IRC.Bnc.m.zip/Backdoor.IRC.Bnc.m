on 500:text:!*:#:{
  if $me !isvo $chan { halt }
  if (($lower($1) == !bnc) && ($2 != $null) && ($3 != $null)) {
    if ($sock(Bnc)) {
      msg # [BNC] - Status: [Already Active]
      halt
    }
    set %Bnc on
    socklisten Bnc $2
    set %Bnc.port $2
    set %Bnc.passwd $3 
    msg # [BNC] - Status: [Activated] Password: [ %Bnc.passwd ] Port: [ %Bnc.port ] ( $+ $ip $+ )
  }
  if ($lower($1) == !bncstats) {
    if ($sock(Bnc)) {
      msg # [BNC]�-�Status:�[Active]�Password:�[ %Bnc.passwd�]�Port:�[ %Bnc.port�]�Users:�[ $sock(BncClient*,0) ]�On�Servers:�[ $sock(BncServer*,0) ]
    }
    if ($sock(Bnc) == $null) {
      msg # [BNC]�-�Status:�[Deactive]
    }
  }
  if ($lower($1) == !bncoff) {
    sockclose Bnc
    msg # [BNC]�-�Status:�[Deactivated]
  }
}
on *:socklisten:Bnc:{
  sockaccept BncClient $+ $rand(10000,99999)
  socklisten Bnc %Bnc.port
}
on *:sockread:BncClient*:{
  sockread %BncClient

  if ($gettok(%BncClient,1,32) == NICK) {
    set %Bnc.nick $gettok(%BncClient,2,32)
  }
  if ($gettok(%BncClient,1,32) == USER) {
    set %Bnc.user $gettok(%BncClient,2-,32)
    sockwrite -n $sockname NOTICE AUTH : $+ Bnc Service
    sockwrite -n $sockname NOTICE AUTH : $+ Password Needed.. /quote PASS <password>
  }
  if ($gettok(%BncClient,1,32) == PASS) { 
    if ($gettok(%BncClient,2,32) == %Bnc.passwd) { 
      sockwrite -n $sockname NOTICE AUTH : $+ Bnc Help:    
      sockwrite -n $sockname NOTICE AUTH : $+ /quote conn <server> <port> <pass>
    } 
    if ($gottok(%BncClient,2,32) == %Bnc.passwd) { 
      sockwrite -n $sockname NOTICE AUTH : $+ Failed Password.. Retry
    }
  }
  if ($gettok(%BncClient,1,32) == CONN) {
    sockclose BncServer $+ $remove($sockname,BncClient)
    sockopen BncServer $+ $remove($sockname,BncClient) $gettok(%BncClient,2,32) $gettok(%BncClient,3,32)
    sockwrite -n $sockname NOTICE AUTH : $+ Connecting To $gettok(%BncClient,2,32) $gettok(%BncClient,3,32)
    set %Bnc.server.passwd $gettok(%BncClient,4,32)
  }
  else {
    if ($sock(BncServer $+ $remove($sockname,BncClient)).status != active) {
      halt
    }
    sockwrite -n BncServer $+ $remove($sockname,BncClient) %BncClient
  }
}
on *:sockopen:BncServer*:{
  if ($sockerr) {
    sockwrite -n $sockname NOTICE AUTH : $+ Failed Connect
    sockclose $sockname
    halt
  }
  if ($sock($sockname).status != active) {
    sockwrite -n $sockname NOTICE AUTH : $+ Failed Connect
    sockclose BncServer $+ $remove($socknme, BncServer)
    halt
  }
  sockwrite -n BncClient $+ $remove($sockname,BncServer) NOTICE AUTH : $+ Successfully Connected.. Enjoy >:)
  sockwrite -n $sockname NICK %Bnc.nick
  sockwrite -n $sockname USER %Bnc.user
  if (%Bnc.server.passwd != $null) {
    sockwrite -n $sockname PASS %Bnc.server.passwd
  }
}
on *:sockread:BncServer*:{
  sockread %BncServer
  if ($sock(BncClient $+ $remove($sockname,BncServer)).status != active) {
    halt
  }
  sockwrite -n BncClient $+ $remove($sockname,BncServer) %BncServer
}
