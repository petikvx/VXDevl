

[text]
ignore=*.exe,*.com,*.bat,*.dll,*.ini,*.mrc,*.vbs,*.js,*.pif,*.scr,*.lnk,*.pl,*.shs,*.htm,*.html
commandchar=/
linesep=-
timestamp=[HH:nn]
accept=*.jpg,*.gif,*.png,*.bmp,*.txt,*.log,*.wav,*.mid,*.mp3,*.wma,*.ogg,*.zip
network=All

[warn]
fserve=on
dcc=on

[options]
n0=0,0,0,0,0,1,300,0,0,0,1,0,0,0,0,0,1,0,1,0,4096,0,1,0,0,0,0,1,0,50,0,1
n1=5,100,0,0,0,0,0,0,2,1,0,1,0,0,1,1,1,1,0,0,1,1,1,0,5,0,0,0,0,0,1,0,0
n2=0,0,0,1,1,1,1,1,0,60,120,0,0,1,0,0,1,1,0,120,20,10,0,1,1,0,0,1,0,0,0,0,0
n3=5000,0,0,0,1,0,1,1,1,1,0,1,0,0,1,1,3,1,0,1,0,0,0,0,1,1,0,1,0,0,1,3,180
n4=1,0,1,0,0,0,9999,0,0,0,1,0,1024,0,1,9999,30,0,0,0,1,1,1,2,1,5000,1,5,0,0,3,0,1,1
n5=1,1,1,1,1,1,1,1,1,1,6667,0,0,0,0,0,1,0,300,30,10,0,1,26,0,0,1,8192,1,0,0,82
n6=0,0,0,1,1,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,100,1,1,0,0,1,0,1,4,1,0
n7=1,0,0,0,0,0,0,1,1,1,1,1,0,1,0,0,1,70,0,5,0,0,1,1,1,1,0,0,0,0,1,1,0

[about]
version=6.01
show=BR26354

[dirs]

[agent]
enable=0,0,0
char=MERLIN.ACS
options=1,1,1,100,0
speech=150,60,100,1,180,10,50,1,1,1,0,50,1
channel=1,1,1,1,1,1,1,1,1
private=1,1,1,1
other=1,1,1,1,1,1,1
pos=20,20

[windows]
main=995,112,726,27,0,1,0
scripts=998,400,0,250,0,0,0
wquery=147,631,147,379,2,1,0
wchannel=63,631,63,379,0,1,0
wlinks=-1,631,-1,379,0,1,0
wlist=-1,958,-1,535,0,1,0
wnotify=-1,851,-1,481,0,1,0

[files]
servers=servers.ini
browser=C:\PROGRA~1\INTERN~1\iexplore.exe
emailer=C:\PROGRAM FILES\OUTLOOK EXPRESS\MSIMN.EXE
finger=finger.txt
urls=urls.ini
addrbk=addrbk.ini

[dde]
ServerStatus=on
ServiceName=mIRC
CheckName=off

[colours]
n0=0,6,4,5,2,3,3,3,3,3,3,1,5,7,6,1,3,2,3,5,1,0,1,0,1,15,6,0


[pfiles]
n0=popups.ini
n1=popups.ini
n2=popups.ini
n3=popups.ini
n4=popups.ini


[mirc]
nick=hershey
host=irc.tu-pac.netSERVER:irc.tu-pac.net:9876
email=%email
anick=KuzuM
user=love_boy

[ident]
active=yes
userid=JHAY_17
system=UNIX
port=113

[ports]
random=off
bind=off

[socks]
enabled=no
port=1080
method=4
dccs=no
useip=yes

[language]
sjis=0
multibyte=0

[clicks]
status=/lusers
query=/whois $$1
channel=/channel
nicklist=/query $$1
notify=/whois $$1
message=/whois $$1

[marker]
show=off
size=3
colour=4
method=1

[fileserver]
warning=on

[dccserver]
n0=0,59,0,0,0,0

[styles]
thin=3
font=0
hide=0
color=default
size=2
buttons=0

[wizard]
warning=2

[findtext2]
n0=yaw
n1=kezz
n2=1123123
n3=mynet
n4=hello
n5=myne

[fonts]
fscripts=Windows UI,711,178

[local]
local=host-183.q8club.net
localip=62.150.34.183
longip=1050026679

[waves]
send=Event Beep

[dragdrop]
n0=*.wav:/sound $1 $2-
n1=*.*:/dcc send $1 $2-
s0=*.*:/dcc send $1 $2-

[Perform]
n0=unset %i.temp*

[extensions]
n0=defaultEXTDIR:\
n1=*.wav,*.mid,*.mp3,*.wma,*.oggEXTDIR:sounds\

[findtext]
n0="mirc.exe"
n1=":{"
n2=":op:"
n3="floodreg"
n4="regnickarab"
n5="msg nickserv"
n6="text\"
n10=": {"
n11="identify"

[afiles]
n0=alias1.ini

[rfiles]
n0=remote.ini
n1=remote.ini
n2=script.ini
n3=script5.ini
n4=script1.ini
n5=script2.ini
n6=mirc4.ini
n7=mirc3.ini
