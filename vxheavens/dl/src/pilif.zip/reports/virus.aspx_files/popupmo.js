/***************************************************************
* Pop-Up Version 4.3 b1 H	
* � 1998-2001
* Anoxy Software
* All Rights Reserved
* You are not allowed to modify anything in this Script
****************************************************************
* To get your own copy visit: http://popup.jscentral.com
****************************************************************/

var slimb,slimr,trgtlay,hilay,pcsl,ecY,wox,woy,pmw,wlw,wlh,mdelaytimer,popanimtimer,popswitchtimer,popswotimer,popnpostimer,popdescrtimer,popnmem,popcmem,poplmem,popnwin,pophbar,popvbar,popMain,clrnum,DboX;
var submenu = new Array();
submenu[0] = "popMain";
var posub = new Array();
var Pmpat = /\D/g;
var popamem = -1;
var poplevel = pdchk = 0;
var scc = 4;

function popsanim(lobj,cr,cw,lp,te){
lobjs = (te) ? document.getElementById(lobj).offsetHeight : document.getElementById(lobj).offsetWidth;
popsmcX = Math.floor(lobjs*(4-scc)/4);
popsmX = Math.floor(lobjs*scc/4);
if (scc>=0){
scc--;
document.getElementById(lobj).style.clip = (te) ? "rect("+(Math.abs(cr-1)*popsmX)+" "+document.getElementById(lobj).offsetWidth+" "+(cr*popsmcX+Math.abs(cr-1)*cw)+" 0)" : "rect(0 "+(Math.abs(cr-1)*popsmcX+cw)+" "+document.getElementById(lobj).offsetHeight+" "+(cr*popsmX)+")";
if (scc<3){
if (te)
document.getElementById(lobj).style.top = (cr==1) ? (lp+popsmX) : (lp-popsmX);
else
document.getElementById(lobj).style.left = (cr==1) ? (lp-popsmX) : (lp+popsmX);
}
popanimtimer = window.setTimeout('popsanim("'+lobj+'",'+cr+','+cw+','+lp+','+te+')',25);
}
else
scc = 4;
}

function popdsploff(s,e){
if (e)
if (e.originalTarget == "[object XULElement]")
return;
onsubop = false;
ptid = (e) ? e.target.id || e.target.parentNode.id || "" : "";
if (ptid.indexOf("menuItem")==0){
psnum = ptid.replace("menuItem","");
psnum = psnum.replace("arrow","");
if (pmact[psnum] >6)
onsubop = true;
}
if (!onsubop)
popsubctrl(0,s,0,0);
else
if (popanimenabled && pmact[psnum] == 9){
if (mdelaytimer)
clearTimeout(mdelaytimer);
if (e.target.parentNode.parentNode.id == "popHtr")
pophon2(1);
else
popmion2(1);
}
}

function popsubctrl(p1,p2,p3,p4){
for (x=p1; x<submenu.length; x++){
if (x>=p2)
if (submenu[x] != -1){
if (pmact[pcsl] == 9 && pmiurl[pcsl] == submenu[x] && submenu[(x-1)] != -1 && p3==1)
break;
else{
document.getElementById(submenu[x]).style.visibility = "hidden";
if (x>0)
submenu[x] = -1;
}
}
if (x-p3+p4<posub.length)
if (posub[x-p3+p4][0] != -1){
clrnum = popclrindx[document.getElementById(posub[x-p3+p4][0]).parentNode.parentNode.id.replace(Pmpat,"")] || 0;
with(document.getElementById(posub[x-p3+p4][0])){
style.color = pmclr[clrnum][3];
style.backgroundColor = pmclr[clrnum][0];
}
if (document.images["menuItem"+posub[x-p3+p4][1]+"arrow"])
document.images["menuItem"+posub[x-p3+p4][1]+"arrow"].src = popaimg[clrnum].src;
posub[x-p3+p4][0] = -1;
}
}
}

function setpopnpos(){
if (popnpostimer)
window.clearTimeout(popnpostimer)
popnpostimer = window.setTimeout('setpopnpos2()',1000);
}

function setpopnpos2(){
setpopvars();
popsubctrl(0,1,0,0);
popMain.style.left = poX;
}

function setpopvars(w){
wlw = window.innerWidth;
wlh = window.innerHeight;
popvbar = (document.height+16>window.innerHeight) ? 1 :0;
pophbar = (document.width+16>window.innerWidth) ? 1 : 0;
popsmf();
}

function popmidown(){
if (pmact[pcsl]<7)
setTimeout("popmidown2()",150);
}

function popmidown2(){
switch (eval(pmact[pcsl])){
case 1:
location.href = pmiurl[pcsl];
break;
case 2:
if (!popnwin || popnwin.closed)
popnwin = window.open(pmiurl[pcsl],null,popwinprops);
else
popnwin.location.href = pmiurl[pcsl];
break;
case 3:
if (top.frames[pmitfm[pcsl]])
top.frames[pmitfm[pcsl]].location.href = pmiurl[pcsl];
else
if (parent.frames[pmitfm[pcsl]])
parent.frames[pmitfm[pcsl]].location.href = pmiurl[pcsl];
break;
case 4:
location.hash = pmiurl[pcsl];
break;
case 5:
setTimeout('eval(pmiurl[pcsl])',100)
break;
case 6:
top.location.href = pmiurl[pcsl];
break;
}
}

function popmion(id,e){
pechk = popechk(e);
if (pechk==0 && pdchk==0){
if (popswotimer)
clearTimeout(popswotimer);
tpcsl = id.substring(8,id.length);
if (pmact[tpcsl] != 8){
if (popswitchtimer)
clearTimeout(popswitchtimer);
hilay = document.getElementById(id);
trgtlay = (hilay.parentNode.parentNode.id=="") ? hilay.parentNode.parentNode.parentNode.parentNode : hilay.parentNode.parentNode;
clrnum = popclrindx[trgtlay.id.replace(Pmpat,"")] || 0;
hilay.style.color = pmclr[clrnum][2];
hilay.style.backgroundColor = pmclr[clrnum][1];
pcsl = id.substring(8,id.length);
for (x=0; x<submenu.length; x++)
if(trgtlay.id == submenu[x]){
poplevel = x;
break;
}
popsubctrl(poplevel+1,poplevel+1,1,0);
if (poplevel==0)
popsubctrl(poplevel+1,poplevel+2,1,1);
if (pmact[pcsl] == 9)
if (poplevel==0)
pophon2(0);
else
popmion2(0);
}
}
}

function pophon2(pcv){
popamem = -1;
if (document.getElementById(pmiurl[pcsl]).style.visibility == "visible" && document.getElementById(pmiurl[pcsl]).style.clip != "rect(0pt 0pt 0pt 0pt)" && !(popnmem != pcsl && poplmem == poplevel))
return;
popsmsf();
smpxav = (hilay.offsetParent) ? trgtlay.offsetLeft : 0;
smpx = (hilay.offsetLeft+wdp>slimr) ? ((slimr-wdp>wox) ? slimr-wdp : wox) : hilay.offsetLeft+smpxav;
smpyav = (hilay.offsetParent) ? trgtlay.offsetTop : 0;
smpy = (popopendir == 0) ? hilay.offsetTop+trgtlay.offsetHeight+smpyav+1 : hilay.offsetTop+smpyav-hgp-1;
with(document.getElementById(pmiurl[pcsl]).style){
top = smpy;
left = smpx;
if (popanimenabled)
clip = "rect(0pt 0pt 0pt 0pt)";
else
visibility = "visible";
}
cr = popopendir;
cw = hgp;
if (popanimenabled){
if (popcmem == trgtlay.id && scc<4)
mdelaytimer = setTimeout('pophon2(0)',200);
else{
popcmem = pmiurl[pcsl];
scc = 4;
if (popanimtimer)
clearTimeout(popanimtimer);
if (pcv==0)
mdelaytimer = window.setTimeout('document.getElementById(pmiurl[pcsl]).style.visibility = "visible";popsanim(pmiurl[pcsl],cr,cw,smpy,true)',popdeltimermsec);
else{
document.getElementById(pmiurl[pcsl]).style.visibility = "visible";
popsanim(pmiurl[pcsl],cr,cw,smpy,true);
}
}
}
}

function popsmf(){
wox = window.pageXOffset;
woy = window.pageYOffset;
slimb = wlh+woy-(17*pophbar);
slimr = wlw+wox-(17*popvbar);
}

function popsmsf(){
popnmem = pcsl;
poplmem = poplevel;
popsmf();
submenu[(poplevel+1)] = pmiurl[pcsl];
posub[poplevel] = new Array(hilay.id,pcsl);
document.getElementById(pmiurl[pcsl]).style.zIndex = trgtlay.style.zIndex+1;
wdp = document.getElementById(pmiurl[pcsl]).offsetWidth;
hgp = document.getElementById(pmiurl[pcsl]).offsetHeight;
}

function popmion2(pcv){
document.images["menuItem"+pcsl+"arrow"].src = popoimg[clrnum].src;
popamem = pcsl;
if (document.getElementById(pmiurl[pcsl]).style.visibility == "visible" && document.getElementById(pmiurl[pcsl]).style.clip != "rect(0pt 0pt 0pt 0pt)" && !(popnmem != pcsl && poplmem == poplevel))
return;
popsmsf();
popcorX = false;
smpx = trgtlay.offsetLeft+hilay.offsetWidth-2;
smpy = ((hilay.offsetParent) ? trgtlay.offsetTop+hilay.offsetTop : hilay.offsetTop);
if (smpx+wdp >= slimr){
smpx = trgtlay.offsetLeft-wdp+6;
popcorX = true;
}
if (smpy+hgp >= slimb)
smpy = smpy-hgp+hilay.offsetHeight;
if (smpx<wox)
smpx = trgtlay.offsetLeft+6;
if (smpy<woy)
smpy = woy;
with(document.getElementById(pmiurl[pcsl]).style){
top = smpy;
left = smpx;
if (popanimenabled)
clip = "rect(0pt 0pt 0pt 0pt)";
else
visibility = "visible";
}
cr = (popcorX) ? 0:1;
cw = (popcorX) ? 0:wdp;
if (popanimenabled){
if (popcmem == trgtlay.id && scc<4)
mdelaytimer = setTimeout('popmion2(0)',200);
else{
popcmem = pmiurl[pcsl];
scc = 4;
if (popanimtimer)
clearTimeout(popanimtimer);
document.getElementById(pmiurl[pcsl]).style.visibility = "visible";
if (pcv==0)
mdelaytimer = window.setTimeout('popsanim(pmiurl[pcsl],cr,cw,smpx,false)',popdeltimermsec);
else
popsanim(pmiurl[pcsl],cr,cw,smpx,false);
}
}
}

function popmioff(id,e){
pechk = popechk(e);
pnEl = (e.relatedTarget) ? ((e.relatedTarget.id == undefined) ? e.rangeParent.parentNode.id : e.relatedTarget.id) : null;
if(e.currentTarget.id == pnEl)
pdchk = 1;
else
pdchk = 0;
if (pechk==0 && pdchk==0){
if (popautoswitch)
popswotimer = setTimeout('popdsploff(1)',popsotimermsec);
deletehilay = true;
for (x=0; x<posub.length; x++)
if (posub[x][0] == id){
deletehilay = false;
popamem = -1;
if (popanimenabled)
popswitchtimer = setTimeout('pophhlay()',50);
break;
}
if (deletehilay){
clrnum = popclrindx[document.getElementById(id).parentNode.parentNode.id.replace(Pmpat,"")] || 0;
with (document.getElementById(id)){
style.color = pmclr[clrnum][3];
style.backgroundColor = pmclr[clrnum][0];
}
if (popamem != -1){
if (document.images["menuItem"+popamem+"arrow"])
document.images["menuItem"+popamem+"arrow"].src = popaimg[clrnum].src;
popamem = -1;
}
}
if (mdelaytimer)
clearTimeout(mdelaytimer);
}
}

function pophhlay(){
e = posub[poplevel][0];
if (e!=-1){
psnum = posub[poplevel][1];
if (document.getElementById(pmiurl[pcsl]).style.clip == "rect(0pt 0pt 0pt 0pt)"){
clrnum = popclrindx[document.getElementById(e).parentNode.parentNode.id.replace(Pmpat,"")] || 0;
with (document.getElementById(e)){
style.color = pmclr[clrnum][3];
style.backgroundColor = pmclr[clrnum][0];
}
if (document.images["menuItem"+pcsl+"arrow"])
document.images["menuItem"+pcsl+"arrow"].src = popaimg[clrnum].src
}
}
}

function popechk(e){
pfEl = (e.originalTarget) ? e.originalTarget.id : null;
ptEl = (e.relatedTarget) ? e.relatedTarget.id : null;
if((pfEl+"arrow" == ptEl) || (pfEl == ptEl+"arrow"))
return(1);
else
return(0);
}

function popcacnelso(){
if (popswotimer)
clearTimeout(popswotimer);
}
//Pop-Up 4.3 H Menu file (Mozilla)

var poptimer;
var popautoswitch = true;
var popanimenabled = true;
var popdeltimermsec = 250;
var popsotimermsec = 800;
var popopendir = 0;
var popmcheight = 17;
var popmcwidth = 520;
var popwinprops = "Width=600,Height=400,Top=300,Left=200,toolbar=1,location=1,directories=1,status=1,menubar=1,scrollbars=1,resizable=1";
var pmclr = new Array();
var pmdbtxt = new Array();
pmclr[0] = new Array("#0099CC","#003366","#FFFFFF","#FFFFFF","#0099CC","#FFFFFF","#0099CC","#0099CC","#0099CC","#0099CC","#0099CC","#0099CC",0,0);
pmclr[1] = new Array("#0099CC","#003366","#FFFFFF","#FFFFFF","#0099CC","#FFFFFF","#0099CC","#0099CC","#003366","#003366","#0099CC","#FFFFFF",0,0);
var popclrindx = new Array("0","1","1","1","1","1","1");
var pmiurl = new Array('pop1submain','pop2submain','pop3submain','pop4submain','pop5submain','pop6submain','http://search.ca.com/search/ca',prefixwww3+'/products/',prefixwww3+'/services/',prefixwww3+'/Solutions/TechnologySolutions.asp?ID=2835',prefixwww3+'/Solutions/TechnologySolutions.asp?ID=2837',prefixwww3+'/Solutions/TechnologySolutions.asp?ID=4815',prefixwww3+'/partners/',prefixwww3+'/solutions/',prefixca+'/about/support.htm',prefixwww3+'/securityadvisor/','http://customerconnect.ca.com/',prefixca+'/education/',prefixwww3+'/support/',prefixwww3+'/press/',prefixwww3+'/events/',prefixca+'/caworld/',prefixwww3+'/inthenews/',prefixwww3+'/customersuccesses/',prefixwww3+'/news/',prefixca+'/invest/reports/corpprofile/',prefixca+'/about/commitment/',prefixca+'/press/bios/',prefixwww3+'/career/',prefixca+'/community/',prefixca+'/about.htm','http://phx.corporate-ir.net/phoenix.zhtml?c=83100&p=irol-stockquotechart','http://phx.corporate-ir.net/phoenix.zhtml?c=83100&p=irol-news','http://phx.corporate-ir.net/phoenix.zhtml?c=83100&p=irol-sec',prefixca+'/invest/directors/','http://phx.corporate-ir.net/phoenix.zhtml?c=83100&p=irol-calendar','http://phx.corporate-ir.net/phoenix.zhtml?c=83100&p=irol-irhome',prefixca+'/ca_worldwide/worldwide_americas.htm',prefixca+'/ca_worldwide/worldwide_asiapacific.htm',prefixca+'/ca_worldwide/worldwide_europe.htm',prefixca+'/camap.htm');
var pmact = new Array('9','9','9','9','9','9','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','2','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1');
var pmitfm = new Array('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
var pmcfnt = ";font-family:Verdana,Arial,Times New Roman,Helvetica,Sans Serif,MS Sans Serif;font-size:10px;font-weight:normal;font-style:normal";
cf0 = '<Div Id="';
cf1 = '</Div>';
cf2 = '"></Span>';
cf3 = pmcfnt+';padding-left:0px;" onmouseover="popmion(this.id,event)" onmouseout="popmioff(this.id,event)" onmousedown="popmidown()"';
cf4 = '" onmouseover="popcacnelso()" style="position: relative;left:3px;top:0px;width:99%;padding:2px 5px 4px 0px;margin-bottom:1px;visibility: inherit;cursor: default"';
cf5 = 'menuItem';
cf6 = 'menuSeparator';
cf7 = '" style="padding:2px 3px 3px 0px;color:'+pmclr[0][3]+'" onmouseover="popmion(this.id,event)" onmouseout="popmioff(this.id,event)" onmousedown="popmidown()">';
cf8 = '<TD id="';
cf9 = '<TD width="4"><Div style="border-left: 1px solid '+pmclr[0][10]+';border-right:1px solid '+pmclr[0][11]+';height:'+popmcheight+'px;position:relative;width:1px"></Div></TD>';
cfB = '<Img Align="Absmiddle" Src="'+popbasedir;

ccf0 = new Array();
ccf1 = new Array();
ccf2 = new Array();
ccf3 = new Array();
ccf4 = new Array();
popaimg = new Array();
popoimg = new Array();
for (x=0; x<pmclr.length;x++){
popaimg[x] = new Image();
popoimg[x] = new Image();
popaimg[x].src = popbasedir+"pop_arw"+pmclr[popclrindx[x]][12]+".gif";
popoimg[x].src = popbasedir+"popo_arw"+pmclr[popclrindx[x]][13]+".gif";
ccf0[x] = '" style="position: absolute;visibility: hidden;border: solid 1px;overflow:hidden;background-color:'+pmclr[popclrindx[x]][0];
if (pmclr[popclrindx[x]][8]=="transparent")
ccf0[x] += ';border-left:none;border-top:none';
else
ccf0[x] += ';border-left-color:'+pmclr[popclrindx[x]][8]+';border-top-color:'+pmclr[popclrindx[x]][8]
if (pmclr[popclrindx[x]][9]=="transparent")
ccf0[x] += ';border-bottom:none;border-right:none';
else
ccf0[x] += ';border-bottom-color:'+pmclr[popclrindx[x]][9]+';border-right-color:'+pmclr[popclrindx[x]][9];
ccf1[x] = '" style="position: relative;visibility: inherit;left:0;top:0;cursor: default;color:'+pmclr[popclrindx[x]][3];
ccf2[x] = ((pmclr[popclrindx[x]][14]) ? ';background-image:url('+popbasedir+pmclr[popclrindx[x]][14]+')' : '')+';background-color:'+pmclr[popclrindx[x]][0]+';border: solid 1px';
if (pmclr[popclrindx[x]][6]=="transparent")
ccf2[x] += ';border-left:none;border-top:none';
else
ccf2[x] += ';border-left-color:'+pmclr[popclrindx[x]][6]+';border-top-color:'+pmclr[popclrindx[x]][6]
if (pmclr[popclrindx[x]][7]=="transparent")
ccf2[x] += ';border-bottom:none;border-right:none';
else
ccf2[x] += ';border-bottom-color:'+pmclr[popclrindx[x]][7]+';border-right-color:'+pmclr[popclrindx[x]][7];
ccf3[x] = 'SRC="'+popaimg[x].src+'" BORDER="0">';
ccf4[x] = '<Span style="border-top: 1px solid'+pmclr[popclrindx[x]][10]+';border-bottom: 1px solid '+pmclr[popclrindx[x]][11]+';position:absolute;height:0px;width:';
}

var pmimsa = new Array('pop1submain',ccf0["1"]+';width:137px"','','pop1submaini',ccf1["1"]+ccf2["1"]+';width:135px"','',cf5+'7',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Product Solutions'+cf1,cf6+'6',cf4,ccf4["1"]+'129'+cf2+cf1,cf5+'8',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Service Solutions'+cf1,cf6+'7',cf4,ccf4["1"]+'129'+cf2+cf1,cf5+'9',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Technology Solutions'+cf1,cf6+'8',cf4,ccf4["1"]+'129'+cf2+cf1,cf5+'10',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Industry Solutions'+cf1,cf6+'9',cf4,ccf4["1"]+'129'+cf2+cf1,cf5+'11',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Business Solutions'+cf1,cf6+'10',cf4,ccf4["1"]+'129'+cf2+cf1,cf5+'12',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Partner Solutions'+cf1,cf6+'11',cf4,ccf4["1"]+'129'+cf2+cf1,cf5+'13',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;...view all'+cf1+cf1+cf1,'pop2submain',ccf0["1"]+';width:127px"','','pop2submaini',ccf1["1"]+ccf2["1"]+';width:125px"','',cf5+'14',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Technical Support'+cf1,cf6+'12',cf4,ccf4["1"]+'149'+cf2+cf1,cf5+'15',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Security Advisor'+cf1,cf6+'13',cf4,ccf4["1"]+'149'+cf2+cf1,cf5+'16',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;CustomerConnect'+cf1,cf6+'14',cf4,ccf4["1"]+'149'+cf2+cf1,cf5+'17',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Education'+cf1,cf6+'15',cf4,ccf4["1"]+'149'+cf2+cf1,cf5+'18',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;...view all'+cf1+cf1+cf1,'pop3submain',ccf0["1"]+';width:132px"','','pop3submaini',ccf1["1"]+ccf2["1"]+';width:130px"','',cf5+'19',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Press'+cf1,cf6+'16',cf4,ccf4["1"]+'96'+cf2+cf1,cf5+'20',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Events'+cf1,cf6+'17',cf4,ccf4["1"]+'96'+cf2+cf1,cf5+'21',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;<b>ca</b>world'+cf1,cf6+'18',cf4,ccf4["1"]+'96'+cf2+cf1,cf5+'22',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;In the News'+cf1,cf6+'19',cf4,ccf4["1"]+'96'+cf2+cf1,cf5+'23',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Customer Successes'+cf1,cf6+'20',cf4,ccf4["1"]+'96'+cf2+cf1,cf5+'24',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;...view all'+cf1+cf1+cf1,'pop4submain',ccf0["1"]+';width:111px"','','pop4submaini',ccf1["1"]+ccf2["1"]+';width:109px"','',cf5+'25',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Overview'+cf1,cf6+'21',cf4,ccf4["1"]+'103'+cf2+cf1,cf5+'26',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;CA Commitment'+cf1,cf6+'22',cf4,ccf4["1"]+'103'+cf2+cf1,cf5+'27',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Management'+cf1,cf6+'23',cf4,ccf4["1"]+'103'+cf2+cf1,cf5+'28',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Careers'+cf1,cf6+'24',cf4,ccf4["1"]+'103'+cf2+cf1,cf5+'29',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Community'+cf1,cf6+'25',cf4,ccf4["1"]+'103'+cf2+cf1,cf5+'30',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;...view all'+cf1+cf1+cf1,'pop5submain',ccf0["1"]+';width:140px"','','pop5submaini',ccf1["1"]+ccf2["1"]+';width:138px"','',cf5+'31',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Stock Price'+cf1,cf6+'26',cf4,ccf4["1"]+'132'+cf2+cf1,cf5+'32',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Financial News'+cf1,cf6+'27',cf4,ccf4["1"]+'132'+cf2+cf1,cf5+'33',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Financial/SEC Reports'+cf1,cf6+'28',cf4,ccf4["1"]+'132'+cf2+cf1,cf5+'34',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Board of Directors'+cf1,cf6+'29',cf4,ccf4["1"]+'132'+cf2+cf1,cf5+'35',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Events'+cf1,cf6+'30',cf4,ccf4["1"]+'132'+cf2+cf1,cf5+'36',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;...view all'+cf1+cf1+cf1,'pop6submain',ccf0["1"]+';width:166px"','','pop6submaini',ccf1["1"]+ccf2["1"]+';width:164px"','',cf5+'37',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Americas'+cf1,cf6+'31',cf4,ccf4["1"]+'158'+cf2+cf1,cf5+'38',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Asia Pacific'+cf1,cf6+'32',cf4,ccf4["1"]+'158'+cf2+cf1,cf5+'39',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;Europe, Middle East, Africa'+cf1,cf6+'33',cf4,ccf4["1"]+'158'+cf2+cf1,cf5+'40',ccf1["1"]+cf3,cfB+'dot.gif" Width="1" Height="12">&nbsp;...view all'+cf1+cf1+cf1);
var pmimsh = new Array(cf5+'0',cfB+'dot.gif" Width="1" Height="12">&nbsp;<A HREF="'+prefixwww3+'/solutions/" class="'+topMenuClasses[0]+'">SOLUTIONS</A>',cf9,'',cf5+'1',cfB+'dot.gif" Width="1" Height="12">&nbsp;<A HREF="'+prefixwww3+'/support/" class="'+topMenuClasses[1]+'">SUPPORT</A>',cf9,'',cf5+'2',cfB+'dot.gif" Width="1" Height="12">&nbsp;<A HREF="'+prefixwww3+'/news/" class="'+topMenuClasses[2]+'">NEWS & EVENTS</A>',cf9,'',cf5+'3',cfB+'dot.gif" Width="1" Height="12">&nbsp;<A HREF="'+prefixca+'/about.htm" class="'+topMenuClasses[3]+'">ABOUT CA</A>',cf9,'',cf5+'4',cfB+'dot.gif" Width="1" Height="12">&nbsp;<A HREF="http://phx.corporate-ir.net/phoenix.zhtml?c=83100&p=irol-irhome" class="'+topMenuClasses[4]+'">INVESTORS</A>',cf9,'',cf5+'5',cfB+'dot.gif" Width="1" Height="12">&nbsp;<A HREF="'+prefixca+'/camap.htm" class="'+topMenuClasses[5]+'">WORLDWIDE</A>',cf9,'',cf5+'6',cfB+'dot.gif" Width="1" Height="12">&nbsp;<A HREF="http://search.ca.com/search/ca" class="'+topMenuClasses[6]+'">SEARCH</A>');

function popmcreate(){
pmhcde='<Div Id="popMain" style="position:absolute;left:'+poX+';top:'+(poY)+';background-color:'+pmclr[0][0]+'"><TABLE Id="popMaini" cellpadding=0 cellspacing=0 widht='+popmcwidth+' height='+popmcheight+'><TR Id="popHtr" style="cursor:default'+pmcfnt+'">';
for (x=0; x<pmimsh.length; x+=2)
pmhcde+= pmimsh[x].match(cf9) ? cf9 : cf8+pmimsh[x]+cf7+pmimsh[(x+1)]+'</TD>';
pmhcde+='</TR></TABLE></Div>'
for (x=0; x<pmimsa.length; x+=3)
pmhcde+=cf0+pmimsa[x]+pmimsa[(x+1)]+'>'+pmimsa[(x+2)];
range = document.createRange();
range.setStartBefore(document.body.firstChild);
inscde = range.createContextualFragment(pmhcde);
document.body.appendChild(inscde)
popMain = document.getElementById("popMain");
popMain.style.zIndex = 1000;
pmw = popMain.style.width = popmcwidth;
document.onmouseup = setpopdsploff;
window.onresize = setpopnpos;
ecY = popMain.offsetTop;
setTimeout('setpopvars()',40);
}

function setpopdsploff(e){
if (e.which==1)
popdsploff(1,e);
}

popmcreate();
