//Pop-Up
var page = new String(location.pathname.toLowerCase());
var host = new String(location.hostname.toLowerCase());
var pageURL = new String(location.href.toLowerCase());

var topMenuClasses = new Array("globalnav","globalnav","globalnav","globalnav","globalnav","globalnav","globalnav");
switch (page.substring(0,5))
{ 
	case "/solu":
		topMenuClasses[0] = "globalnavon";
		break;
	case "/tria":
		topMenuClasses[0] = "globalnavon";
		break;
	case "/part":
		topMenuClasses[0] = "globalnavon";
		break;
	case "/serv":
		topMenuClasses[0] = "globalnavon";
		break;
	case "/viru":
		topMenuClasses[1] = "globalnavon";
		break;
	case "/supp":
		topMenuClasses[1] = "globalnavon";
		break;
	case "/beta":
		topMenuClasses[1] = "globalnavon";
		break;
	case "/news":
		topMenuClasses[2] = "globalnavon";
		break;
	case "/pres":
		topMenuClasses[2] = "globalnavon";
		break;
	case "/even":
		topMenuClasses[2] = "globalnavon";
		break;
	case "/succ":
		topMenuClasses[2] = "globalnavon";
		break;
	case "/inth":
		topMenuClasses[2] = "globalnavon";
		break;
	case "/quot":
		topMenuClasses[2] = "globalnavon";
		break;		
	case "/anal":
		topMenuClasses[3] = "globalnavon";
		break;
	case "/cto/":
		topMenuClasses[3] = "globalnavon";
		break;
	case "/care":
		topMenuClasses[3] = "globalnavon";
		break;
}

var hostca = host.substring(0,12);
page = page.substring(0,10);
var prefixwww3 = "";
var prefixca = "http://www.ca.com";
if (window.location.protocol == "http:")
{
if ((host.substring(0,2) == "ca") || host.substring(0,6) == "www.ca")
{
prefixwww3 = "http://www3.ca.com";
prefixca = "";
}
if (page == ("/register/") || page == ("/channels/") || hostca == ("causergroups") || hostca == ("phx.corporat"))
	{
	prefixwww3 = "http://www3.ca.com";
	prefixca = "http://www.ca.com";
	if (hostca == ("phx.corporat"))
		{
		topMenuClasses[4] = "globalnavon";
		}
	}
}
if (window.location.protocol == "https:")
{
prefixwww3 = "http://www3.ca.com";
prefixca = "http://www.ca.com";
}
