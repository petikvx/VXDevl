function submitFeedback()
	{
	with(document)
	{
	if ((formfeedback.rating[0].checked) || (formfeedback.rating[1].checked) || (formfeedback.rating[2].checked) || (formfeedback.rating[3].checked) || (formfeedback.rating[4].checked))
			{
			window.open("", "winPopup", "resizeable=no,height=304,width=282,top=200,left=520");
			return true;
			}
		else
			{
			alert("To submit feedback, please rate the information on this page.")
			return false;
			}
	}
	}