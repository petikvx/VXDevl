var thisPage = "";

var isNS = document.layers;
var isIE = document.all;

userAgent = window.navigator.userAgent;
browserVers = parseInt(userAgent.charAt(userAgent.indexOf("/")+1),10);

// --------------------------------
// PRELOADING, ROLLOVER FUNCTIONS
// --------------------------------
var imgPath = "/global/en/images/";
var tn_imgPath = imgPath + "topnav/";
var list = new Array();
var	pageHasLoaded = false;

function findElement(n,ly) {
	if (browserVers < 4) return document[n];
	var curDoc = ly ? ly.document : document;
	var elem = curDoc[n];
	if (!elem) {
		for (var i=0;i<curDoc.layers.length;i++) {
			elem = findElement(n,curDoc.layers[i]);
			if (elem) return elem;
		}
	}
	return elem;
}

function preload(imgname,msg) {
	var thisImage;
	if (document.images) {
 		thisImage = new Image();
		thisImage.src = tn_imgPath + imgname + "-over.gif";
		list[imgname] = thisImage;
	}
}

function preloadAll () {
	// preload("imagename", "statusText",ifHi,path,imageSuffix);
	if (thisPage == "home") {
		preload("homepage-nav-products","Products");
		preload("homepage-nav-purchase","Purchase");
		preload("homepage-nav-support","Support");
		preload("homepage-nav-security","Security Info");
		preload("homepage-nav-partners","Partners");
		preload("homepage-nav-about","About Us");
	} else {
		preload("tn-home","Home");
		preload("tn-products","Products");
		preload("tn-purchase","Purchase");
		preload("tn-support","Support");
		preload("tn-security","Security Info");
		preload("tn-partners","Partners");
		preload("tn-about","About Us");
	}
}

function switchImage (imgName,newSrc) {
	var el = findElement(imgName);
	el.src = newSrc;
}

function rollOver (imgName) {
	if (pageHasLoaded)
		switchImage (imgName,tn_imgPath + imgName + "-over.gif");
	return true;
}

function rollOff (imgName) {
	if (pageHasLoaded)
		switchImage (imgName,tn_imgPath + imgName + ".gif");
	return true;
}

function pageInit () {
	preloadAll();
	pageHasLoaded = true;
}