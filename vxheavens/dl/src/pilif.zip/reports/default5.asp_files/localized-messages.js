// SPECIFY LOCALIZATION STRINGS

// [ve.js]
var search_virusname = "virus name";
var alertbox_entervirusname = "Please enter a virus name to search for.";

// [ve_form_validate.js]
var alertbox_selectone = "Please select at least one search option.";
