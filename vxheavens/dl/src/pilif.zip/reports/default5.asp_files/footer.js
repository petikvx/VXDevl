//<script>
// GLOBAL FOOTER JS FILE

var baseURL = ''
var popup
var browserName = navigator.appName
var browserVer = parseInt(navigator.appVersion)
var count = 3

// SET DEFAULT DISPLAY SETTINGS
if (!hideEmailLink) 	var hideEmailLink = false
if (!showPrintLink)	var showPrintLink = false
if (!hideRateLink)	var hideRateLink = false
if (!showReportLink)	var showReportLink = false

// SET DEFAULT PARAMETERS
if (!sourceTitle)		var sourceTitle = escape(document.title)
if (!sourceURL)		var sourceURL = escape(location)
if (!reportProducer)	var reportProducer = ''
if (!reportEmail)		var reportEmail = ''

// SET DEFAULT LINKS
if (!emailLink)		var emailLink = 'http://www.trendmicro.com/footer/email/form.asp?URL=' + sourceURL + '&sourceTitle=' + sourceTitle
if (!printLink)		var printLink = '"JavaScript:window.print()"'
if (!rateLink)		var rateLink = 'http://www.trendmicro.com/footer/rate/form.asp?sourceURL=' + escape(location) + '&sourceTitle=' + sourceTitle
if (!reportLink)		var reportLink = baseURL + '/footer/report/form.asp?sourceURL=' + escape(location) + '&reportProducer=' + escape(reportProducer) + '&reportEmail=' + escape(reportEmail)


if (hideEmailLink) count--
if (showPrintLink) count++
if (hideRateLink) count--
if (showReportLink) count++
if (count > 3) {
	var br = "<br>"
} else {
	var br = " "
}

// WRITE HTML TO DISPLAY PAGE FOOTER
links = '<table border="0" cellpadding="0"><tr>'

if (!hideEmailLink) {
	links = links + '<td valign=top align=center><a href="javascript:newWindow(emailLink)"><img src="' + baseURL + '/global/common/images/icon-email.gif" width="17" height="11" border="0"></a>&nbsp;'
	links = links + '<a href="javascript:newWindow(emailLink)">Email' + br + 'this page</a></td>'
	links = links + '<td><img src="/spacer.gif" width="15" height="1" border="0"></td>'
}

if (showPrintLink) {
	links = links + '<td valign=top align=center><a href=' + printLink + '><img src="' + baseURL + '/footer/images/print_this_page.gif" width="15" height="11" border="0"></a>&nbsp;'
	links = links + '<a href=' + printLink + ' class="brownLinkSm"><b>Print</b>' + br + 'this page</a></td>'
	links = links + '<td><img src="/spacer.gif" width="15" height="1" border="0"></td>'
}

if (!hideRateLink) {
	links = links + '<td valign=top align=center><a href="javascript:newWindow(rateLink)"><img src="' + baseURL + '/global/common/images/icon-star.gif" width="11" height="10" border="0"></a>&nbsp;'
	links = links + '<a href="javascript:newWindow(rateLink)">Rate' + br + 'this page</a></td>'
	links = links + '<td><img src="/spacer.gif" width="15" height="1" border="0"></td>'
}

if (showReportLink) {
	links = links + '<td valign=top align=center><a href="javascript:newWindow(reportLink)"><img src="' + baseURL + '/footer/images/report_broken_link.gif" width="16" height="13" border="0"></a>&nbsp;'
	links = links + '<a href="javascript:newWindow(reportLink)" class="brownLinkSm"><b>Report</b>' + br + 'broken link</a></td>'
	links = links + '<td><img src="/spacer.gif" width="15" height="1" border="0"></td>'
}


links = links + '<td valign=top align=center>'

links = links + '' + br + '</td>'

links = links + '</tr></table><img src="/spacer.gif" width="1" height="5" border="0"><br>'

//links = links + '<td valign=top align=center><a href"/corporate/contact_us.htm"><img src="' + baseURL + '/footer/images/contact_us.gif" width="14" height="10" border="0"></a>&nbsp;'

//links = links + '<a href="/corporate/contact_us.htm" class="brownLinkSm"><b>Contact</b>' + br + 'us</a></td>'

//links = links + '</tr></table><img src="/spacer.gif" width="1" height="5" border="0"><br>'



if (browserName == "Netscape") {
  features = "scrollbars=yes,resizable=yes,width=482,height=285"
} else {
  features = "scrollbars=no,resizable=yes,width=460,height=280"
}

function newWindow(url) {
  var clickTime = new Date()
  url = url + '&ct=' + clickTime.getTime() + '&referrer=' + escape(document.referrer)
  if (!popup || popup.closed) {
    popup = window.open(url,"popup",features)
  } else {
    popup.location = url
    popup.focus()
  }
}

if (parseInt(navigator.appVersion) > 3) document.write(links)
//</script>