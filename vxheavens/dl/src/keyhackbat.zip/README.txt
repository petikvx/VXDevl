
 0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0
 0                                                      0 0 0                          0                                                                            
 x       000         0000000 0         0  000    000   0     0   000000   000          x                 
 0       000    0    000      0       0   000    000  000   000  00       000    0     0                    
 x       000  0      000       0     0    000    000  000   000  00       000  0       x                   
 0       0000        000        0   0     000    000  000   000  00       0000         0                    
 x       000 0       0000000     000      0000000000  000000000  00       000  0       x                                                                                                                                              
 x       000   0     000         000      000    000  000   000  00       000    0     0                           
 0       000         0000000     000      000    000  000   000  000000   000          x                                  x    
 x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x0x  
  


          *****************************************************************************
          *                                                                           *
          *                                                                           *     
          *                     KEYHACK VIRUS (VERSION 1.3)                           *
          *                                                                           *
          *                  (C) COPYRIGHTS S.SETHUPATHI 2002                         *
          *                                                                           *
          *                            13,APRIL                                       *
          *                                                                           *
          *              (LOG ON,HACK IN,GO ANYWHERE,STEAL EVERYTHING)                *
          *                                                                           *
          *                                                                           * 
          *****************************************************************************


SHORT DESCRIPTION:

 
                   THIS VIRUS IS A STRAIGHT TICKET TO THE HELL.DONT USE IT AGAINST A
INNOCENT PERSON.USE IT AGAINST A PERSON WHO HAD BETRAYED U.


DISCLAIMER:


                   THIS TYPE OF PROGRAM IS NOT SUITABLE FOR STUDY PURPOSE.THIS PROGRAM 
DEALS WITH INFORMATION REGARDING TO HACKING AND BREACHING OF SECURITY.


BEFORE YOU START READING THE DOCUMENT READ THIS:
-------------------------------------------------------------------------------
IF YOU USE THIS TOOL YOU DISCLAIMER OF WARRANTY AND LIMITATION OF LIABILITY.
THE TOOL IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, WHETHER EXPRESS OR 
IMPLIED. WITHOUT LIMITATION. YOU ASSUME ALL RISK IN USING THIS TOOL.
IN NO EVENT I WILL BE LIABLE FOR INDIRECT, INCIDENTAL OR CONSEQUENTIAL DAMAGES,
INCLUDING, WITHOUT LIMITATION, LOSS OF INCOME, LOSS OF USE, OR
LOSS OF INFORMATION. IN NO EVENT I WILL BE LIABLE FOR ANY DAMAGES.
-------------------------------------------------------------------------------

INTRODUCTION:


              DEAR USER THIS IS A THIRD VERSION OF MY KEYHACK VIRUS.THIS IS A
VIRUS WRITTEN IN AN BATCH FILE.BATCH FILES ARE AN IMPORTANT ASPECT OF MSDOS 
OPERATING SYSTEM.A BATCH FILE CONSISTS OF A SERIES OF OPERATING SYSTEM 
COMMANDS.A BATCH FILE CAN BE RUN IN THE SAME WAY AS THAT OF A EXECUTABLE FILE.
USUALLY NO ONE HAVE ANY KNOWLEDGE ABOUT WHAT BATCH FILES ARE CAPABLE OF.I HAVE
WRITTEN THE SAME VIRUS IN C++ ALSO.THE PURPOSE OF ME TO WRITE IN THE FORM OF A
BATCH FILE IS THAT TO MAKE AWARE THAT HOW POWERFUL BATCH FILES ARE.BATCH FILES
CAN BE USED TO CREATE VIRUSES,WORMS,BACKDOOR TROJANS.THE PROBLEM IS THAT KNOW 
ONE SHOW ANY INTEREST IN STUDYING ABOUT THESE BATCH FILES.A BATCH FILE IS A 
HIGHLY ADVANCED TOOL.EVEN MICROSOFT HAS NOT GIVEN IN DETAIL ABOUT BATCH FILES
FEARING THAT MANY PROBLEMS WILL ARISE.BATCH FILES ARE THE HEART OF MSDOS OS.

NOTE:

              THIS VIRUS WORKS ONLY IN WINDOWS 95 & IN WINDOWS 98(PC ONLY).
A NEW VERSION THAT WORKS IN THE NT(WORK STATION 4.0),ME,2000 WILL BE RELEASED SOON.
 

REQUIREMENTS:

 
              MAKE SURE THAT ANSI.SYS DRIVER IS PRESENT IN THE "C:\WINDOWS\COMMAND"
DIRECTORY.BY DEFAULT ALL VERSION OF WINDOWS WILL CONTAIN IT.IT IS VERY ESSENTIAL FOR
"ANSI.SYS" FILE TO BE PRESENT.



METHOD OF INVOKING:

                  
              DOUBLE CLICK THE FILE CHIMERA.BAT (OR) GO TO THE COMMAND PROMPT TYPE CHIMERA
AND PRESS ENTER.RESTART THE COMPUTER.



HOW IT WORKS:


              THOUGH IT IS A SECRET I WILL GIVE A SHORT HINT."ANSI.SYS" DRIVER IN DOS 
CONTORLS THE KEYBOARD INTERRUPT.IT DETECTS EACH KEYSTROKE PRESSED AND PRODUCES THE CORRESPONDING
KEYCODE SIGNAL.THE IDEA IS TO CAPTURE THE KEYCODE SIGNAL GENERATED AND RECHANGING IT.I CANNOT
EXPLAIN ANYTHING MORE THAN THIS.I HAVE PROVIDED THE SOURCE CODE FOR FREE.READ IT AND TRY TO
UNDERSTAND IT.IF U HAVE ANY DOUBT REGARDING IT U R WELCOME TO SEND ME TO THE ADDRESS GIVEN BELOW.



SOLUTION:


              THE ONLY BEST SOLUTION TO THIS VIRUS IS TO REINSTALL UR OPERATING 
SYSTEM.THE AUTHOR IS NOT RESPONSIBLE FOR ANY DEADLY EFFECTS IN UR SYSTEM.EVERYTHING 
IS @ UR PERSONAL RISK.


CREDITS:


               THIS VIRUS HAVE BEEN TESTED WITH NORTON ANTIVIRUS 2002.IT DIDNT DETECT
IT AS AN VIRUS.THE VIRUS DEFINITION FOR THIS PROGRAM IS BEYOND THE SCOPE OF ANY ANTI
VIRUS.IT IS HIGHLY STEALTH.


CONCLUSION:


             IF U WANT TO KNOW ABOUT IN MORE DEATIL U CAN CONTACT ME.



CONTACT ID:

             1.SETHUPATHI_2K1@HOTMAIL.COM
             2.SETHUGENIUS_HACKER@HOTMAIL.COM



                                           