#ifndef __GENERAL_H__
#define __GENERAL_H__

#include <eikenv.h>

//#define CARIBE_DEBUG



#define ErrMessage(a) CEikonEnv::Static()->AlertWin(_L(a),_L("")); 



#endif