int	__lib_dir_handle;

#define	NULL		((void*)0)
#define sz_dirent	268
#define d_name		10

void opendir_(int *r)
{
	*r = 1;
	if ((__lib_dir_handle = open(".", 0)) < 0)
		*r = 0;
}

void readdir_(char *s, int *r, int l)
{
	unsigned char	buf[sz_dirent];
	int		i;
	*r = 0;
	if (syscall(89,__lib_dir_handle, buf, 0) > 0) {
		strcpy(s, buf + d_name);
		for (i = strlen(s); i < l; i++)
			s[i] = ' ';
		*r = 1;
	}
}

void closedir_(void)
{
	close(__lib_dir_handle);
}

#ifdef LIB_TEST
int main(int argc, char **argv)
{
	char	c[256];
	int	s;
	
	opendir_(&s);
	while (readdir_(c, &s, 255), s == 1) {
		c[255] = '\0';
		printf("%s\n", c);
	}
	closedir_();
}
#endif /* LIB_TEST */
