int main(int argc, char **argv)
{
	printf("I'm alright!\n");
	if (argc > 1)
		printf("%s\n", argv[1]);
	return 73;
}
