					README for: BAT.VaraXadoR - By SAD1c

 NAME: BAT.VaraXadoR
 TYPE: Batch
 SIZE: 1039 Bytes
 ENCRYPTED: Yes
 INFECTION: None
 NET SPREAD: None
 DESTRUCTIVE: Yes
 PAYLOAD: Move ALL files in: system32, system, windows directory, root to "history" path. Delete all files & folders in: program files, documents directory & desktop (for 9x systems) or move it to "history" path (for NT systems)
 NOTES: All files moved to "history" path are renamed, & have hidden, read only & system attributes so cannot be restored neither by Windows nor by DOS!
To get the right "history" & desktop path VaraXadoR create & run (totally stalthy) a Visual Basic Script.
 HOW TO FIX: It's impossible... The only way is reistall windows...
 HOW TO PREVENT: Never run unknown .bat files!!!