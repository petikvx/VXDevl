					README for: BAT.Confusion - By SAD1c

 NAME: BAT.Confusion
 TYPE: Batch
 SIZE: 1108 Bytes
 ENCRYPTED: Yes
 INFECTION: None
 NET SPREAD: None
 DESTRUCTIVE: Not really...
 PAYLOAD: Rename ALL files in: parent directory, system32, system, windows directory, root, program files, documents directory
 NOTES: This virus use the for method for the files searching, so files with system or hidden attributes couldn't renamed
 HOW TO FIX: It's very hard... I think the only way is reistall windows...
 HOW TO PREVENT: Never run unknown .bat files!!!