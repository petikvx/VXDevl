***************************************
::..::..:..:: GEDZAC LABS ::..:..::..::
:::::::::::: www.gedzac.tk ::::::::::::
***************************************

    Visual Basic Project Encryptor
             Version 1.5

Comentarios, sugerencias, correcciones:
nemlim@gedzac.zzn.com