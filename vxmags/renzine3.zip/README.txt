REN - ZINE #3
dedicated to VirusBuster
September 1999
resolution: 800x600
RENEGADE...fabriziozzz@geocities.com

music by Stevie Ray Vaughan
song:Texas Flood 