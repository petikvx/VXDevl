Razorblade's Batch Virus Generator v1.0
(c) 2005 by Razorblade
http://www.razorcenter.de.vu
=======================================

This is my first VCK I have coded! I know that Batch-Virii are very lame, but I have coded this VCK to learn Visual Basic and improve myself! 
This VCK is written in VB, so, you see .....


Anyway .... have fun! ;)




Bugs & other to
razor.hacks@gmx.net


