                  "INVICTUS" VX Library - by Weendigo[MATRiX]
                  ~~~~~~~~~~~~~~~~~~~~~
   I really don�t know why am I doing this library, maybe bcz
my girl leave some months ago, or bcz my ganja ends, world sux,
ppl die by hungry, Abraham Lincon was a fag, McVeigh is dead,
Bush wants to suck my dick everyday...

   Fuck reasons...let�s code!

   Version 1.03 (29/09/2001)

   Current functions:

   OpenRead
   OpenCreate
   OpenWrite
   CloseFile
   InfectFile
   Pack
   Depack
   procB64encode
   procB64decode
   PlayFile
   NetWorkExplorer


   You can make this library better sending comments about new
functions that should be implemented in the future, and
reporting bugs, of course.

   All coded in ASM

   PS: To use this shit by your own hands.

   URL:

   http://www.coderz.net/mtxvx
   http://www.nbk.hpg.com.br

   Email:

   nbk_vx@starmail.com