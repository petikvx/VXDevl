-----------------------------------------
Hell P2P Worm Generator
Autor: Falckon
Version 1.08 (fixed)
-----------------------------------------

History:
--------------

Version 1.8
28/02/03
6:30 PM
Encontrados varios errores y reparados :S  desgraciadamente publique en vx heavens
la version erronea :S
------------------------------------------------------------
Version 1.0 (beta)
28/02/03
4:50 PM
el Generador fue terminado  esta en pruebas
-----------------------------------------------------------
Errores bugs y otras cosas porfavor a:
falckon@hotmail.com
http://www.viriizone.tk