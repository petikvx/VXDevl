/////////////////////////////////////////////////////////////////////////////
// Batch-O-Matic 6.9 Source Code - � 2002-2003 SAD1c - All Rights Reserved //
/////////////////////////////////////////////////////////////////////////////

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <fstream.h>
#include <Classes.hpp>
#include <Controls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <StdCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TSaveDialog *SaveDialog1;
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TCheckBox *CheckBox1;
    TButton *Button1;
    TButton *Button2;
    TButton *Button3;
    TButton *Button666;
    TLabel *Label666;
    TPanel *Panel1;
    TImage *ProgramIcon;
    TLabel *ProductName;
    TLabel *Version;
    TLabel *Copyright;
    TImage *Image2;
    TImage *Image4;
    TLabel *Label11;
    TLabel *Label12;
    TLabel *Label13;
    TLabel *Label14;
    TLabel *Label15;
    TLabel *Label16;
    TLabel *Label17;
    TBevel *Bevel2;
    TLabel *Label18;
    TLabel *Label19;
    TLabel *Label20;
    TBevel *Bevel1;
    TLabel *Label21;
    TLabel *Label22;
    TButton *OKButton;
    TLabel *Label23;
    TLabel *Label24;
    TLabel *Label25;
    TTimer *Timer1;
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
    void __fastcall Label18Click(TObject *Sender);
    void __fastcall Label19Click(TObject *Sender);
    void __fastcall OKButtonClick(TObject *Sender);
    void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall CheckBox1Click(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);
private:	// User declarations
public:		// User declarations
    ofstream fil;
    AnsiString labelstr, noso, epwd;
    void __fastcall wstf(AnsiString str);
    void __fastcall wstfnr(AnsiString str);
    AnsiString __fastcall CaseRand(AnsiString str);
    AnsiString __fastcall StrRand(int num, int al);
    AnsiString __fastcall AdirRand(int num);
    AnsiString __fastcall AsciiRand(int num);
    AnsiString __fastcall Infstr(AnsiString sa, AnsiString sb, int in);
    AnsiString __fastcall NameRand(bool type);
    AnsiString __fastcall EncryptData(AnsiString all);
    AnsiString __fastcall GetDFF(AnsiString f);
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;                  
//---------------------------------------------------------------------------
#endif
