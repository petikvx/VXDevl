


                          ��������������������������Ļ
                          � ���� Dangerous Menu ۲�� � [DvL]
                          ��������������������������ļ

 Contacts:
           -> dvl2003ro@yahoo.co.uk
           -> www.geocities.com/ratty_dvl/BATch/main.htm

+------------+
� DISCLAIMER �
+------------+
 USE this utility at YOUR OWN RISK !!!
 I'm NOT responsable for any damage caused to your or any other computer ...
 Dangerous Menu has been extensively tested with Win95/IE 5 and it works fine on 
my IBM PC/233 mhz, 64 MB memory, 200 MB hard drive, I can't say how well it will
work on your system.
 After downloading or starting the program u r responsable for your actions
 Use the program only if u have a clean windows instalation, and use it with no 
applications opened. (FOR YOUR OWN GOOD), u must have the last wsh update (it works
with older versions, too)
 This program was only designed for win9x & winme, and not for winxp or any other
windoze.
 This program only teaches u some batch, some vbscript and many more ... DON`T use
it for spreading or anything else, learn something from it ;)
 I`ve spend many hours learning batch, vbscript and the rest, don`t rip DM, try to
understand the scripts, try to see what they do, but only on a safe computer, use
Deep Freeze to freeze your files and to safely try the virii.

If u want to report a bug or you want to ask me anything mail me.
