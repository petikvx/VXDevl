

                            ��    presenting    Ļ  by  DvL
                �����������ͼ   Dangerous Menu   �������������
                  www.geocities.com/ratty_dvl/BATch/main.htm
             DMenu is dedicated to my love, my sweat angel, Ioana
                ����������������������������������������������
                    Created to work only on win9x systems

     Note: I wanna make DM to be the coolest batch constructor made in batch
                        [........... dreams ...........]
   Greetz:
   ~~~~~~~
  - SAD1c [for his articles, bug reportz and 4 beeing a good friend]
  - SpTh [for all his articles and virii]

 [*] version 3.8 - 16.07.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - added floppy [a:\ drive] dropping, the virus will copy itself to "a:\"
       drive only if a diskette exists in the drive [from EricHelps]

 [*] version 3.7 - 12.07.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - killed some virii
     - fixed several bugs [with help from SAD1c]
     - changed the pirch worm

 [*] version 3.6 - 09.07.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - fixed an important bug, when i was redirecting data with echo, instead
       of %% i optained %. The bug was fixed by puting %%%% and obtaining %%.
     - added .vbs file infection/droping
     - added .js file infection/droping
     - fixed several little bugs

 [*] version 3.5 - 08.07.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - added (QBasic) .bas file infection/droping
     - added in autoexec.bat droping another shit: it checks what
       day it is and for every day it has a payload
     - fixed some very stupid bugs with the echo command

 [*] version 3.4 - 07.07.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - now, DM checks to see if your pc is running winXP, if
       winXP is found the program ends
     - removed some dangerous payloads from autoexec.bat droping
     - better autoexec.bat and config.sys droping
     - added .bat dropping
     - few changes in the program (only to make it better)

 [*] version 3.3 - 07.07.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - the retro part is now better and more powerful
     - added autoexec.bat infection/droping
     - added config.sys infection/droping
     - little changes and some bugs are now fixed

     - KAV name: TrojanDropper.BAT.Dmenu.f

 [*] version 3.2 - 06.07.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - added virc spreading
     - added kazaa spreading
     - added .lnk dropping
     - fixed some minor bugs

     - KAV name: TrojanDropper.BAT.Dmenu.f

 [*] version 3.1 - 27.06.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - my DMenu evolved [again]: from a dropper to a constructor.
     - Features: - choose between eicar, fake bytes and both of them
                 - choose between keyboard and mouse disabled and swap mouse buttons
                 - retro [it deletes allmost all known AV`z]
                 - autoexec.bat payloadz
                 - Outlook Express spreading
                 - mIRC spreading
                 - pIRCh spreading
                 - pif infector

     - KAV name: TrojanDropper.BAT.Dmenu.g

 [*] version 3.0 - 18.05.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - Dropped files: -> the Hippie viruz for win9x and winXP
                      -> the BoogieMan viruz for winXP
                      -> the Hool-i-Gun viruz for winXP
                      -> the RemAV viruz for winXP
                      -> the BATlle-Field.b viruz for winXP

     - KAV name: TrojanDropper.BAT.Dmenu.e

 [*] version 2.1 - 06.05.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - Dropped files: -> a file which will change the sizes from some IMPORTANT files to 0 bytes
                      -> a file which will delete some IMPORTANT files with the COPY command 
                      -> a file which will try to format the a,c,d,e drives
                      -> a file which will try to delete all files from drive c
                      -> a file which will try to overwrite all files from drive c

     - KAV name: TrojanDropper.BAT.Dmenu.d

 [*] version 1.1 - 12.03.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - the third version of DMenu is written [ya, the third version]
     - my DMenu evolved: from a trojan to a dropper.
     - Dropped files: -> a file which will delete everything from desktop 
                      -> a file which will delete all command.com files
                      -> a file which will delete everything from My Documents
                      -> a file which will delete the windows password files
                      -> a file which will try to delete all your files

     - KAV name: TrojanDropper.BAT.Dmenu.c

 [*] version 2.0 - 12.03.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - the second version of DMenu is written.
     - like his predecesor, but newer commands option in menu,
     - Features: - Delete files from system folder
                 - Format drive d
                 - Format drive a
                 - Restart computer

     - KAV name: TrojanDropper.BAT.Dmenu.b

 [*] version 1.0 - 11.03.2003:
     =-=-=-=-=-=-=-=-=-=-=-=-=
     - the first version of DMenu is written
     - it`s the first trojan which can "satisfy" your pleasure from his menu
     - Deletes: - everything from usual win9x desktop
                - all command.com files from your pc
                - all files from My Documents
                - win password files [.pwl]

     - KAV name: TrojanDropper.BAT.Dmenu.a