Senna Spy Internet Worm Generator 2000

The first Internet Worm Generator in the world!

Make your own internet worm.
Outlook and network compatible.
Windows 95, 98, NT and 2000 compatible.

Generate VBScript source code.

http://sennaspy.cjb.net

Thanks...
Senna Spy

