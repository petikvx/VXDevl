Vbs Worms Creator 0.01 By [K]Alamar
http://www.virii.com.ar
Virii Argentina - The biggest virii resource in the net.
______________________________________________________________________

Hi:

I made this program because i was bored, and then, i was no bored
anymore, so i stoped writting it, so, a lot of stuff are not her, but
they will, you just have to wait till i get bored again, and i will add
payloads and more infection metods.

Ok, first, whit this program you can make really basic vbs worms that
will work fine, but if you wanna make a good worm, you should code it 
by your self. You can learn to code one just reading a worm created by 
the program, Visual Basic Scripting is really easy, but not stupid,
you can do a lot whit it.
Soon i will post a vbs worms tutorial in Virii Argentina, so, go 
often to the site if you wanna learn more.

Sorry for the bad english.;o)
______________________________________________________________________

Features:

The worm is created completly random, so, every worm will be diferent
to the other; the functions, variables, and objects are created
randomly.

--
If you try to edit the worm be very carefoul whit editing 
the variables, because you have to edit it every time it is shown.
______________________________________________________________________

* Start whit windows:
This will made your worm run every time windows start; this is
good if you you want to try to spread every time.

* Worm backup:
That's the directory where the worm will copy so if the user delete
the first file, you will not lost the worm.

* Outlook Replication:
The worm will send a mail to all the contact list whit the worm 
attached, the mail subject will be the one you put, and the mail body
too.

* Mirc replication:
The worm will try to find Mirc in c:\mirc, c:\mirc32 and 
programfiles\mirc, if it is finded it will create cript.ini, 
that wil try to send the worm by mirc.
______________________________________________________________________

Ok, i tell you again, i will add more functions, payloadas and stuff
to the program, and also redesing it, and make it faster, so, if you
wanna get the updates go to virii.com.ar.

Questions? Comments? Bugs?

kalamar@virii.com.ar

Thanls for downloading Vbs Worms Creator 0.01.

[K]Alamar