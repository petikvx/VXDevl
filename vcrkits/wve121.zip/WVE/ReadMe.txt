The WalruS Macro Virus Engine (WVE)

The WalruS Virus Engine is a very easy to use virus generator for creating macro viruses/worms in Word 97/2000/XP.
To use WVE just run the WVE.exe file provided in this Zip file. 

WVE requires VB runtimes 6 to Work. Should WVE not work, try downloading and installing the runtimes from http://dcanet.softseek.com/Utilities/VBRUN_and_other_DLLs_and_Runtime_Files/Review_19823_index.html

Currently WVE has the following virus options.

Virus type: Module or Class infection.
Virus Details: Virus name, Author, Version (Optional), Origin (Optional), Comments (Optional), Greets (Optional).
Infection Hook: Document Open, Close, New, Print, File Save, File Save As, Word Exit.
Self Recognition: Count Of module lines, Code module name, Code string marker within code module, Word/Doc properties.
Code Replication: Import/Export to a file, String copy.
Stealth: No stealth, Level 1 stealth, Level 2 Stealth.
Random Noise: No noise, Minimum noise, Medium noise, Maximum noise.
Payload: None, Custom, Existing -> Colours madness, CD Tray Wildness, Kill active document, Word Hiccups, Message box, Assistant message, Password Document, Crazy mouse, Random coloured shapes, Crash Windows.
Payload Trigger: None, On infection hook, Random, By date, By time, Custom.
Virus Extras: VBS backup, Fast infection, Super fast infection, Spread on IRC mIRC/Pirch/VIRC, Infect Zip archives, Change document properties, Change Windows/Word usernames, Custom module, Retro, Document Encryption, Spread by mail (disabled).
Options: Create infected document, Include date in virus, Include time in virus, Include comments in virus, Use random variable names, Turn of sounds in WVE, Prompt to edit/view source code before the virus is created, Create Worm, Create virus path.
Create Random Virus.
Reset Virus Options.
About WVE: Update WVE using internet, Mail WalruS, Visit The WalruS Homepage Acknowledgments.
Exit.

Every option has an associated help button that explains the options aim.


WVE has an extras screen where the following can be done:-

Drop A WalruS Virus : Drop a WalruS virus Puny/Wally/Chipper/Stars/LSD, Launch The WalruS encryption tool (WET) to use in your virus.

Scattered throughout WVE are lots of hidden secrets and funny things just for fun :-)

Another Virus Creation Tool!!! Why make another creation tool so soon after WMVG?

Well WVE is Bigger, Better, Faster And Prettier than WMVG. It is also easier to update and is not dependent on Word being installed. WVE will work without Word, it will just create the source code so that it may be imported later.

In future WVE will be continously updated to include more options, bug fixes etc.

Please feel free to contribute any code for any part of this kit eg more payloads/infection routines etc. Im always after new and cool code. If i include it a reference will be made in acknowledgments.

WVE was designed and tested initially on Windows ME with Word 2000 however tests have been done on various other configurations by the beta testers (see acknowledgments)

For Any Comments, Questions Or Bugs Contact WalruS Direct Below.

WalruS@iamit.com
http://www.WalruS.8k.com