Vbs Worms Generator 0.91 By [K]Alamar
Buenos Aires - Argentina - 10/Jul/2000
Http://www.virii.com.ar
Virii Argentina - The biggest virii resource in the net.
Bugs, questions or comments: kalamar@virii.com.ar
______________________________________________________________________
**********************************************************************
YOU NEED THE WINDOWS SCRIPT HOST 5.0 OR LATER IF YOU WANT THE PROGRAM
TO WORK, IF THE WSH 5 IS NOT INSTALLED THE PROGRAM WILL TELL YOU.
YOU ALSO NEED THE VISUAL BASIC 5.0 RUNTIMES, YOU CAN GET THEM IN
MICROSOFT.COM OR YOU CAN ASK ME FOR THEM AND I'LL SEND THE FILES TO
YOU.
CONTACT ME IF YOU HAVE ANY OF THE PROBLEMS, I'LL HELP YOU.
**********************************************************************
YOU NEED THE MICROSOFT VISUAL BASIC 5.0 RUNTIMES TO RUN THIS PROGRAM.
**********************************************************************
Remeber, this program if for educational purpose only, I take no 
responsabiliy for any damage caused for any file created whit this 
program to anything.
**********************************************************************
PLEASE LEAVE THIS FILE IN THE SAME FOLDER AS THE EXE IF YOU WANT THE 
PROGRAM TO RUN FINE.
**********************************************************************
______________________________________________________________________
Sorry for the bad english.
______________________________________________________________________
Hi!:
Thanx for downloading the Vbs Worms Generator 0.91.
I can see the 1.0 Comming!
______________________________________________________________________
What's New (some of these things where already in 0.90) :
*Pirch replication (thanx to Mano/SunSoft_Team for the script).
*Fixed some bugs, lots of bugs.
*Modified code so Avp can detect it (Avp detect's all virii created
 whit 0.80 lik i-Worm.Lee.j.
*New design.
*Fast acces.
*New name! (Vbs Worms Generator or VbsWg), i like it more than the 
 other.
*Fixed Avp I-Worms detrection; Avp has a new detection method that
 detects i-worms that uses the Outlook replication.
*Infection for vbe files.
*I don't remember anything else.
______________________________________________________________________



______________________________________________________________________
*Stuff:
The worms crated whit the program are completly randomized, so you 
will never have 2 equal worms.

What does that mean?

That all the variables are randomized words of 10 characters, so, the
posibilities of having two equal words in a wordm are dificult, and 
the posibilities of having 2 equal worms are completily imposible.

You must be very carefoul when you edit the worm, becaouse if you
change a variable, you must change it every time it's shown.
______________________________________________________________________
*Features:

Start whit windows:
This make the worm be executed every time windows is started, so your
worm can try to infect or spread every day.

Worm backup:
It's just for having a copy of the worm in a safe place, so you can
be shure that it will no be lost.

Outlook Replication:
it uses the same function that all the vbs's, js's or any other kind of
worm, it sends a message, that you can define, whit te worm attached
to every preson in the user's address list.

Mirc replication:
Search for mirc.ini(what means that the mirc is there) in the most
commons floders(programfiles\mirc, c:\mirc, c:\mirc32) and if it 
is found, the worm create "script.ini" in that folder, that script make
the mirc sends the worm to every person that join to a channel.
(see "If found Mirc, infect.")

Pirch replication:
Same as mirc, but for pirch (i haven't tested the script cause i 
haven't got pirch, please someone test it and tell me if this work).

Infect Files:
The worm will search for all the hard drives (and the network drives 
too, i think) for files whit the extencion that you want(in this
version only .vbs and vbe are searched) and copy overwrite him whit itself.
*If found Mirc, infect:
This will make the worm to search also for mirc.ini, so if it find him,
it will infect the folder where mirc is. This method works 100% of the
times.

'To do a search for all the computer could take over 5 minutes, 
depending of the hard drive size.

Payloads:
These are stuff that you can add to the worm to be done.
  Message: shows a message box whit the text and the picture that
  you want.

  Open web address: open the web address that you want.

  When?: whit this you can tell the worm when do you wan to execute
  the payloads.

*Any idea?, contact me and i will add it!.
______________________________________________________________________

Ok, this is all that the program can make, maybe i forgot something,
i don't know.
I hope that you can learn something about Visual Scripting, it's
really easy an powerfull.
Visit www.virii.com.ar often if you wnna get the newest versions, i
think that the 1.0 will be finished in a week or two.

Have fun.

[K]Alamar
kalamar@virii.com.ar
http://www.virii.com.ar
______________________________________________________________________