
 Next Generation Virus Construktion Kit
 by SnakeByte ( SnakeByte@kryptocrew.de )
 [ www.kryptocrew.de/snakebyte ]


0.) Important Information
1.) What is this ?
2.) Features
3.) Thanx & Greetz
4.) Version History 
5.) Thoughts and Ideas


0.) Important Information

 This software is NOT written to create damage, therefore you will never see any destructive
 payload or something similar. Please do not abuse it, because virus spreading is illegal
 and you can get into serious problems by doing this. This construction kit is just
 meant to show what is possible nowadays and not to support kids, which want to
 infect one of their friends as a joke with a virus. Hope you keep this in mind
 while using.


1.) What does this thingie do ?

 The Next Generation Virus Construktion Kit ( NGVCK ) generates Win32 PE Infectors.
 All created viruses are completely different in structure and opcode.
 This makes it impossible to catch all variants with one or more scanstrings.
 First, the Kit generates the opcode form of the different modules.
 For example the Delta Offset routine might have one of the following appearances :

  --- Basic Version
   E800000000     call Delta
   5D             Delta: pop ebp
   81ED05104000   sub ebp, offset Delta
  --- E8000000005D81ED05104000
 
  --- Example 1 ( Different Instructions )
   E800000000      call Delta
   812C2405104000  Delta: sub dword ptr [esp], offset Delta
   58              pop eax
   8BE8            mov ebp, eax
  --- E800000000812C2405104000588BE8

  --- Example 2 ( Different Instructions + Trash )
   81C11B753100    add    ecx,0031751B   ; trash
   E800000000     call   Delta
   812C240B104000 Delta: sub dword ptr [esp], offset Delta
   81EB09090000    sub    ebx,00000909   ; trash
   8B1424         mov    edx,[esp]
   91              xchg   ecx,eax        ; trash
   83C404         add    esp,00000004
   81E1445E0000    and    ecx,00005E44   ; trash
   87EA           xchg   edx,ebp
  --- *812C240B104000*8B1424*83C404*87EA

 I guess you can imagine many more examples. The registers are choosen at random, and
 the offsets also differ in each version. The trash is completely randomly generated.
 I also made various versions for the instructions everywhere I found another way
 to do the same thing:

  mov eax, 1

  xor eax, eax
  inc eax

  push 1
  pop eax

  ... I think you got the point ;)

 I found for nearly everything a replacement, for opcodes and structure.
 In addition to this, the whole structure is changing everytime. I have a jump or a
 call at the end of each module to the next one. So I can randomly place all the 
 modules inside the source. Nice eh .. ;)
 Same goes of course for the data.


2.) Features

 - Infects :
    + Win32 PE-Executables

 - Directory Travelling :
    + Windows Directory
    + System Directory

 - Anti Bait Checks :
    + Size

 - Anti Debugging :
    + Checks API's for SoftIce Breakpoint ( code from T2000's Chainsaw )
    + Sets up an SEH and creates an exception

 - Encryption :
    + ROR/ROL, NEG, NOT, XOR, ADD/SUB


3.) Thanx & Greetz

 First of all I want to tell you that I really enjoyed to sit here,
 listening to the new Alice Cooper CD and trying to put some sense
 into my lines of code. I think it was worth the time I spend =)

 Necronomicon      - H. P. L. still rocks ;)
 Arzy              - heh, don't always quit during the chat :P
 Pacman            - thnx for compiling this shit sometimes 
 devil_505         - thnx for theaching me how to idle ;)
 sequenzer         - nice that you helped me with the shr/shl thingie ..
 Int 13h           - sorry for that ddos accident.. :(
 BlackJack         - i like your win32, pe, ne and dos infector
 Virusbuster       - thnx for publishing my stuff in 29a #5
 Blind Angel       - heh, go on with So(u)rcerer, it's cool !
 All German VX ppl - vielleicht gibt's ja doch mal ne deutsche Szene =)
 toro              - thnx for beta testing !
 H+BEDV            - remove this fucking signature from your database !
 Ciatrix           - and once again.. V-Dat is.. ehrm..
                     I think you know what i want to say =)
 T-Info Board ppl  - big thnx for your help against H+BEDV !
 Kaspersky         - wow, you really seem to have some talents
                     ( I don't even understand my code in TFAK and
                       you seem to do so without my comments.. *g* )


 Others I want to mention here :
   entire KryptoCrew, DukeCS, rose, Anthraxx, Paul Zest,
   Vecna, Darkman, Dr. Seltsam, Eisbaer,
   the #CCC guys =), ...and many many more,...
   ( I am too lazy to write down everyone.. *g* )


4.) Version History
 
 As you will see here, it took a long time until I finished this thing ;(
 Thats because I just can't work on weekends at this ( then I am at Wiesbaden
 and make party or meet my girlfriend ) and I have to study and learn MySQL
 and Java at the same time :(


 *Version 0.00 - 20-11-2000
   Generates simple Win32 Viruses
   NOP is the only trash instruction
   lot's of bugs ;(

 *Version 0.02 - 11-12-2000
   Most generated viruses work ! ( so I hope I can finish this basis of the kit this week ) 
   I found out that the Digital Hackers' Alliance Randomized Encryption Generator [DREG]
   which was created by Gothmog/DHA also tried to create viruses this way. Due to the
   fact that all samples from him get detected, I'll try to give my best to avoid this ;)
   I will take a look at his VCK and hope to learn from his output.
   ( heh, Gothmog, if you are still around, give me a call.. :P )

 *Version 0.10 - 13-13-2000
   The Kit works stable ! All generated Viruses work, infect the current and
   ( if choosen ) the windows and system directory. I will now read some poly
   tutors and papers to improve the randomness of it, and made some improvements
   of the really crappy output-design ;)

 *Version 0.12 - 18-12-2000
   The output is now ok, and understandable ;) I added a lot of comments
   and formatted them. Got not much time at the moment to work on the
   engine itself, because I still got to find some x-mas presents and
   i got more work at university. So I just worked over 1/4 of the current engine
   to make it more variable, but till now, I found at least one replacement for
   every opcode and structure inside the 3 modules.

 *Version 0.13 - 25-12-2000
   Ok, now 3/4 are completely random, will continue with the rest...

 *Version 0.14 - 08-01-2001
   Ok, there are round about 99% of the opcodes random
   ( they can be replaced by another ), the few others are either
   "ret"s ( which i will replace tomorrow ) or an instruction, with 
   at least one random parameter ( register / offset / constant ),
   so there are maybe 20 Bytes static, but these are always at a 
   different place and in a different order, so I think they will 
   not make a reliable scanstring... ;)
   But I will remove them too... But first I want to add some
   other viral tricks ( anti-debugging, anti-bait, encryption )
   which the user might select to include. ( This will also change
   the behavior of the viruses )

 *Version 0.20 - 16-01-2001 ( first beta )
   I added encryption ( even if it is not completely random ), but
   just simple algorithms, nothing with a key, but XOR and SUB/ADD
   will follow soon =) Hope I can do this till friday, so I can give out
   a first beta to some ppl. Every opcode except the ones in the crypt
   routines are random, so no simple scanstring can be choosen. But the
   ones inside the crypt routine will be made variable too.
 
 *Version 0.21 - 31-01-2001
   Removed some really stupid bugs from the encryption routine
   and made it more variable. I also added an SEH anti debugging
   trick and included some trash code to make it more variable.

 *Version 0.22 MTX#3 Release - 19.02.2001
   Just minor changes, I got no time at the moment :(
   University means lots of work...


5.) Thoughts and Ideas


 This last part will present some ideas and techniques i got or found
 while developing my Next Generation VCK. Not the big things, but
 if you are bored, just read it ... ;)

 /*/ Another way to receive the delta handle in Win9x & ME /*/

  This does not work on NT, but fine on all Win95 based systems.
  When starting the file, EAX contains the initial EIP. By using this
  we can simply retrieve the delta offset :
 
  .code
  Delta:
   mov ebp, eax
   sub ebp, offset Delta
   lea ecx, [ebp+offset Whatever]


 /*/ A possible Anti-Emulator Check /*/

  This has been tested under Win95, NT and ME, so I guess it will
  also work on 98 and 2000. When the file ist started, 
  the first 16 Bits of ESP and EBP are equal, this might be used to
  pass weak emulators, which do not correctly set these values.

  .code
   mov ebx, esp     ; get values
   mov edx, ebp
  
   shr ebx, 16d     ; clear last 16 Bit
   shr edx, 16d     ; could also be done with xor bx, bx .. etc

   cmp edx, ebx
   jne Emulated


 /*/ The Game /*/

  The game between the Antivirus and Virus Communities is still going on.
  Normally, there is a new Virus, which gives for a short time a point
  for the VX Scene, then there it gets detected and can be removed which
  gives a point for the AV's. So what can we do, to retrieve a keep the
  points for a longer time than the 12-24 hours they usually need to create
  a scanstring. The first way is polymorphism, which needs them to make a deeper
  analyzis of the virus, to test the strings. The next way is every new technique
  used by a virus. The last example for this was the stream infection, which made
  the AV's fear some undetectable viruses, which did not ( yet.. *g* ) exist.
  With every new technology the AV's need to understand it completely to react to
  it, so be creative. Even if you do things a lot different like usual in your virus
  they still need to understand it, because it could make their scanstrings useless and
  these 'we don't know if further payloads exists...' just look like shit inside
  the descriptions. The last thing I came about is a kind of denial of service ;)
  If the virus structure is like spaghetti code they need a bit longer to analyze it.
  And if there is a lot, a whole lot, of viruses like this, they have a lot to do,
  thats also a reason why I created NGVCK, because it makes such a lot of viruses possible
  and they have to develop a new technique to catch em all, which will hopefully not
  just be a fake.


 /*/ Writing a VCK /*/

  Ok, writing a VCK is a challenge and nice, but what is such a VCK
  useful for ? Maybe for Newbies to learn from the source, but I hardly
  think they do. For giving others the chance to infect others. Yes,
  this may be and I think this is what most VCK's are used for, sad 
  but true. A VCK might be nice, because it gives the AV'er a whole
  lot of work at once, they need to cope, because otherwise there
  would be several new viruses floating around. But wait, when talking
  about AV's, I think a VCK is also a big deal for them.
  They have the source codes of several viruses at once, they can
  take a look at fully commented source code and check if their
  heuristic engine catches them all. In addition to this, they
  can train their heuristics on all the generated viruses, which
  gives them a boost. So writing a VCK might not be that good for
  VX-Scene at all...

