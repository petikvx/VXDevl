This is the ReadMe for El-Trucha's Graphical Virus Maker
I know this version supports more OS's than Win2k/XP if u have all the required system files.
Send me an email and tell me if it worked and what OS u got: eltrucha14@hotmail.com

Descriptions of the files:
===========================
virusmkr.exe - The program.

autoexec.bat - The Autoexec.bat that will be replaced with the one that has the format command.

bat2exe.com - The compiler, BAT2EXEC. Much thanx 2 the author!!! ;)

WizApp.exe - Wizard Apprentice, the graphical interface. Much thanx 2 the author!!! ;)

readme.txt - This file.

changelog.txt - The program's ChangeLog.

bitmap.bmp - The picture that u see at the side of the program.


Usage:
===========================
Here's the files for each OS:

DOS:
autoexec.bat
command.com

Windows 3.x/9x/Me:
autoexec.bat
command.com
win.ini
win.com

Windows NT/2k/XP (maybe 2k3 and Longhorn, but I'm not sure...)
boot.ini
NTLDR