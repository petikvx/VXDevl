//
// This is the client program for the kmodule.sys kernel module.
// See kmodule source for details.
//
// Joanna Rutkowska, joanna<a>mailsnare.net, 2003
//




#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "..\\kmodule\\kmodule.h"
#include "..\\kmodule\\targets.h"

#define MAXPROCNO 1000	//FIXME: ugly static array
#define VERSION "0.2"
#define devName L"\\\\.\\klister"




void die (char* s) {
	fprintf (stderr, "error: %s\n", s);
	exit (1);
}

ServiceTableInfo SrvTables[MAX_SERVICETABLES];
int main (int argc, char **argv) {

	int i, tno;
	fprintf (stderr, "SDT finder %s, Joanna Rutkowska, 2003\n", VERSION);

	fprintf (stderr, "determinig OS version... ");
	
	OSVERSIONINFOEX	osver;
	osver.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	GetVersionEx ((LPOSVERSIONINFO)&osver);

	int ntrgs = sizeof (targets)/sizeof(_TARGETS);

	for (i = 0; i < ntrgs; i++) 
		if (targets[i].dwBuildNumber == osver.dwBuildNumber &&
			targets[i].wServicePackMajor == osver.wServicePackMajor &&
			targets[i].wServicePackMinor == osver.wServicePackMinor) {

			tno = i;
			fprintf (stderr, "%s\n", targets[tno].name);
			break;
		}

	if (i == ntrgs) die ("unsuportted OS version.");


	fprintf (stderr, "opening device %S...\n", devName);
	HANDLE hDevice = CreateFileW(devName ,
                          GENERIC_READ | GENERIC_WRITE,
                          0,
                          NULL,
                          OPEN_EXISTING,
                          FILE_ATTRIBUTE_NORMAL,
                          NULL
                          );
    if ( hDevice == ((HANDLE)-1) ) die ("can't open device");

	KLISTER_INIT kl_init;
	
	kl_init.pKiDispatcherReadyListHead_addr = targets[tno].pKiDispatcherReadyListHead_addr;
	kl_init.pKiWaitInListHead_addr = targets[tno].pKiWaitInListHead_addr;
	kl_init.pKiWaitOutListHead_addr = targets[tno].pKiWaitOutListHead_addr;
	
	fprintf (stderr, "using offsets:\n");
	fprintf (stderr, " * pKiDispatcherReadyListHead : %#x\n", 
		kl_init.pKiDispatcherReadyListHead_addr);

	fprintf (stderr, " * pKiWaitInListHead_addr     : %#x\n", 
		kl_init.pKiWaitInListHead_addr);
	
	fprintf (stderr, " * pKiWaitOutListHead_addr    : %#x\n", 
		kl_init.pKiWaitOutListHead_addr);
	

	DWORD bytesReturned = 0;

	fprintf (stderr, "sending  IOCTL_KLISTER_INIT...\n");
	if(!DeviceIoControl(hDevice, IOCTL_KLISTER_INIT,
							(LPVOID)&kl_init,
							sizeof(kl_init),
							NULL,
							0,
							&bytesReturned,
							NULL))
		die ("can't communicate with kernel module (IOCTL_KLISTER_INIT)");



	bytesReturned = 0;
	
	fprintf (stderr, "sending  IOCTL_KLISTER_FIND_ST...\n");
	if(!DeviceIoControl(hDevice, IOCTL_KLISTER_FIND_ST,
							NULL,
							0,
							(LPVOID)&SrvTables,
							sizeof (SrvTables),
							&bytesReturned,
							NULL))
		die ("can't communicate with kernel module (IOCTL_KLISTER_FIND_ST)");


	fprintf (stderr, "bytesReturned = %d\n", bytesReturned);
	int nSrvTbles = bytesReturned/sizeof (ServiceTableInfo);

	if (nSrvTbles == 0)
		die ("NO SERVICE TABLE FOUND. VERY STRANGE!");
	if (nSrvTbles == 1) {
		fprintf (stderr, "ALL %d THREADS are using the SAME Service Table, at adddres %#x\n",
			SrvTables[0].nthreads, SrvTables[0].addr);
		fprintf (stdout, "------ Serivce Table dump ------\n");

		bytesReturned = 0;
	
		fprintf (stderr, "sending  IOCTL_KLISTER_DUMP_ST...\n");

		int n = SrvTables[0].n;
		int STno = 0;
		int* ST = new int [n + 1];

		if(!DeviceIoControl(hDevice, IOCTL_KLISTER_DUMP_ST,
							(LPVOID)&STno,
							sizeof(int),
							(LPVOID)ST,
							n*sizeof(int),
							&bytesReturned,
							NULL))
			die ("can't communicate with kernel module (IOCTL_KLISTER_DUMP_ST)");
		
		if (bytesReturned != n*sizeof(int)) 
			die ("bytesReturned != n*sizeof(int)");

		for (int i = 0; i < n; i++)
			fprintf (stdout, "%04d: %#x\n", i, ST[i]);
		delete ST;


	} else {
		fprintf (stderr, "NOT ALL THREADS are using the same Service Table\n");
		for (int i = 0; i < nSrvTbles; i++) {
			fprintf (stdout, "SrvTable at %#x used by %d threads\n",
				SrvTables[i].addr, SrvTables[i].nthreads);
		}
	}

	CloseHandle (hDevice);
	return 0;
}

