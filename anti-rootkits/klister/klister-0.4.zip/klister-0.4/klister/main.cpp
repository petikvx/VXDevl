//
// This is the client program for the kmodule.sys kernel module.
// See kmodule source for details.
//
// Joanna Rutkowska, joanna<a>mailsnare.net, 2003
//



#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "..\\kmodule\\kmodule.h"
#include "..\\kmodule\\targets.h"

#define MAXPROCNO 1000	//FIXME: ugly static array
#define VERSION "0.4"
#define devName L"\\\\.\\klister"







void die (char* s) {
	fprintf (stderr, "error: %s\n", s);
	exit (1);
}


int main (int argc, char **argv) {

	int i, tno;
	fprintf (stderr, "klister %s, Joanna Rutkowska, 2003\n", VERSION);

	fprintf (stderr, "determinig OS version... ");
	
	OSVERSIONINFOEX	osver;
	osver.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	GetVersionEx ((LPOSVERSIONINFO)&osver);

	int ntrgs = sizeof (targets)/sizeof(_TARGETS);

	for (i = 0; i < ntrgs; i++) 
		if (targets[i].dwBuildNumber == osver.dwBuildNumber &&
			targets[i].wServicePackMajor == osver.wServicePackMajor &&
			targets[i].wServicePackMinor == osver.wServicePackMinor) {

			tno = i;
			fprintf (stderr, "%s\n", targets[tno].name);
			break;
		}

	if (i == ntrgs) die ("unsuportted OS version.");


	fprintf (stderr, "opening device %S...\n", devName);
	HANDLE hDevice = CreateFileW(devName ,
                          GENERIC_READ | GENERIC_WRITE,
                          0,
                          NULL,
                          OPEN_EXISTING,
                          FILE_ATTRIBUTE_NORMAL,
                          NULL
                          );
    if ( hDevice == ((HANDLE)-1) ) die ("can't open device");

	KLISTER_INIT kl_init;
	
	kl_init.pKiDispatcherReadyListHead_addr = targets[tno].pKiDispatcherReadyListHead_addr;
	kl_init.pKiWaitInListHead_addr = targets[tno].pKiWaitInListHead_addr;
	kl_init.pKiWaitOutListHead_addr = targets[tno].pKiWaitOutListHead_addr;
	
	fprintf (stderr, "using offsets:\n");
	fprintf (stderr, " * pKiDispatcherReadyListHead : %#x\n", 
		kl_init.pKiDispatcherReadyListHead_addr);

	fprintf (stderr, " * pKiWaitInListHead_addr     : %#x\n", 
		kl_init.pKiWaitInListHead_addr);
	
	fprintf (stderr, " * pKiWaitOutListHead_addr    : %#x\n", 
		kl_init.pKiWaitOutListHead_addr);
	

	DWORD bytesReturned = 0;

	fprintf (stderr, "sending  IOCTL_KLISTER_INIT...\n");
	if(!DeviceIoControl(hDevice, IOCTL_KLISTER_INIT,
							(LPVOID)&kl_init,
							sizeof(kl_init),
							NULL,
							0,
							&bytesReturned,
							NULL))
		die ("can't communicate with kernel module (IOCTL_KLISTER_INIT)");


	KLISTER_PROCINFO kl_procinfo[MAXPROCNO];
	bytesReturned = 0;
	
	fprintf (stderr, "sending  IOCTL_KLISTER_LISTPROC...\n");
	if(!DeviceIoControl(hDevice, IOCTL_KLISTER_LISTPROC,
							NULL,
							0,
							(LPVOID)&kl_procinfo,
							sizeof (kl_procinfo),
							&bytesReturned,
							NULL))
		die ("can't communicate with kernel module (IOCTL_KLISTER_LISTPROC)");


	
	int nprocs = bytesReturned/sizeof (KLISTER_PROCINFO);
	fprintf (stderr, "%d processes found:\n", nprocs);
	
	for (i = 0; i < nprocs; i++) 
		fprintf (stdout, "0x%8x %6d %s\n", 
		kl_procinfo[i].obAddr,
		kl_procinfo[i].pid, 
		kl_procinfo[i].name);
	


	CloseHandle (hDevice);
	return 0;
}

