
#ifndef _NTDDK_
#include <winioctl.h>
#endif

#define FILE_DEVICE_KLISTER      0x8888
     

#define IOCTL_KLISTER_INIT\
	(ULONG) CTL_CODE(FILE_DEVICE_KLISTER, 0x01, METHOD_BUFFERED, FILE_WRITE_ACCESS)

#define IOCTL_KLISTER_LISTPROC\
    (ULONG) CTL_CODE(FILE_DEVICE_KLISTER, 0x02, METHOD_BUFFERED, FILE_WRITE_ACCESS)

#define IOCTL_KLISTER_DUMP_IDT\
    (ULONG) CTL_CODE(FILE_DEVICE_KLISTER, 0x03, METHOD_BUFFERED, FILE_WRITE_ACCESS)

#define IOCTL_KLISTER_FIND_ST\
    (ULONG) CTL_CODE(FILE_DEVICE_KLISTER, 0x04, METHOD_BUFFERED, FILE_WRITE_ACCESS)

#define IOCTL_KLISTER_DUMP_ST\
    (ULONG) CTL_CODE(FILE_DEVICE_KLISTER, 0x05, METHOD_BUFFERED, FILE_WRITE_ACCESS)


#define WAITLIST_OFFSET 0x5c	// in _KTHREAD

typedef struct _KLISTER_INIT {
	
	int pKiWaitInListHead_addr ;
	int pKiWaitOutListHead_addr ;
	int pKiDispatcherReadyListHead_addr ;
} KLISTER_INIT, *PKLISTER_INIT;


typedef struct _KLISTER_PROCINFO {
	int pid;
	int obAddr;
	char name [18];
} KLISTER_PROCINFO, *PKLISTER_PROCINFO;


#pragma pack(1)
typedef struct _IDTGATE {
        unsigned short  off1;
        unsigned short  sel;
        unsigned char   none, flags;
        unsigned short  off2;
} IDTGATE, *PIDTGATE;

#pragma pack(1)
typedef struct _IDTR {
        unsigned short  limit;
        unsigned int    base;
} IDTR, *PIDTR;

#pragma pack()

#define MAX_PROCS 1000
#define IDT_NGATES 256

#define MAX_SERVICETABLES 100

#define MAX_THREADS 10000
typedef struct _ServiceTableInfo {
		int addr;
		int n;			// size of the table
		int nthreads;	// how many threads are using this table
	//	int threads[MAX_THREADS];	// id of each thread which uses this table
} ServiceTableInfo;



