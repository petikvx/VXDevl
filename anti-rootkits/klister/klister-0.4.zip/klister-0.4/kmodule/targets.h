#ifndef __TARGETS_H
#define __TARGETS_H

struct _TARGETS {
	char name[128];
	
	DWORD dwBuildNumber;
	WORD wServicePackMajor;
	WORD wServicePackMinor;
	
	//
	// You should use debug symbols info to get the address. 
	// Small program from Schreiber's book (Undocumented Windows 2000 Secrets)
	// is a good choice here:
	//
	// w2k_sym /v \WINNT\system32\ntoskrnl.exe | grep KiWaitInListHead
	//

	int pKiWaitInListHead_addr ;
	int pKiWaitOutListHead_addr ;
	int pKiDispatcherReadyListHead_addr ;
} targets[] = {
	{
		"Windows 2000 Server [2195], SP2",
		2195, 2, 0,
		
		0x804814F8,
		0x80481AA8,
		0x80481580
	},
	{
		"Windows 2000 Server [2195], SP3",
		2195, 3, 0,
		
		0x80481C78,
		0x80482228,
		0x80481D00
	},
	{
		"Windows 2000 Server [2195], SP4",
		2195, 4, 0,
			
		0x80482258,
		0x80482808,
		0x804822e0
		
	} };

#endif
