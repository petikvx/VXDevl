
//
// This module reads the internals dispatcher thread's lists
// in order to enumerate all running threads (and processes)
// in the system. This is intended to detect some hidden processes
// by rootkits (like fu), etc.
//
// This is proof-of-concept software, and no warranty is given
// Use at your own risk.
//
// Joanna Rutkowska, joanna<a>mailsnare.net, 2003
//



#include <ntddk.h>
#include <windef.h>

typedef PVOID *PPVOID;
#include "w2k_def_jr.h"
#include "kmodule.h"

const WCHAR devLink[]  = L"\\??\\klister";
const WCHAR devName[]  = L"\\Device\\klister";

PLIST_ENTRY pKiWaitInListHead ;
PLIST_ENTRY pKiWaitOutListHead ;
PLIST_ENTRY pKiDispatcherReadyListHead ;

KLISTER_PROCINFO procs[MAX_PROCS];

DWORD nprocs = 0;

void insertProc (PEPROCESS obAddr) {
	DWORD i;
	for (i = 0; i < nprocs; i++)
		if (procs[i].obAddr == (int)obAddr) return;
	
	procs [nprocs].obAddr = (int)obAddr;
	procs [nprocs].pid = obAddr->UniqueProcessId;
	strncpy (procs [nprocs].name, obAddr->ImageFileName, 16); 
	nprocs++;
}

ServiceTableInfo SrvTables[MAX_SERVICETABLES];
DWORD nSrvTables = 0;

void insertServTable (int tid, int addr, int n) {
	DWORD i;
	for (i = 0; i < nSrvTables; i++)
		if (SrvTables[i].addr == addr) {
			// we ignore buffer overflow here ;)
//			if (SrvTables[i].nthreads < MAX_THREADS)
//				SrvTables[i].threads[SrvTables[i].nthreads] = tid;
			
			SrvTables[i].n = n;
			SrvTables[i].nthreads++;
			return;
		}
	
	SrvTables[nSrvTables].addr = addr;
	SrvTables[i].n = n;
	//SrvTables[nSrvTables].threads[0] = tid;
	SrvTables[nSrvTables].nthreads = 1;
	nSrvTables++;
}


PEPROCESS processObject (PETHREAD ethread) {
	return  (PEPROCESS)(ethread->Tcb.ApcState.Process);
}

/*
char* processName (PEPROCESS eprocess) {
	
	return &eprocess->ImageFileName[0];
}
*/	

void createProcList () {
	int i;
    PVOID obj;
	PETHREAD pethread;

	nprocs = 0;
	nSrvTables = 0;

	for (obj = pKiWaitInListHead->Flink;
		obj && obj != pKiWaitInListHead; obj = ((PLIST_ENTRY)obj)->Flink) {
	
			pethread = (PETHREAD) ((char*)obj - WAITLIST_OFFSET);
			insertServTable ((int)pethread->Cid.UniqueThread,
				(int)pethread->Tcb.pServiceDescriptorTable->ntoskrnl.ServiceTable,
				(int)pethread->Tcb.pServiceDescriptorTable->ntoskrnl.ServiceLimit);

			insertProc (processObject (pethread));
	}

	for (obj = pKiWaitOutListHead->Flink;
		obj && obj != pKiWaitOutListHead; obj = ((PLIST_ENTRY)obj)->Flink) {
	
			pethread = (PETHREAD) ((char*)obj - WAITLIST_OFFSET);
			insertServTable ((int)pethread->Cid.UniqueThread,
				(int)pethread->Tcb.pServiceDescriptorTable->ntoskrnl.ServiceTable,
				(int)pethread->Tcb.pServiceDescriptorTable->ntoskrnl.ServiceLimit);

			insertProc (processObject (pethread));
	}

	for (i = 0; i < 32; i++) 
			for (obj = pKiDispatcherReadyListHead[i].Flink;
					obj != &pKiDispatcherReadyListHead[i];
					obj = ((PLIST_ENTRY)obj)->Flink) {
	
						
					pethread = (PETHREAD) ((char*)obj - WAITLIST_OFFSET);
					insertServTable ((int)pethread->Cid.UniqueThread,
						(int)pethread->Tcb.pServiceDescriptorTable->ntoskrnl.ServiceTable,
						(int)pethread->Tcb.pServiceDescriptorTable->ntoskrnl.ServiceLimit);
					insertProc (processObject (pethread));
											
				
					}
		
}


PIDTGATE readIDT() {
	IDTR idtr;

	__asm {
		sidt idtr;
	}

	return(PIDTGATE) idtr.base;
}


NTSTATUS klisterDeviceControl(
    IN PDEVICE_OBJECT pDeviceObject,
    IN ULONG IoControlCode, 
    IN PVOID pInputBuffer, 
    IN ULONG InputBufferLength, 
    OUT PVOID pOutputBuffer, 
    IN ULONG OutputBufferLength, 
    OUT PIO_STATUS_BLOCK IoStatus
    
    ) 
{

    DWORD maxnproc, maxTbls, n, i, STn;
	PKLISTER_INIT pkl_init;

	IoStatus->Status = STATUS_SUCCESS;
    IoStatus->Information = 0;

    switch ( IoControlCode ) 
	{

	case IOCTL_KLISTER_INIT:

		if ((InputBufferLength != sizeof(KLISTER_INIT) ) || (pInputBuffer == NULL))
		{
			IoStatus->Status = STATUS_INVALID_BUFFER_SIZE;
			break;
		}
		
		pkl_init = (PKLISTER_INIT) pInputBuffer;

		pKiWaitInListHead  = (PLIST_ENTRY) pkl_init->pKiWaitInListHead_addr;
		pKiWaitOutListHead  = (PLIST_ENTRY) pkl_init->pKiWaitOutListHead_addr;
		pKiDispatcherReadyListHead  = (PLIST_ENTRY) pkl_init->pKiDispatcherReadyListHead_addr;

		KdPrint (("	pKiWaitInListHead: %#x\n", pKiWaitInListHead));
		KdPrint (("	pKiWaitOutListHead: %#x\n", pKiWaitOutListHead));
		KdPrint (("	pKiDispatcherReadyListHead: %#x\n", pKiDispatcherReadyListHead));

		for (i = 0; i < MAX_PROCS; i++)
			procs[i].pid = 0;

		for (i = 0; i < MAX_SERVICETABLES; i++)
			SrvTables[i].addr = 0;

	break;

	
	case IOCTL_KLISTER_LISTPROC:
		
		if ((OutputBufferLength < sizeof (KLISTER_PROCINFO)) || (pOutputBuffer == NULL))
		{
			IoStatus->Status = STATUS_INVALID_BUFFER_SIZE;
			break;
		
		}
           
		maxnproc = OutputBufferLength/sizeof (KLISTER_PROCINFO);
		createProcList();
		if (nprocs > maxnproc) n = maxnproc*sizeof (KLISTER_PROCINFO);
		else n = nprocs * sizeof (KLISTER_PROCINFO);

		
		memcpy (pOutputBuffer, (PVOID) &procs, n);
		
		IoStatus->Information = n;

	break; 

	case IOCTL_KLISTER_DUMP_IDT:
		if ((OutputBufferLength < sizeof (IDTGATE)*IDT_NGATES)
			|| (pOutputBuffer == NULL))
		{
			IoStatus->Status = STATUS_INVALID_BUFFER_SIZE;
			break;
		
		}
		

		n = sizeof (IDTGATE) * IDT_NGATES;
		memcpy (pOutputBuffer, (PVOID) readIDT(), n);
		
		IoStatus->Information = n;		

	break;

	case IOCTL_KLISTER_FIND_ST:
		if ((OutputBufferLength < sizeof (ServiceTableInfo))
			|| (pOutputBuffer == NULL))
		{
			IoStatus->Status = STATUS_INVALID_BUFFER_SIZE;
			break;
		
		}
				
		maxTbls = OutputBufferLength/sizeof(ServiceTableInfo);
		createProcList();

		if (nSrvTables > maxTbls) n = maxTbls*sizeof (ServiceTableInfo);
		else n = nSrvTables * sizeof (ServiceTableInfo);

		
		memcpy (pOutputBuffer, (PVOID) SrvTables, n);
		
		IoStatus->Information = n;

	break;

	case IOCTL_KLISTER_DUMP_ST:
		if ((InputBufferLength != sizeof(int) ) || (pInputBuffer == NULL))
		{
			IoStatus->Status = STATUS_INVALID_BUFFER_SIZE;
			break;
		}
		if ((OutputBufferLength < sizeof (int))
			|| (pOutputBuffer == NULL))
		{
			IoStatus->Status = STATUS_INVALID_BUFFER_SIZE;
			break;
		
		}
		
		STn = *(int*)pInputBuffer;	// no of ST to dump
		KdPrint (("	STn: %#x\n", STn));
	
		n = sizeof (int) * (SrvTables[STn].n);
		KdPrint(("klister: n = %d\n", n));
		
		n = (n > OutputBufferLength) ? OutputBufferLength : n;
		KdPrint(("klister: n = %d\n", n));

		memcpy (pOutputBuffer, (PVOID) SrvTables[STn].addr, n);
		KdPrint (("memcpy (pOutputBuffer, (PVOID) SrvTables[STn].addr, n)"));
		KdPrint (("pOutputBuffer = %#x\n", pOutputBuffer));
		KdPrint (("SrvTables[STn].addr = %#x\n", SrvTables[STn].addr));
		IoStatus->Information = n;		



	break;


	default:
		IoStatus->Status = STATUS_INVALID_DEVICE_REQUEST;
		break;
	}

    return IoStatus->Status;
}


NTSTATUS klisterDispatch(
    IN PDEVICE_OBJECT pDeviceObject, 
    IN PIRP pIrp 
    )
{
    PIO_STACK_LOCATION      irpStack;
    PVOID                   pInputBuffer;
    PVOID                   pOutputBuffer;
    ULONG                   inputBufferLength;
    ULONG                   outputBufferLength;
    ULONG                   ioControlCode;
	NTSTATUS				ntstatus;

    
    irpStack = IoGetCurrentIrpStackLocation (pIrp);

    pInputBuffer             = pIrp->AssociatedIrp.SystemBuffer;
    inputBufferLength       = irpStack->Parameters.DeviceIoControl.InputBufferLength;
    pOutputBuffer            = pIrp->AssociatedIrp.SystemBuffer;
    outputBufferLength      = irpStack->Parameters.DeviceIoControl.OutputBufferLength;
    ioControlCode           = irpStack->Parameters.DeviceIoControl.IoControlCode;

    ntstatus = pIrp->IoStatus.Status = STATUS_SUCCESS;
    pIrp->IoStatus.Information = 0;

    switch (irpStack->MajorFunction) {
    case IRP_MJ_CREATE:
        break;

    case IRP_MJ_SHUTDOWN:
        break;

    case IRP_MJ_CLOSE:
        break;

    case IRP_MJ_DEVICE_CONTROL:
       
        ntstatus = klisterDeviceControl(
			pDeviceObject, ioControlCode,
			pInputBuffer, inputBufferLength, 
			pOutputBuffer, outputBufferLength,
			&pIrp->IoStatus);
        break;
    }

	IoCompleteRequest( pIrp, IO_NO_INCREMENT );
    return ntstatus;   
}




NTSTATUS klisterUnload(IN PDRIVER_OBJECT pDriverObject)
{
    UNICODE_STRING          devLinkUnicd;
	PDEVICE_OBJECT			pObj;

	pObj = pDriverObject->DeviceObject;

	if (pObj != NULL)
	{
        RtlInitUnicodeString( &devLinkUnicd, devLink );
		IoDeleteSymbolicLink( &devLinkUnicd );
		IoDeleteDevice( pDriverObject->DeviceObject );
		return STATUS_SUCCESS;
	}
	return STATUS_SUCCESS;
}


NTSTATUS DriverEntry(
				   IN PDRIVER_OBJECT  pDriverObject,
				   IN PUNICODE_STRING pRegistryPath
					)
{
	
    NTSTATUS                ntStatus;
    UNICODE_STRING          devNameUnicd;
    UNICODE_STRING          devLinkUnicd;        
	PDEVICE_OBJECT			pDevice;

    RtlInitUnicodeString (&devNameUnicd,
                          devName );
    RtlInitUnicodeString (&devLinkUnicd,
                          devLink );
    
	ntStatus = IoCreateDevice ( pDriverObject,
                                0, 
                                &devNameUnicd,
                                FILE_DEVICE_KLISTER,
                                0,
                                TRUE,
                                &pDevice );

    if( !NT_SUCCESS(ntStatus)) {
		DbgPrint(("klister: cannot create device.\n"));
        return ntStatus;
	}

    ntStatus = IoCreateSymbolicLink (&devLinkUnicd, &devNameUnicd);
	
	if( !NT_SUCCESS(ntStatus)) {
		DbgPrint(("klister: cannot create symlink to device.\n"));
        return ntStatus;
	}

	
	pDriverObject->MajorFunction[IRP_MJ_SHUTDOWN]        =
    pDriverObject->MajorFunction[IRP_MJ_CREATE]          =
    pDriverObject->MajorFunction[IRP_MJ_CLOSE]           =
    pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]  = klisterDispatch;

	pDriverObject->DriverUnload                          = klisterUnload;

    
	KdPrint (("klister load succesfully\n"));
	return STATUS_SUCCESS;
}
