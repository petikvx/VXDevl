//
// This is the client program for the kmodule.sys kernel module.
// See kmodule source for details.
//
// Joanna Rutkowska, joanna<a>mailsnare.net, 2003
//




#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include "..\\kmodule\\kmodule.h"

#define VERSION "0.3"
#define devName L"\\\\.\\klister"

void die (char* s) {
	fprintf (stderr, "error: %s\n", s);
	exit (1);
}


int main (int argc, char **argv) {

	int i;
	fprintf (stderr, "IDT dumper %s, joanna rutkowska, 2003\n", VERSION);

	fprintf (stderr, "opening device %S...\n", devName);
	HANDLE hDevice = CreateFileW(devName ,
                          GENERIC_READ | GENERIC_WRITE,
                          0,
                          NULL,
                          OPEN_EXISTING,
                          FILE_ATTRIBUTE_NORMAL,
                          NULL
                          );
    if ( hDevice == ((HANDLE)-1) ) die ("can't open device");


	IDTGATE idt[IDT_NGATES];
	unsigned long bytesReturned = 0;
	
	fprintf (stderr, "sending  IOCTL_KLISTER_DUMP_IDT...\n");
	if(!DeviceIoControl(hDevice, IOCTL_KLISTER_DUMP_IDT,
							NULL,
							0,
							(LPVOID)&idt,
							sizeof (idt),
							&bytesReturned,
							NULL))
		die ("can't communicate with kernel module (IOCTL_KLISTER_LISTPROC)");


	
	for (i = 0; i < IDT_NGATES; i++) 
		fprintf (stdout, "IDT[%d] at %#x\n", 
		i, (idt[i].off2<<16) + (idt[i].off1));
	


	CloseHandle (hDevice);
	return 0;
}
