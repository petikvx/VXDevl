#pragma once

#define PFSRV_VERSION "2.11"

// delay (in msec) between the time the service starts and the moment
// the baseline is captured.
#define INITIAL_SLEEP_TIME	60*1000	

/* STOP_CONTROL is only for developing,
 * there is no reason for stoping the 
 * service in real life. moreover it is strongly
 * not recommended. becouse some malicious rootkit
 * can kill our pfservice process, hash of baselin is
 * kept in kernel, so we cancompare if it changed since the
 * last boot
 */
#define ALLOW_STOP_CONTROL


// how many iterations for baseline tests
#define BASELINE_NITER 1000

#define PROTECT_SERVICE_RESTART


// support traceing whole EP? currently not supported by client programs
// (i.e.) pfAgentSudio will suport it.

//#define TRACEPATH 1

// if pfDriver should use Debug Registers for hardware protection of IDT1
#define DR_PROTECTION 1

