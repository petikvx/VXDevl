/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#pragma once

#define PF_START			1
#define PF_GET_COUNT		2
#define PF_GET_TRACE		3
#define PF_QUERY			4	
#define PF_ANSWER			0xdefaced
#define PF_SERVICE_STARTED	0xbabe

#define pfServiceNo 0xa1
#define serviceMagic 0xdeadbeaf

#define TF_MASK 0x100	// TF mask in EFLAGS

#define pfDrvName TEXT("pf2drv")
#define szDrvSYS TEXT("pfDriver.sys")
