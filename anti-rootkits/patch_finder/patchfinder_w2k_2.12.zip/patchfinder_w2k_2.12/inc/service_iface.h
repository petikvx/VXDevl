#pragma once


#define SRVCMD_CHECK_MODULE 1	// check if kenrel driver is loaded
#define SERCMD_CHECK_HASH 2		// check if hashes are ok
#define SRVCMD_RUN_TEST 3

#define SRVRESP_MODULE_PRESENT 1
#define SRVRESP_MODULE_NOT_PRESENT 2
#define SRVRESP_OK 5
#define SRVRESP_INVALID_CMD -1

#define TSTNAMELEN 256
#define TSTNAMELENSHORT 128

typedef struct _SRVCMD {
	int cmd;	// what client wants from us?
	int resp;	// soemtimes server responds

	int testno;	// which test
	int niter;	// how many iterations

	/* result for this test on the current system */
	int peekCurr;
	double peekPrCurr;
	
	/* result for this test, taken at system boot */
	/* thus considered as a 'clear' baseline */
	int peekClear;
	double peekPrClear;
	char shortname [TSTNAMELENSHORT];


} SRVCMD, *PSRVCMD;



#define pfPipeCmd TEXT("\\\\.\\pipe\\pf_cmd")
#define pfPipeData TEXT("\\\\.\\pipe\\pf_data")
#define pfSrvName TEXT("pf2")
#define szSrvEXE TEXT("pfService.exe")

#define pfAppName TEXT("pfService")
#define pfAgentName TEXT("pfAgent")

// change this when adding new tests!
#define pfNTESTS 8		// how many tests are defined

