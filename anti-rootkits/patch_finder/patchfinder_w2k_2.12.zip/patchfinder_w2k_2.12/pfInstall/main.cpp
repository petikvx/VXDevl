
#include <windows.h>
#include <stdio.h>
#include "..\inc\service_iface.h"
#include "..\inc\kernel_iface.h"

#define warn(str) {				\
	fprintf (stderr, " ERROR:"##str##"\n"); \
		return FALSE;	\
	}

BOOL InstallService(PTSTR szModulePathname) {

   // Open the SCM on this machine.
   SC_HANDLE hSCM = 
      OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
	
   if (hSCM == NULL) warn ("Cannot open SCM manager");


   PCTSTR pszDeps = "Eventlog\0";

   // Add this service to the SCM's database.
   SC_HANDLE hService = 
      CreateService(hSCM, pfSrvName, pfSrvName,
         SERVICE_CHANGE_CONFIG, SERVICE_WIN32_OWN_PROCESS, 
         SERVICE_AUTO_START, SERVICE_ERROR_IGNORE,
         szModulePathname, NULL, NULL, pszDeps, NULL, NULL);

   if (hService == NULL) warn ("Cannot create service entry");

   SERVICE_DESCRIPTION sd = { 
      TEXT("PatchFinder 2.0")
    };
   ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &sd);

   CloseServiceHandle (hService);
   CloseServiceHandle (hSCM);
   return TRUE;
	
}

BOOL InstallDriver(PTSTR szModulePathname) {

   // Open the SCM on this machine.
   SC_HANDLE hSCM = 
      OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);

   if (hSCM == NULL) warn ("Cannot open SCM manager");
   // Add this service to the SCM's database.
   SC_HANDLE hService = 
      CreateService(hSCM, pfDrvName, pfDrvName,
         0, SERVICE_KERNEL_DRIVER, 
		 SERVICE_SYSTEM_START, SERVICE_ERROR_IGNORE,
	     szModulePathname, NULL, NULL, NULL, NULL, NULL);

   if (hService == NULL) warn ("Cannot create driver entry");

   CloseServiceHandle (hService);
   CloseServiceHandle (hSCM);
   return TRUE;
}



BOOL RemoveService(PTSTR srvName) {

   // Open the SCM on this machine.
   SC_HANDLE hSCM = 
      OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
   if (hSCM == NULL) warn ("Cannot open SCM manager");

   // Open this service for DELETE access
   SC_HANDLE hService = 
      OpenService(hSCM, srvName, DELETE);
   if (hService == NULL) warn ("Cannot open service entry");

   // Remove this service from the SCM's database.
   if (DeleteService(hService) == 0)
	   warn ("Cannot delete service entry");
    
   CloseServiceHandle (hService);
   CloseServiceHandle (hSCM);
   return TRUE;
}

BOOL RemoveDriver(PTSTR drvName) {

   // Open the SCM on this machine.
   SC_HANDLE hSCM = 
      OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
   if (hSCM == NULL) warn ("Cannot open SCM manager");

   // Open this service for DELETE access
   SC_HANDLE hService = 
      OpenService(hSCM, drvName, DELETE);
   if (hService == NULL) warn ("Cannot open driver entry");

   // Remove this service from the SCM's database.
   if (DeleteService(hService) == 0)
	   warn ("Cannot delete driver entry");
    
   CloseServiceHandle (hService);
   CloseServiceHandle (hSCM);

   TCHAR szSubKey[_MAX_PATH];

   wsprintf(szSubKey, 
      TEXT("System\\CurrentControlSet\\Services\\%s"), 
	  drvName);
   
	
   if (RegDeleteKey(HKEY_LOCAL_MACHINE, szSubKey)!= NO_ERROR)
		warn ("Cannot delete registry key for the driver");

   
   return TRUE;
}


BOOL RemoveEventLog (PTSTR appName) {
	TCHAR szSubKey[_MAX_PATH];
	wsprintf(szSubKey, 
      TEXT("System\\CurrentControlSet\\Services\\EventLog\\System\\%s"), 
	  appName);
   
	if (RegDeleteKey(HKEY_LOCAL_MACHINE, szSubKey)!= NO_ERROR)
		warn ("Cannot delete registry key");
	return TRUE;
}


void usage (char *prog) {

	printf ("patchfinder2 installer\n");
	printf ("%s --install <pf_dir>\n", prog);
	printf ("%s --uninstall\n", prog);
	exit (1);
}

BOOL checkFile (PTSTR file) {

	HANDLE hFile = CreateFile (file, GENERIC_READ,
		0, NULL, OPEN_EXISTING, 0, NULL);
	if (hFile == INVALID_HANDLE_VALUE) return FALSE;
	return TRUE;
}

int main (int argc, char **argv) {

	OSVERSIONINFOEX	osver;
	osver.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	GetVersionEx ((LPOSVERSIONINFO)&osver);

	if (osver.dwBuildNumber != 2195) {
		fprintf (stderr,
			"Sorry, only Windows 2000 is currently supported :(\n");
		exit (1);
	}

	if (argc != 2 && argc != 3) usage (argv[0]);
	
	



	if (strncmp(argv[1], "--install", 8) == 0) {
		if (argc != 3) usage(argv[0]);
		char szImagePath[4096];

		sprintf (szImagePath, "%s\\%s", argv[2], szDrvSYS);

		if (!checkFile (szImagePath)) {
			fprintf (stderr, "cannot find %s file in that directory\n",
				szDrvSYS);
			exit (2);
		}
		
		fprintf (stderr, "installing pfDriver...");
		if (InstallDriver (szImagePath) == TRUE)
			fprintf (stderr, "done.\n");
		
		
		sprintf (szImagePath, "%s\\%s", argv[2], szSrvEXE);

		if (!checkFile (szImagePath)) {
			fprintf (stderr, "cannot find %s file in that directory\n",
				szSrvEXE);
			exit (2);
		}

		fprintf (stderr, "installing pfService...");
		if (InstallService(szImagePath))
			fprintf (stderr, "done.\n");
		
		exit (0);				
	}

	if (strncmp(argv[1], "--uninstall", 10) == 0) {
		fprintf (stderr, "uninstalling pfDriver...");
		if (RemoveDriver(pfDrvName))
			fprintf (stderr, "done.\n");

		fprintf (stderr, "uninstalling pfService...");
		if (RemoveService(pfSrvName) == TRUE)
			fprintf (stderr, "done.\n");

		fprintf (stderr, "removing EventLog entry for %s...", pfAppName);
		if (RemoveEventLog (pfAppName))
			fprintf (stderr, "done.\n");

		fprintf (stderr, "removing EventLog entry for %s...", pfAgentName);
		if (RemoveEventLog (pfAgentName))
			fprintf (stderr, "done.\n");
					
		
		exit (0);
		
	}

	usage (argv[0]);
	return 0;
}

