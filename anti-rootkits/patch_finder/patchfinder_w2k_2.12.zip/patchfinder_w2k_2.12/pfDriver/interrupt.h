/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#ifndef INTERRUPT_H
#define INTERRUPT_H

#pragma pack(1)
typedef struct _IDTGATE {
        unsigned short  off1;
        unsigned short  sel;
        unsigned char   none, flags;
        unsigned short  off2;
} IDTGATE, *PIDTGATE;

#pragma pack(1)
typedef struct _IDTR {
        unsigned short  limit;
        unsigned int    base;
} IDTR, *PIDTR;

#pragma pack()

unsigned int getIntHandler (int vec);
unsigned int getIntGateAddr (int vec) ;
void setIntHandler (int vec, unsigned newHandler);


#endif