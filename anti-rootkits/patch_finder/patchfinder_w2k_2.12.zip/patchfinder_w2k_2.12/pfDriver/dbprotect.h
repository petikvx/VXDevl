/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#ifndef DBPROTECT_H
#define DBPROTECT_H


#define DB_PROT_EXEC  0
#define DB_PROT_WRITE 1
#define DB_PROT_RW	  3

#define DB_DR0 0
#define DB_DR1 1
#define DB_DR2 2
#define DB_DR3 3

#define DB_LEN_1B 0
#define DB_LEN_2B 1
#define DB_LEN_4B 3

int dbProtect (int reg, int addr, int len, int protection);
int dbSetGeneralProtection ();
int dbRemoveAllProtection ();


#endif