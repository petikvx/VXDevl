/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#include "dbprotect.h"
#include <ntddk.h>



int dbProtect (int reg, int addr, int len, int protection) {
	unsigned int dr7mask;
	KdPrint(("pf: dbProtect (DR%d = %#x)\n",
		reg, addr));

	
	
	switch (reg) {
	case 0:
		__asm {
			mov eax, addr;
			mov DR0, eax;
		}
		break;			
	case 1:
		__asm {
			mov eax, addr;
			mov DR1, eax;
		}
		break;			
	case 2:
		__asm {
			mov eax, addr;
			mov DR2, eax;
		}
		break;			
	case 3:
		__asm {
			mov eax, addr;
			mov DR3, eax;
		}
		break;			
	}

	dr7mask = 0x2<<(reg*2);
	dr7mask |= (( (len<<2) + protection) << (16+(4*reg)));
	__asm {
			mov eax, DR7;
			or  eax, dr7mask;
			mov DR7, eax;
	}
	
	
	
	return 1;
}




int dbSetGeneralProtection () {

	__asm {
		mov eax, DR7;
		or eax, 0x2000;
		mov DR7, eax;
	}
	return 1;
}


