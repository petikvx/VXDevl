/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#ifndef SST_H
#define SST_H

// from Schreiber's Undocumented Windows 2000
typedef NTSTATUS (NTAPI *NTPROC) ();
typedef NTPROC *PNTPROC;
typedef struct {
  PNTPROC	ServiceTable;
  PULONG	CounterTable;
  ULONG		ServiceLimit;
  PCHAR		ArgumentTable;
}	SYSTEM_SERVICE_TABLE,
  *PSYSTEM_SERVICE_TABLE;
typedef struct {
	SYSTEM_SERVICE_TABLE ntoskrnl;
	SYSTEM_SERVICE_TABLE win32k;
	SYSTEM_SERVICE_TABLE table3;
	SYSTEM_SERVICE_TABLE table4;
}	SERVICE_DESCRIPTOR_TABLE,
  *PSERVICE_DESCRIPTOR_TABLE;


extern PSERVICE_DESCRIPTOR_TABLE KeServiceDescriptorTable;


#endif
