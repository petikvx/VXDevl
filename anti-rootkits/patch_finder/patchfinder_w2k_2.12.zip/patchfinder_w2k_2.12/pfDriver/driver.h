/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#ifndef DRIVER_H
#define DRIVER_H

#include <ntddk.h>

#define NT_SYSTEM_SERVICE_INT 0x2e
#define NT_DEBUG_INT 0x1

#endif
