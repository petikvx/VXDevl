/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#include "interrupt.h"

unsigned getIntHandler (int vec) {
	IDTR idtr;
	PIDTGATE idt;

	__asm {
		sidt idtr;
	}

	idt = (PIDTGATE) idtr.base;
	
	return  (idt[vec].off2<<16) +
		(idt[vec].off1);
}

unsigned getIntGateAddr (int vec) {
	IDTR idtr;
	PIDTGATE idt;

	__asm {
		sidt idtr;
	}

	idt = (PIDTGATE) idtr.base;
	
	return  (int)&idt[vec];
}


void setIntHandler (int vec, unsigned newHandler) {
	IDTR idtr;
	PIDTGATE idt;

	__asm {
		cli;
		sidt idtr;
	}

	idt = (PIDTGATE) idtr.base;
	
	idt[vec].off2 = newHandler >> 16;
	idt[vec].off1 = newHandler & 0xffff;
	
	__asm{
		sti;
	}

}

