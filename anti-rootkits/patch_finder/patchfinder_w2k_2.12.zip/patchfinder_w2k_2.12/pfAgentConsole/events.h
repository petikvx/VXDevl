//
//  Values are 32 bit values layed out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: MSG_RESULTS_OK
//
// MessageText:
//
//  Machine %1 seems to be CLEAR, biggest test difference = %2. Tests with
//  difference greater then zero:
//  %3
//
#define MSG_RESULTS_OK                   ((DWORD)0x00000001L)

//
// MessageId: MSG_RESULTS_WARN
//
// MessageText:
//
//  Machine %1 DOES NOT seem to be CLEAR, biggest test difference = %2.
//  It can be false positive however. Rerun the tests or use pfAgentStudio
//  to analyse your machine. Tests with difference greater then zero:
//  %3
//
#define MSG_RESULTS_WARN                 ((DWORD)0x00000002L)

//
// MessageId: MSG_RESULTS_ALERT
//
// MessageText:
//
//  Machine %1 seems to be COMPROMISED!!!
//  It is unlikely it is a false positive!
//  Contact your forensic analysis specialist!
//  %3
//
#define MSG_RESULTS_ALERT                ((DWORD)0x00000003L)

//
// MessageId: MSG_PIPE_ERROR
//
// MessageText:
//
//  There was an error while communicating with pfService on machine %1!
//  Detailed error description: %2.
//
#define MSG_PIPE_ERROR                   ((DWORD)0x00000010L)

//
// MessageId: MSG_ERROR
//
// MessageText:
//
//  There was an error: %2.
//  Machine on which pfService is excpected: %1.
//
#define MSG_ERROR                        ((DWORD)0x00000012L)

