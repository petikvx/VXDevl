#include <windows.h>
#include <stdio.h>
#include <stdlib.h>


#include "..\inc\service_iface.h"
#include "EventLog.h"
#include "events.h"

char pipe[] = "\\pipe\\pf_cmd";
char pfPipe[2048];
CEventLog pfEventLog (pfAgentName);
char COMPUTER[1024];

#define WARN_TH 100
#define ALERT_TH 500

void die (int id, char *errstr) {
	
	PTSTR ppszStrings[] = {COMPUTER, errstr, NULL};
	int stringsNum = 0;
	switch (id) {
	case MSG_PIPE_ERROR:
		fprintf (stderr, "\nThere was an error while communicating with pfSerivce:");
		fprintf (stderr, "%s\n", errstr);
		fprintf (stderr, "It seems that pfService has been not started, or it is generating\n");
		fprintf (stderr, "the baseline after system boot. Check event log for details.\n");
		stringsNum = 2;
		break;
	
	case MSG_ERROR:
		fprintf (stderr, "ERROR: %s\n", errstr);
		stringsNum = 2;
		break;

	}

	
	pfEventLog.ReportEvent (EVENTLOG_ERROR_TYPE,
			0, id, CEventLog::REUSER_NOTAPPLICABLE,
			stringsNum, (LPCTSTR*)ppszStrings, 0, NULL);
	

	exit (1);
}

void usage (char *prg) {
	printf ("PatchFinder2 Agent, (c) Joanna Rutkowska, 2004\n");
	printf ("usage: %s [\\\\COMPUTER]\n", prg);
	exit (0);
}


int verbose = 0;

#define _info(msg) \
	if (verbose >= 1) \
	fprintf (stderr, msg);

void sendAndRecv (SRVCMD *srvcmd) {
	DWORD dwNumBytes;
	HANDLE hPipeCmd = CreateFile (pfPipe, GENERIC_READ | GENERIC_WRITE,
		0, NULL, OPEN_EXISTING, 0, NULL);
	if (hPipeCmd == INVALID_HANDLE_VALUE) 
		die (MSG_PIPE_ERROR, "cannot open pipe");
	

	WriteFile (hPipeCmd, (LPVOID)srvcmd, sizeof(SRVCMD), &dwNumBytes, NULL);
	if (dwNumBytes != sizeof(SRVCMD)) die (MSG_PIPE_ERROR, "writing to pipe error!");

	ReadFile (hPipeCmd, (LPVOID)srvcmd, sizeof(SRVCMD), &dwNumBytes, NULL);
	if (dwNumBytes != sizeof(SRVCMD)) die (MSG_PIPE_ERROR, "reading from pipe error!");
	CloseHandle (hPipeCmd);
	Sleep (300);	// Give some time for the service to call ConnectNamedPiep()
}

struct TRESULTS {
	int testno;
	int peek;
	double peekPr;
	int peek_baseline;
	double peekPr_baseline;
	char shortname [TSTNAMELENSHORT];
};


void updateProgressBar (char *msg, int i, int N, int pBarLen) {
		int j, pb = pBarLen*i/N;
		fprintf (stderr, "\r%s", msg);
		for (j = 0; j < pb; j++)
			fprintf (stderr, "#");
		for (; j < pBarLen; j++)
			fprintf (stderr, "_");
		if (i%4==0) fprintf (stderr, "|");
		if (i%4==1) fprintf (stderr, "/");
		if (i%4==2) fprintf (stderr, "-");
		if (i%4==3) fprintf (stderr, "\\");
}


int main (int argc, char **argv) {
	SRVCMD srvcmd;
	

	pfEventLog.Install (
		EVENTLOG_INFORMATION_TYPE | 
		EVENTLOG_WARNING_TYPE | 
		EVENTLOG_ERROR_TYPE,
		NULL, NULL, 1, NULL);


	strcpy (COMPUTER, "\\\\.");
	if (argc > 2) usage (argv[0]);
	if (argc == 2) {
		if (strncmp (argv[1], "-h", 2) == 0 ||
			strncmp (argv[1], "/h", 2) == 0 ||
			strncmp (argv[1], "/?", 2) == 0) usage (argv[0]);
			
		strncpy (COMPUTER, argv[1], sizeof(COMPUTER));
	}

	sprintf (pfPipe, "%s%s", COMPUTER, pipe);
	fprintf (stderr, "using pipe: %s\n", pfPipe);


	_info("checking for pf in the kenrel...");
	srvcmd.cmd = SRVCMD_CHECK_MODULE;
	sendAndRecv (&srvcmd);
	if (srvcmd.resp != SRVRESP_MODULE_PRESENT) 
		die (MSG_ERROR, "pfDriver not loaded!");
	_info("present.\n");

	int niter = 1000;
	
	struct TRESULTS tresults[pfNTESTS];

	for (int i = 0; i < pfNTESTS; i++) {
		updateProgressBar ("performing tests ", i, pfNTESTS, 50);
		srvcmd.cmd = SRVCMD_RUN_TEST;
		srvcmd.testno = i;
		srvcmd.niter = niter;
		sendAndRecv (&srvcmd);
		tresults[i].peek = srvcmd.peekCurr;
		tresults[i].peekPr = srvcmd.peekPrCurr;
		tresults[i].peek_baseline = srvcmd.peekClear;
		tresults[i].peekPr_baseline = srvcmd.peekPrClear;
		strcpy (tresults[i].shortname, srvcmd.shortname);
		

	}
	updateProgressBar ("performing tests ", pfNTESTS, pfNTESTS, 50);
	Sleep (300);	// :-)
	
	
	int max_diff = 0;
	printf ("\r"
	"---------------------------------------------------------------------\n"
	" test name            | current system| clear system   | diff    \n"
	"---------------------------------------------------------------------\n"
	);

	char raport[10000], raport1[1000];
	int diffno = 0;
	sprintf (raport, "\n");

	for (i = 0; i < pfNTESTS; i++) {
		int diff = abs (tresults[i].peek_baseline - tresults[i].peek);
		if (diff > max_diff) max_diff = diff;
		printf (
	" %20s | %6d (%3d%%) | %6d (%3d%%)  | %6d |\n",
		tresults[i].shortname,
		tresults[i].peek,
		(int)(tresults[i].peekPr*100),
		tresults[i].peek_baseline,
		(int)(tresults[i].peekPr_baseline*100),
		diff
		);
		if (diff > 0) {
			sprintf (raport1, "%s, diff = %d, pr = %.1f%%\n", 
				tresults[i].shortname, diff,
				tresults[i].peekPr*tresults[i].peekPr_baseline*100);
			strcat (raport, raport1);
			diffno++;
		}
		
	}

	if (diffno == 0)
		sprintf (raport, "All tests clear!");
	
	
	printf (
		"---------------------------------------------------------------------\n");
	char max_diff_str[100];
	sprintf (max_diff_str, "%d", max_diff);
	PTSTR ppszStrings[] = {COMPUTER, max_diff_str, raport, NULL};

	
	if (max_diff < WARN_TH) {
		pfEventLog.ReportEvent (EVENTLOG_INFORMATION_TYPE,
			0, MSG_RESULTS_OK, CEventLog::REUSER_NOTAPPLICABLE,
			3, (LPCTSTR*)ppszStrings, 0, NULL);
		
		printf ("Your system seems to be CLEAR.\n");
	}

	if (max_diff >= WARN_TH && max_diff <ALERT_TH) {
		pfEventLog.ReportEvent (EVENTLOG_WARNING_TYPE,
			0, MSG_RESULTS_WARN, CEventLog::REUSER_NOTAPPLICABLE,
			3, (LPCTSTR*)ppszStrings, 0, NULL);
		printf ("Your system DOES NOT seem to be CLEAR, false positive is");
		printf ("possible however. Rerun the tests or use pfAgentStudio.\n");
	}
	
	if (max_diff > ALERT_TH) {
		pfEventLog.ReportEvent (EVENTLOG_WARNING_TYPE,
			0, MSG_RESULTS_ALERT, CEventLog::REUSER_NOTAPPLICABLE,
			3, (LPCTSTR*)ppszStrings, 0, NULL);
		printf ("Your system seems to be COMPROMISED!!!");
	}


	return 0;
}
