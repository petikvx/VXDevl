/*
 *	PatchFinder 2.x for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003-2004
 *
 */

#ifndef TEST_H
#define TEST_H


#include "types.h"

#include "..\inc\service_iface.h"
#include "..\inc\config.h"



void clearTFbit () ;
void setTFbit () ;
int pfSrv (int cmd, int* tracebuf);

class TRACE {
public:
#ifdef TRACEPATH
	TRACE () {trace = 0; n = 0;}
	~TRACE () { delete trace; }
	int *trace;
#else
	TRACE () {n = 0;}
#endif
	int n;
};

class TEST {
public:
	TEST() { n = 0; trace = NULL; }
	~TEST() { delete []trace; }
	virtual int go (int N);	
	
	int getSamples (int *buf, int bufLen);

	int findPeek ();
	int getPeek();
	float getPeekPr();
	
	char *getName () { return name; }
	char *getNameShort () { return shortname; }

protected:
	int pfStart();
	int pfStop ();
	
	TRACE *trace;
	char name[TSTNAMELEN];
	char shortname [TSTNAMELENSHORT];
	int n, N;
	int peek;
	float peekPr;

};
typedef TEST* PTEST;


void die (char *str);

#endif

