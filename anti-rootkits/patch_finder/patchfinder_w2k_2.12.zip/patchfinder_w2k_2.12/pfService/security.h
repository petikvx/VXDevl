#pragma once

HANDLE OpenCurrentToken(ULONG lAccess, BOOL fOpenAsSelf) ;
PSID GetCurrentSID() ;
BOOL InitializePipeSecurity(SECURITY_ATTRIBUTES* pSA) ;
