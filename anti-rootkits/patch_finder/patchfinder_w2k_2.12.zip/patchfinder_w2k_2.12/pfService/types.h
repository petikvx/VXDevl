/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */
 
#ifndef TYPES_H
#define TYPES_H

#ifndef WIN32
#define FALSE 0
#define TRUE 1
typedef int BOOL;
typedef int FILEHANDLE;
#endif

#ifdef WIN32
#include <windows.h>
typedef HANDLE FILEHANDLE;
#endif

#endif




