/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */
 
#include "test.h"
#include "..\inc\kernel_iface.h"


#ifndef WIN32
#include <asm/unistd.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#endif

#include <stdio.h>



int TEST::pfStart () {
	setTFbit ();
	//assert (n < N);
	return pfSrv (PF_START, 0);
}

int TEST::pfStop() {
	clearTFbit ();
	
	int cnt = pfSrv (PF_GET_COUNT, 0);
	trace[n].n = cnt;
#ifdef TRACEPATH
	trace[n].trace = new int [cnt + 1];
	pfSrv(PF_GET_TRACE, trace[n].trace);
#else
	pfSrv(PF_GET_TRACE, 0);
#endif
	n++;	
	return 0;
}

int TEST::go (int _N) {
	n = 0;
	N = _N;

	if (trace) delete []trace;
	trace = new TRACE [N + 1];

	return 0;
}

typedef struct _SAMPLE {
	int value;
	int count;
	int testno;
	struct _SAMPLE *next;

} SAMPLE, *PSAMPLE;

int TEST::findPeek () {
	PSAMPLE p, head = NULL;
	
	for (int i = 0; i < N; i++) {
		BOOL found = FALSE;	
		if (head) for (p = head; p != NULL; p = p->next)
			if (p->value == trace[i].n) {
				p->count++;
				found = TRUE;
				break;
			}
		if (!found) {
			PSAMPLE newSmpl = new SAMPLE;
			newSmpl->next = head;
			head = newSmpl;
			newSmpl->count = 0;
			newSmpl->value = trace[i].n;
			newSmpl->testno = i;
		}

	}

	int peekVal = 0;
	int peekTest = 0;
	peek = 0;
	peekPr = 0;
	for (p = head; p != NULL; p = p->next)
		if (p->count > peekVal) {
			peekTest = p->testno;
			peekVal = p->count;
			peek = p->value;
			peekPr = (float)(p->count+1)/N;
		}
	
	for (p = head; p != NULL;) {
		
		PSAMPLE tmp = p;
		p = p->next;
		delete tmp;
	}
	
	
		
	return peekTest;
		
}

int TEST::getPeek() {
	findPeek();
	return peek;
}

float TEST::getPeekPr() {
	findPeek();
	return peekPr;
}

int TEST::getSamples (int *buf, int bufLen) {
	if (bufLen < N) return 0;
	for (int i = 0; i < N; i++)
		buf[i] = trace[i].n;
	return bufLen;
}


typedef struct _TESTSAVE {
	char name [TSTNAMELEN];
	int N;
} TSTSAVE, *PTSTSAVE;



