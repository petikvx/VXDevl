/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */

#pragma once
#include <string.h>

class test_FindFile : public TEST {
public:
	test_FindFile () : TEST()  {
		strcpy (shortname, "FindFile");
		strcpy (name, "FindFile (C:\\WINNT\\system32\\drivers)");
	};
	int go (int N) {
		WIN32_FIND_DATA FindFileData;
		HANDLE hFind;
		TEST::go (N);

		for (int i = 0; i < N; i++)	 {
			pfStart();
			hFind = FindFirstFile("C:\\WINNT\\system32\\drivers", &FindFileData);
			pfStop();

			if (hFind == INVALID_HANDLE_VALUE) 	return 0;
			else FindClose(hFind);
		}
		return N;
	}
};

//////////////////////////////////////////////////////////////////////////////

class test_OpenFile : public TEST {
public:
	test_OpenFile () : TEST()  {
		strcpy (shortname, "OpenFile");
		strcpy (name, "CreateFile (C:\\WINNT\\system32\\ntoskrnl.exe)");
	};
	int go (int N) {
		HANDLE hFile;
		TEST::go (N);

		for (int i = 0; i < N; i++)	 {
			pfStart();
			hFile = CreateFile("C:\\WINNT\\system32\\NTOSKRNL.EXE",
				GENERIC_READ, 0, NULL, OPEN_EXISTING,
				0, NULL);
				
			pfStop();

			if (hFile == INVALID_HANDLE_VALUE) 	return 0;
			else CloseHandle(hFile);
		}
		return N;
	}
};

//////////////////////////////////////////////////////////////////////////////


typedef unsigned long NTSTATUS;

#define NT_SUCCESS(Status) ((NTSTATUS)(Status) >= 0)
#define SystemProcessAndThreadsInfo 5

class test_Processes : public TEST {
public:
	test_Processes () : TEST()  {
		strcpy (shortname, "Processes");
		strcpy (name, "ZwQuerySystemInformation (SystemProcessAndThreadsInfo)");
	};
	int go (int N) {
		DWORD buf[1];
		DWORD retLen;
		TEST::go (N);

		NTSTATUS (__stdcall *ZwQuerySystemInformation)(
		  IN DWORD SystemInformationClass,
		  IN OUT PVOID SystemInformation,
		  IN ULONG SystemInformationLength,
		  OUT PULONG ReturnLength 
		);


		ZwQuerySystemInformation = (NTSTATUS (__stdcall *)(DWORD, PVOID, ULONG, PULONG))
			GetProcAddress(	GetModuleHandle("ntdll.dll"),
				"ZwQuerySystemInformation" );
		
		if (!ZwQuerySystemInformation) {
			fprintf (stderr, "can't load ZwQuerySystemInfo\n");
			return 0;
		}

		for (int i = 0; i < N; i++)	 {
			pfStart();

			NTSTATUS result = ZwQuerySystemInformation (
				SystemProcessAndThreadsInfo,
				buf,
				sizeof(buf),
				&retLen);

				
			pfStop();
		}
		return N;
	}
};

//////////////////////////////////////////////////////////////////////////////

class test_null : public TEST {
public:
	test_null () : TEST()  {
		strcpy (shortname, "null(nop)");
		strcpy (name, "null (nop)");
	};
	int go (int N) {
		TEST::go (N);
		for (int i = 0; i < N; i++)	 {
			pfStart();
			_asm nop;		
			pfStop();
		}
		return N;
	}
};

//////////////////////////////////////////////////////////////////////////////

class test_recvNull : public TEST {
public:
	test_recvNull () : TEST()  {
		strcpy (shortname, "recv_null");
		strcpy (name, "recv(0,0,0,0)");
	};
	int go (int N) {
			
		TEST::go (N);

		for (int i = 0; i < N; i++)	 {
			pfStart();
			recv(0, 0, 0, 0);		
			pfStop();
		}
		return N;
	}
};
//////////////////////////////////////////////////////////////////////////////

class test_RegEnumNull : public TEST {
public:
	test_RegEnumNull () : TEST()  {
		strcpy (shortname, "RegEnumKey_null");
		strcpy (name, "RegEnumKeyEx(NULL)");
	};
	int go (int N) {
		TEST::go (N);
		for (int i = 0; i < N; i++)	 {
			pfStart();
		
			RegEnumKeyExW (
				NULL,
				0,
				NULL,
				NULL,
				NULL, NULL, NULL,
				NULL
				);

			pfStop();
			
		}
		return N;
	}
};

//////////////////////////////////////////////////////////////////////////////

class test_RegEnum : public TEST {
public:
	test_RegEnum () : TEST()  {
		strcpy (shortname, "RegEnumKey");
		strcpy (name, "RegEnumKey(\"HKLM\")");
	};
	int go (int N) {
		TEST::go (N);
		for (int i = 0; i < N; i++)	 {
			
			HKEY hKey;
			LONG ret = RegOpenKeyExW(
				HKEY_LOCAL_MACHINE,
				NULL,
				NULL,
				KEY_ENUMERATE_SUB_KEYS,
				&hKey);

			WCHAR buf[1024];	
			DWORD bufLen = sizeof(buf) ;
			FILETIME ftLast;
			
			pfStart();
			
			RegEnumKeyExW (
				hKey,
				0,
				buf,
				&bufLen,
				NULL, NULL, NULL,
				&ftLast
				);

			pfStop();
			RegCloseKey (hKey);
		}
		return N;
	}
};

//////////////////////////////////////////////////////////////////////////////

class test_RegOpenKey : public TEST {
public:
	test_RegOpenKey () : TEST()  {
		strcpy (shortname, "RegOpenKey");
		strcpy (name, "RegOpenKey(\"HKLM\")");
	};
	int go (int N) {
		TEST::go (N);
		for (int i = 0; i < N; i++)	 {
		
			HKEY hKey;
			pfStart();
			LONG ret = RegOpenKeyExW(
				HKEY_LOCAL_MACHINE,
				NULL,
				NULL,
				KEY_ENUMERATE_SUB_KEYS,
				&hKey);
	
			pfStop();
			RegCloseKey (hKey);
		}
		return N;
	}
};

