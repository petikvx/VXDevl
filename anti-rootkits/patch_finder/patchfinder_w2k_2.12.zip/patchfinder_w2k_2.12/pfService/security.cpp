#include <windows.h>


// stolen from Richter&Clark book about Services ;)

HANDLE OpenCurrentToken(ULONG lAccess, BOOL fOpenAsSelf) {

   HANDLE hToken = NULL;

   if (!OpenThreadToken(GetCurrentThread(), lAccess, fOpenAsSelf, &hToken) 
         && GetLastError() == ERROR_NO_TOKEN) {
      if (!OpenProcessToken(GetCurrentProcess(), lAccess, &hToken)) {
         hToken = NULL;
      }
   }

   return (hToken);
}

PSID GetCurrentSID() {
   
   HANDLE hToken = NULL;
   PSID psid = NULL;
   PTOKEN_USER pUser = {0};
   
   try { {
      
      hToken = OpenCurrentToken(TOKEN_QUERY, TRUE);
      if (hToken == NULL)
         goto leave;
      
      ULONG lSize = 0;
      GetTokenInformation(hToken, TokenUser, NULL, 0, &lSize);
      pUser = (PTOKEN_USER) HeapAlloc(GetProcessHeap(), 0, lSize);
      if (pUser == NULL)
         goto leave;

      if (!GetTokenInformation(hToken, TokenUser, pUser, lSize, &lSize))
         goto leave;

      // Go through this hoopla because we want the returned SID to be freeable
      // via freesid()
      if (!AllocateAndInitializeSid(GetSidIdentifierAuthority(pUser->User.Sid),
            *GetSidSubAuthorityCount(pUser->User.Sid),
            *GetSidSubAuthority(pUser->User.Sid, 0),
            *GetSidSubAuthority(pUser->User.Sid, 1),
            *GetSidSubAuthority(pUser->User.Sid, 2),
            *GetSidSubAuthority(pUser->User.Sid, 3),
            *GetSidSubAuthority(pUser->User.Sid, 4),
            *GetSidSubAuthority(pUser->User.Sid, 5),
            *GetSidSubAuthority(pUser->User.Sid, 6),
            *GetSidSubAuthority(pUser->User.Sid, 7),
            &psid)) {
         psid = NULL;
         goto leave;
      }

   } leave:;
   }
   catch (...) {
   }

   if (pUser != NULL)
      HeapFree(GetProcessHeap(), 0, pUser);
   if (hToken != NULL)
      CloseHandle(hToken);
   
   return (psid);
}

BOOL InitializePipeSecurity(SECURITY_ATTRIBUTES* pSA) {

   BOOL fReturn = FALSE;
   PSECURITY_DESCRIPTOR pSD = NULL;
   PSID psidOwner = NULL;
   PSID psidEveryone = NULL;

   try { {
   
      // Setup the SECURITY_ATTRIBUTES structure
      pSA->nLength = sizeof(SECURITY_ATTRIBUTES);
      pSA->bInheritHandle = FALSE;
      pSA->lpSecurityDescriptor = NULL;
/*
      // Create a SID for the "Everyone" well-known group
      SID_IDENTIFIER_AUTHORITY sidAuth = SECURITY_WORLD_SID_AUTHORITY;
      if (!AllocateAndInitializeSid(&sidAuth, 1, SECURITY_WORLD_RID, 0, 0, 0, 
            0, 0, 0, 0, &psidEveryone))
         goto leave;
*/

      // Create a SID for the "Authenticated-Users" well-known group
      SID_IDENTIFIER_AUTHORITY sidAuth = SECURITY_NT_AUTHORITY;
      if (!AllocateAndInitializeSid(&sidAuth, 1, 11, 0, 0, 0, 
            0, 0, 0, 0, &psidEveryone))
         goto leave;



      // Get the SID for the Token User
      psidOwner = GetCurrentSID();
      if (psidOwner == NULL)
         goto leave;

      // Calculate the size of the SD and ACL needed
      ULONG lSDSize = sizeof(SECURITY_DESCRIPTOR);
      ULONG lACLSize = 0;
      lACLSize += GetLengthSid(psidEveryone);
      lACLSize += GetLengthSid(psidOwner);
      lACLSize += sizeof(ACCESS_ALLOWED_ACE) * 2;
      lACLSize += sizeof(ACL);

      // Allocate the memory
      pSD = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, lSDSize + lACLSize);
      if (pSD == NULL)
         goto leave;

      // Setup SD and DACL, and assign DACL to SD
      InitializeSecurityDescriptor(pSD, SECURITY_DESCRIPTOR_REVISION);

      PACL pacl = (PACL) (((PBYTE) pSD) + lSDSize);
      InitializeAcl(pacl, lACLSize, ACL_REVISION);
      SetSecurityDescriptorDacl(pSD, TRUE, pacl, FALSE);

      // Add aces to the DACL
      if (!AddAccessAllowedAce(pacl, ACL_REVISION, FILE_GENERIC_READ 
            | FILE_GENERIC_WRITE, psidEveryone))
         goto leave;

      if (!AddAccessAllowedAce(pacl, ACL_REVISION, FILE_ALL_ACCESS, psidOwner))
         goto leave;

      pSA->lpSecurityDescriptor = pSD;
      fReturn = TRUE;

   } leave:;
   }
   catch (...) {
   }

   // Cleanup
   if (psidOwner != NULL)
      FreeSid(psidOwner);

   if (psidEveryone != NULL)
      FreeSid(psidEveryone);

   if (!fReturn &&pSD != NULL)
      HeapFree(GetProcessHeap(), 0, pSD);

   return (fReturn);
}

///////////////////////////////////////////////////////////////////////////////
