/*
 *	PatchFinder for Windows 2000
 *	Joanna Rutkowska, joanna at mailsnare dot net
 *	(c) 2003
 *
 */



#define pfServiceNo 0xa1
#define serviceMagic 0xdeadbeaf

#define TF_MASK 0x100	// TF mask in EFLAGS


int _declspec ( naked ) _pfSrv (int magic, int cmd, int* tracebuf) {
	_asm {
		mov eax, pfServiceNo;
		lea edx, [esp+4];
		int 2eh;
		
		ret;	// FIXME
	}
}


int pfSrv (int cmd, int* tracebuf) {
	return _pfSrv(serviceMagic, cmd, tracebuf);
}



void clearTFbit () {
	_asm {
		pushfd;
		pop eax;
		and eax, 0xfffffeff;
		push eax;
		popfd;
	}
}

void setTFbit () {
	_asm {
		pushfd;
		pop eax;
		or eax, 0x100;
		push eax;
		popfd;
	}

}
