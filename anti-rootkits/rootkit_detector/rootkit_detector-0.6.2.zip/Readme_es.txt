Rootkit Detector v0.6.2
======================


Rootkit Detector Profesional 2004
Programado por aT4r@3wdesign.es
Homepage: http://www.3WDesign.es/security Copyright (c) 2003 
	  http://www.haxorcitos.com



Usage:
-----

rkd.exe [params]

	-v 		- Muestra informacion extra.
	-m  programa	- Genera un informe sobre un programa sospechoso.


Descripcion:
------------
Esta utilidad proporciona informacion acerca de procesos y servicios ocultos en su sistema por NT rootkits como Hacker Defender (rootkit.host.sk)
no detectadas por software antivirus Una vez se han insstalado en el sistema.
Despues de identificar handles ocultos, rootkit Detector intentara matar dichas tareas y reescanear el sistema para identificar servicios y claves
ocultas en el registro (Run, runOnce,...)instalados en el sistema por hackers.
Otra de las capacidades de Rootkit Detector es que incluye una base de datos Interna con las firmas MD5 de multiples rootkits, exploits y utilidades
de hacking conocidas. si bien estas pueden ser alteradas, en muchas ocasiones estos resultados no variaran.

Un Informe Completo sera Generado con informacion sobre todos lor procesos y servicios que corren en el sistema incluyendo checksums en MD5.
Si encuentra en su sistema algun proceso o programa que Rootkit Detector no es capaz de identificar, envienos un informe completo a at4r@3wdesign.es
proporcionandonos la mayor informacion posible y nuestro equipo de seguridad incluira dichas entradas en la proxima version.
Ejemplo:
Encontrado programa XXXXXXXXXX.exe con checksum md5 FFFFFFFFFFFFFFFFFF identificado como "Escanner http".
Encontrado programa YYYYYYYYYY.exe con checksum md5 FFFFFFFFFFFFFFFFFF identificado como "Servidor tftp".

Si no es capaz de identificar la funcion de ese programa, no dude en enviarnos el/los ficheros adjuntos al email.

Para cualquier duda, visite nuestro Foro en el portal www.shellsec.net 





Informacion de Contacto:
------------------------

at4r@3wdesign.es		- Enviar bugs / Informes
comercial@3wdesign.es		- Informacion Sobre auditorias de seguridad para su empresa.




------------------------------------------------------------
            3W Design Security (c) 20003
------------------------------------------------------------