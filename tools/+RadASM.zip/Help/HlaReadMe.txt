Using RadASM to edit HLA code.

Hla uses nmake and a make file to build projects. In hla.ini you can find section [Enviroment].
You must manually change it to reflect your configuration.

If you are manually editing RadASM.ini, then make the following changes:
[FileBrowser]
Filter=.asm.inc.rc.txt.doc.rtf.dlg.mnu.rap.bmp.ico.cur.hla.hhf.
[Assembler]
Assembler=masm,fasm,tasm,nasm,hla
[Template]
Txt=.asm.inc.def.rc.txt.mak.tbr.hla.hhf.

KetilO