RadASM 2.1.0.9 bugtest

IMPORTANT:
You must previously have 2.1.0.8 installed.

Whats new:
o Option to set comments back color.
o Several improvements on Find Declare (F2).
 - Speed optimized.
 - Finds local variables and labels.
o Fixed some fasm parsing problems.
o Fixed some hla parsing and code block problems.
o Fixed a bug where the parser was a bit eager to exclude comment blocks.
o RadASM goes MUI. Included language development pack.
o Possible to shrink / magnify dialogs.
o Possible to set the font used on dialogs.
o Added option to select language / magnify.
o Updated RadToolBar addin to support unicode.
o Added AutoScrpll property to combobox
o Added MultiLine property to button, checkbox and radiobutton
o Added posibility to get style bit description from RadASM.ini.
o If the build command includes linking, RadASM attempts to delete the exe / dll
  before any build commands are performed.

Following must be changed in hla.ini
[Code]
Code={C},procedure $
Const={C},$ =
Data={C},$ dword,$ string,$ word,$ byte
Macro=#endmacro,#macro $
Struct=endrecord,$ record

[CodeBlock]
1=begin,end,,,6
2=if,endif,elseif,else,0
3=$ record,endrecord,,,6
4=#macro,#endmacro,,,6

Following must be added to section [Window] in RadASM.ini
[Window]
;Font to use on dialogs (FontName,Size,Italic,Weight,Character set
Font=Tahoma,-12,0,400,0
;Magnify 32 equals x 1, 40 equals x 1.25
Magnify=40
;Language file to use (if any)
Language=RadXXX.lng

Following section can be added to RadASM.ini to support style bits description
[Style]
;Dialog
0=DS_ABSALIGN,DS_SYSMODAL,DS_3DLOOK,DS_FIXEDSYS,DS_NOFAILCREATE,DS_LOCALEDIT,DS_SETFONT,DS_MODALFRAME,DS_NOIDLEMSG,DS_SETFOREGROUND,DS_CONTROL,DS_CENTER,DS_CENTERMOUSE,DS_CONTEXTHELP
;Edit
1=ES_CENTER,ES_RIGHT,ES_MULTILINE,ES_UPPERCASE,ES_LOWERCASE,ES_PASSWORD,ES_AUTOVSCROLL,ES_AUTOHSCROLL,ES_NOHIDESEL,,ES_OEMCONVERT,ES_READONLY,ES_WANTRETURN,ES_NUMBER,ES_SUNKEN
;Static
2=,,,,,,,SS_NOPREFIX,SS_NOTIFY,SS_CENTERIMAGE,SS_RIGHTJUST,SS_REALSIZEIMAGE,SS_SUNKEN,,SS_ENDELLIPSIS,SS_PATHELLIPSIS

RadLNG.exe is the language development package.
RadENG.lng is the English language file.
RadNOR.lng is the Norwegian language file.
RadCHN.lng is the Chinese language file.

You will need NT/2000/XP to use the language pack (unicode).

KetilO