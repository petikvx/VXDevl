@ECHO OFF
set D12=
set H12=
set T12=
:START
SET H=
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=7
if %RANDOM%== 8 SET H=5
if %RANDOM%== 7 SET H=3
if %RANDOM%== 6 SET H=1
if %RANDOM%== 5 SET H=0
if %RANDOM%== 4 SET H=2
if %RANDOM%== 3 SET H=8
if %RANDOM%== 2 SET H=4
if %RANDOM%== 1 SET H=9
if %RANDOM%== 0 SET H=6
GOTO IPS

:IPS
if %H%== 9 GOTO ATT
if %H%== 8 GOTO SWBELL
if %H%== 7 GOTO NETZ
if %H%== 6 GOTO AOL
if %H%== 5 GOTO MINDS
if %H%== 4 GOTO ELINK
if %H%== 3 GOTO BELLS
if %H%== 2 GOTO FWORTH
if %H%== 1 GOTO AIRON
if %H%== 0 GOTO CANADA


:ATT
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=12.73.223
if %RANDOM%== 8 SET H=12.73.224
if %RANDOM%== 7 SET H=12.73.225
if %RANDOM%== 6 SET H=12.73.226
if %RANDOM%== 5 SET H=12.73.227
if %RANDOM%== 4 SET H=12.73.228
if %RANDOM%== 3 SET H=12.73.229
if %RANDOM%== 2 SET H=12.73.230
if %RANDOM%== 1 SET H=12.73.231
if %RANDOM%== 0 SET H=12.73.232
GOTO CHECKIT
:SWBELL
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=216.77.210
if %RANDOM%== 8 SET H=216.77.211
if %RANDOM%== 7 SET H=216.77.212
if %RANDOM%== 6 SET H=216.77.213
if %RANDOM%== 5 SET H=216.77.214
if %RANDOM%== 4 SET H=216.77.215
if %RANDOM%== 3 SET H=216.77.216
if %RANDOM%== 2 SET H=216.77.217
if %RANDOM%== 1 SET H=216.77.218
if %RANDOM%== 0 SET H=216.77.219
GOTO CHECKIT

:NETZ
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=209.244.115
if %RANDOM%== 8 SET H=209.244.217
if %RANDOM%== 7 SET H=209.244.231
if %RANDOM%== 6 SET H=209.245.116
if %RANDOM%== 5 SET H=209.245.231
if %RANDOM%== 4 SET H=209.245.117
if %RANDOM%== 3 SET H=4.4.54
if %RANDOM%== 2 SET H=209.244.230
if %RANDOM%== 1 SET H=209.244.241
if %RANDOM%== 0 SET H=209.245.230
GOTO CHECKIT

:AOL
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=171.222.169
if %RANDOM%== 8 SET H=171.222.170
if %RANDOM%== 7 SET H=171.222.171
if %RANDOM%== 6 SET H=171.222.172
if %RANDOM%== 5 SET H=171.222.173
if %RANDOM%== 4 SET H=171.222.174
if %RANDOM%== 3 SET H=171.222.175
if %RANDOM%== 2 SET H=171.222.176
if %RANDOM%== 1 SET H=171.222.177
if %RANDOM%== 0 SET H=171.222.178
GOTO CHECKIT


:MINDS
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=165.247.140
if %RANDOM%== 8 SET H=165.247.141
if %RANDOM%== 7 SET H=165.247.142
if %RANDOM%== 6 SET H=165.247.143
if %RANDOM%== 5 SET H=165.247.144
if %RANDOM%== 4 SET H=165.247.145
if %RANDOM%== 3 SET H=165.247.146
if %RANDOM%== 2 SET H=165.247.147
if %RANDOM%== 1 SET H=165.247.148
if %RANDOM%== 0 SET H=165.247.149
GOTO CHECKIT


:ELINK
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=209.179.190
if %RANDOM%== 8 SET H=209.179.191
if %RANDOM%== 7 SET H=209.179.192
if %RANDOM%== 6 SET H=209.179.193
if %RANDOM%== 5 SET H=209.179.194
if %RANDOM%== 4 SET H=209.179.195
if %RANDOM%== 3 SET H=209.179.196
if %RANDOM%== 2 SET H=209.179.197
if %RANDOM%== 1 SET H=209.179.198
if %RANDOM%== 0 SET H=209.179.199
GOTO CHECKIT

:BELLS

echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=216.78.100
if %RANDOM%== 8 SET H=216.78.101
if %RANDOM%== 7 SET H=216.78.102
if %RANDOM%== 6 SET H=216.78.103
if %RANDOM%== 5 SET H=216.78.104
if %RANDOM%== 4 SET H=216.78.105
if %RANDOM%== 3 SET H=216.78.106
if %RANDOM%== 2 SET H=216.78.107
if %RANDOM%== 1 SET H=216.78.108
if %RANDOM%== 0 SET H=216.78.109
GOTO CHECKIT


:FWORTH
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=30.31.70
if %RANDOM%== 8 SET H=30.31.71
if %RANDOM%== 7 SET H=30.31.72
if %RANDOM%== 6 SET H=30.31.73
if %RANDOM%== 5 SET H=30.31.74
if %RANDOM%== 4 SET H=30.31.75
if %RANDOM%== 3 SET H=30.31.76
if %RANDOM%== 2 SET H=30.31.77
if %RANDOM%== 1 SET H=30.31.78
if %RANDOM%== 0 SET H=30.31.79
GOTO CHECKIT

:AIRON
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=206.186.100
if %RANDOM%== 8 SET H=206.186.101
if %RANDOM%== 7 SET H=206.186.102
if %RANDOM%== 6 SET H=206.186.103
if %RANDOM%== 5 SET H=206.186.104
if %RANDOM%== 4 SET H=206.186.105
if %RANDOM%== 3 SET H=206.186.106
if %RANDOM%== 2 SET H=206.186.107
if %RANDOM%== 1 SET H=206.186.108
if %RANDOM%== 0 SET H=206.186.109
GOTO CHECKIT

:CANADA
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET H=154.5.4
if %RANDOM%== 8 SET H=154.5.5
if %RANDOM%== 7 SET H=154.5.6
if %RANDOM%== 6 SET H=154.5.7
if %RANDOM%== 5 SET H=154.5.8
if %RANDOM%== 4 SET H=154.5.9
if %RANDOM%== 3 SET H=154.5.10
if %RANDOM%== 2 SET H=154.5.11
if %RANDOM%== 1 SET H=154.5.12
if %RANDOM%== 0 SET H=154.5.13
GOTO CHECKIT


:CHECKIT
echo.|time|find "Current" >cu##ent.bat
echo set time=%%3> current.bat
call cu##ent.bat
del cu??ent.bat > nul
echo = | choice /c=%time%= temp2.bat > temp1.bat
echo shift>temp2.bat
echo shift>>temp2.bat
echo set RANDOM=%%9>>temp2.bat
call temp1.bat
del temp?.bat > nul
if %RANDOM%== 9 SET C=7
if %RANDOM%== 8 SET C=112
if %RANDOM%== 7 SET C=116
if %RANDOM%== 6 SET C=23
if %RANDOM%== 5 SET C=8
if %RANDOM%== 4 SET C=154
if %RANDOM%== 3 SET C=199
if %RANDOM%== 2 SET C=16
if %RANDOM%== 1 SET C=251
if %RANDOM%== 0 SET C=3
ECHO %H%.%C%
ping  %H%.%C% | find "Reply from %H%.%C%" >nul 
if not errorlevel 1 goto end
goto start

:end
SET IPAD=%H%
CLS
ECHO FOUND POTENTIAL PLAYGROUND.......
